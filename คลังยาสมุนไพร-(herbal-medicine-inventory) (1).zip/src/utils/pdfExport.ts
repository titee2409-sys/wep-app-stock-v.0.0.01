import jsPDF from "jspdf";
import html2canvas from "html2canvas";

export interface ExportPdfOptions {
  filename?: string;
  reportTitle?: string;
  onProgress?: (status: string) => void;
}

/**
 * Capture an HTML element by ID and export it as an A4 formatted PDF document
 */
export async function exportElementToPdf(
  elementId: string,
  options: ExportPdfOptions = {}
): Promise<void> {
  const element = document.getElementById(elementId);
  if (!element) {
    throw new Error(`ไม่พบองค์ประกอบ HTML สำหรับการส่งออก (id: ${elementId})`);
  }

  options.onProgress?.("กำลังประมวลผลเอกสาร...");

  // Capture canvas with 2x scale for sharp text rendering
  const canvas = await html2canvas(element, {
    scale: 2,
    useCORS: true,
    allowTaint: true,
    logging: false,
    backgroundColor: "#FFFFFF",
    windowWidth: element.scrollWidth || 800,
  });

  options.onProgress?.("กำลังสร้างไฟล์ PDF...");

  const imgData = canvas.toDataURL("image/png");

  // Create jsPDF instance (A4 size: 210mm x 297mm)
  const pdf = new jsPDF({
    orientation: "portrait",
    unit: "mm",
    format: "a4",
    compress: true,
  });

  const pdfWidth = 210;
  const pdfHeight = 297;
  const margin = 8; // 8mm margin
  const contentWidth = pdfWidth - margin * 2;
  const contentHeight = (canvas.height * contentWidth) / canvas.width;

  let heightLeft = contentHeight;
  let position = margin;
  let page = 1;

  // Page 1
  pdf.addImage(imgData, "PNG", margin, position, contentWidth, contentHeight, undefined, "FAST");
  heightLeft -= (pdfHeight - margin * 2);

  // Additional pages if report height exceeds 1 page
  while (heightLeft > 5) {
    pdf.addPage();
    position = margin - (pdfHeight - margin * 2) * page;
    pdf.addImage(imgData, "PNG", margin, position, contentWidth, contentHeight, undefined, "FAST");
    heightLeft -= (pdfHeight - margin * 2);
    page++;
  }

  const todayStr = new Date().toISOString().slice(0, 10);
  const defaultFilename = `herbal-inventory-alerts-report-${todayStr}.pdf`;
  const finalFilename = options.filename || defaultFilename;

  options.onProgress?.("กำลังบันทึกไฟล์...");
  pdf.save(finalFilename);
}
