import type { InventoryState, StockTransaction, HerbalLot, EmailAlertSettings, MockEmailNotification } from "../types";
import { INITIAL_INVENTORY, INITIAL_TRANSACTIONS, SAMPLE_INVENTORY, SAMPLE_TRANSACTIONS } from "../data/initialData";

const INV_KEY = "herbal_inventory_v2";
const TX_KEY = "herbal_transactions_v2";
const NAME_KEY = "herbal_staff_name";
const EMAIL_SETTINGS_KEY = "herbal_email_settings_v1";
const EMAIL_LOGS_KEY = "herbal_email_logs_v2";

export const DEFAULT_EMAIL_SETTINGS: EmailAlertSettings = {
  enabled: true,
  recipientEmail: "titee2409@gmail.com",
  notifyLowStock: true,
  notifyNearExpiry: true,
  nearExpiryDaysThreshold: 90,
  frequency: "instant",
  autoSimulateOnStockChange: true,
};

export async function loadInventory(): Promise<InventoryState> {
  try {
    // If v1 data exists, remove it so sample data doesn't persist
    if (typeof window !== "undefined") {
      try {
        localStorage.removeItem("herbal_inventory_v1");
        localStorage.removeItem("herbal_transactions_v1");
        localStorage.removeItem("herbal_email_logs_v1");
        if (window.storage) {
          window.storage.set("herbal_inventory_v1", "", true).catch(() => {});
          window.storage.set("herbal_transactions_v1", "", true).catch(() => {});
        }
      } catch {}
    }

    if (typeof window !== "undefined" && window.storage) {
      const r = await window.storage.get(INV_KEY, true);
      if (r?.value) return JSON.parse(r.value);
    }
    const local = localStorage.getItem(INV_KEY);
    if (local) return JSON.parse(local);
    localStorage.setItem(INV_KEY, JSON.stringify(INITIAL_INVENTORY));
    return INITIAL_INVENTORY;
  } catch (err) {
    console.error("loadInventory error", err);
    return INITIAL_INVENTORY;
  }
}

export async function saveInventory(inv: InventoryState): Promise<void> {
  try {
    if (typeof window !== "undefined" && window.storage) {
      await window.storage.set(INV_KEY, JSON.stringify(inv), true);
    }
    localStorage.setItem(INV_KEY, JSON.stringify(inv));
  } catch (e) {
    console.error("save inventory failed", e);
  }
}

export async function loadTx(): Promise<StockTransaction[]> {
  try {
    if (typeof window !== "undefined" && window.storage) {
      const r = await window.storage.get(TX_KEY, true);
      if (r?.value) return JSON.parse(r.value);
    }
    const local = localStorage.getItem(TX_KEY);
    if (local) return JSON.parse(local);
    localStorage.setItem(TX_KEY, JSON.stringify(INITIAL_TRANSACTIONS));
    return INITIAL_TRANSACTIONS;
  } catch {
    return INITIAL_TRANSACTIONS;
  }
}

export async function saveTx(tx: StockTransaction[]): Promise<void> {
  try {
    if (typeof window !== "undefined" && window.storage) {
      await window.storage.set(TX_KEY, JSON.stringify(tx), true);
    }
    localStorage.setItem(TX_KEY, JSON.stringify(tx));
  } catch (e) {
    console.error("save tx failed", e);
  }
}

/**
 * Clear all data (items, lots, transactions, and email logs)
 */
export async function clearAllData(): Promise<{ inventory: InventoryState; transactions: StockTransaction[] }> {
  const emptyInv: InventoryState = { items: [], lots: [] };
  const emptyTx: StockTransaction[] = [];
  await saveInventory(emptyInv);
  await saveTx(emptyTx);
  await saveEmailLogs([]);
  try {
    localStorage.removeItem("herbal_inventory_v1");
    localStorage.removeItem("herbal_transactions_v1");
    localStorage.removeItem("herbal_email_logs_v1");
  } catch {}
  return { inventory: emptyInv, transactions: emptyTx };
}

/**
 * Load sample demo data (5 items, 5 lots, 18 transactions)
 */
export async function loadSampleData(): Promise<{ inventory: InventoryState; transactions: StockTransaction[] }> {
  await saveInventory(SAMPLE_INVENTORY);
  await saveTx(SAMPLE_TRANSACTIONS);
  return { inventory: SAMPLE_INVENTORY, transactions: SAMPLE_TRANSACTIONS };
}

export async function loadName(): Promise<string> {
  try {
    if (typeof window !== "undefined" && window.storage) {
      const r = await window.storage.get(NAME_KEY, false);
      if (r?.value) return r.value;
    }
    return localStorage.getItem(NAME_KEY) || "เภสัชกร ประจำการ";
  } catch {
    return "เภสัชกร ประจำการ";
  }
}

export async function saveName(n: string): Promise<void> {
  try {
    if (typeof window !== "undefined" && window.storage) {
      await window.storage.set(NAME_KEY, n, false);
    }
    localStorage.setItem(NAME_KEY, n);
  } catch (e) {
    console.error("save name failed", e);
  }
}

export const uid = () => Date.now().toString(36) + Math.random().toString(36).slice(2, 8);
export const today = () => new Date().toISOString().slice(0, 10);

export const fmtDate = (d?: string) => {
  if (!d) return "-";
  try {
    const dt = new Date(d + "T00:00:00");
    if (isNaN(dt.getTime())) return d;
    return dt.toLocaleDateString("th-TH", { day: "2-digit", month: "short", year: "numeric" });
  } catch {
    return d;
  }
};

export const daysUntil = (d: string) => {
  try {
    const dt = new Date(d + "T00:00:00");
    const now = new Date();
    now.setHours(0, 0, 0, 0);
    return Math.ceil((dt.getTime() - now.getTime()) / 86400000);
  } catch {
    return 999;
  }
};

export const CATEGORIES = [
  "ยาเม็ด",
  "ยาแคปซูล",
  "ยาผง",
  "ยาน้ำ/ยาดอง",
  "วัตถุดิบสมุนไพรดิบ",
  "ยาดม/ยาหม่อง",
  "อื่นๆ",
];

export function lotQtyForItem(lots: HerbalLot[], itemId: string) {
  return lots.filter((l) => l.itemId === itemId && l.qty > 0).reduce((s, l) => s + l.qty, 0);
}

export async function loadEmailSettings(): Promise<EmailAlertSettings> {
  try {
    if (typeof window !== "undefined" && window.storage) {
      const r = await window.storage.get(EMAIL_SETTINGS_KEY, true);
      if (r?.value) return { ...DEFAULT_EMAIL_SETTINGS, ...JSON.parse(r.value) };
    }
    const local = localStorage.getItem(EMAIL_SETTINGS_KEY);
    if (local) return { ...DEFAULT_EMAIL_SETTINGS, ...JSON.parse(local) };
    return DEFAULT_EMAIL_SETTINGS;
  } catch {
    return DEFAULT_EMAIL_SETTINGS;
  }
}

export async function saveEmailSettings(settings: EmailAlertSettings): Promise<void> {
  try {
    if (typeof window !== "undefined" && window.storage) {
      await window.storage.set(EMAIL_SETTINGS_KEY, JSON.stringify(settings), true);
    }
    localStorage.setItem(EMAIL_SETTINGS_KEY, JSON.stringify(settings));
  } catch (e) {
    console.error("save email settings failed", e);
  }
}

export async function loadEmailLogs(): Promise<MockEmailNotification[]> {
  try {
    if (typeof window !== "undefined" && window.storage) {
      const r = await window.storage.get(EMAIL_LOGS_KEY, true);
      if (r?.value) return JSON.parse(r.value);
    }
    const local = localStorage.getItem(EMAIL_LOGS_KEY);
    if (local) return JSON.parse(local);
    return [];
  } catch {
    return [];
  }
}

export async function saveEmailLogs(logs: MockEmailNotification[]): Promise<void> {
  try {
    if (typeof window !== "undefined" && window.storage) {
      await window.storage.set(EMAIL_LOGS_KEY, JSON.stringify(logs.slice(0, 50)), true);
    }
    localStorage.setItem(EMAIL_LOGS_KEY, JSON.stringify(logs.slice(0, 50)));
  } catch (e) {
    console.error("save email logs failed", e);
  }
}
