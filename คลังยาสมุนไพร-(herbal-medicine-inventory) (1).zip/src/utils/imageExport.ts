import html2canvas from "html2canvas";

export interface ExportImageOptions {
  filename?: string;
  scale?: number;
  backgroundColor?: string;
  onProgress?: (msg: string) => void;
}

/**
 * Capture an HTML element by ID and export it as a high-resolution PNG image file
 * suitable for inclusion in formal inventory reports and executive presentations.
 */
export async function exportElementToPng(
  elementId: string,
  options: ExportImageOptions = {}
): Promise<void> {
  const element = document.getElementById(elementId);
  if (!element) {
    throw new Error(`ไม่พบองค์ประกอบสำหรับส่งออกรูปภาพ (id: ${elementId})`);
  }

  options.onProgress?.("กำลังประมวลผลกราฟความละเอียดสูง...");

  // Capture canvas with 2.5x scale for crisp publication-ready rendering
  const canvas = await html2canvas(element, {
    scale: options.scale || 2.5,
    useCORS: true,
    allowTaint: true,
    logging: false,
    backgroundColor: options.backgroundColor || "#FFFFFF",
    windowWidth: element.scrollWidth || 1100,
  });

  options.onProgress?.("กำลังแปลงเป็นไฟล์รูปภาพ PNG...");

  // Convert to Blob and trigger direct browser download
  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, "image/png"));
  if (!blob) {
    throw new Error("เกิดข้อผิดพลาดในการแปลง Canvas เป็นไฟล์รูปภาพ");
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  const todayStr = new Date().toISOString().slice(0, 10);
  a.href = url;
  a.download = options.filename || `กราฟวิเคราะห์คลังยาสมุนไพร_${todayStr}.png`;
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
