export interface HerbalItem {
  id: string;
  name: string;
  category: string;
  unit: string;
  minStock: number;
  price: number;
  supplier?: string;
  reorderQty?: number;
  leadTimeDays?: number;
  orderNotes?: string;
  lastOrderDate?: string;
}

export interface HerbalLot {
  id: string;
  itemId: string;
  lotNo: string;
  qty: number;
  expiryDate: string;
  receivedDate: string;
}

export interface StockTransaction {
  id: string;
  itemId: string;
  lotId?: string;
  type: "in" | "out";
  qty: number;
  date: string;
  timestamp?: string;
  user: string;
  note?: string;
}

export interface InventoryState {
  items: HerbalItem[];
  lots: HerbalLot[];
}

export interface MockEmailNotification {
  id: string;
  sentAt: string;
  recipientEmail: string;
  subject: string;
  type: "combined" | "low_stock" | "near_expiry" | "digest";
  itemCount: number;
  lowStockItemsCount: number;
  nearExpiryLotsCount: number;
  estimatedReorderCost?: number;
  status: "sent" | "delivered";
  summaryText?: string;
  lowStockDetails?: {
    id: string;
    name: string;
    category: string;
    unit: string;
    current: number;
    minStock: number;
    reorderQty?: number;
    supplier?: string;
    estimatedCost: number;
  }[];
  nearExpiryDetails?: {
    lotId: string;
    itemName: string;
    lotNo: string;
    qty: number;
    unit: string;
    expiryDate: string;
    daysLeft: number;
  }[];
}

export interface EmailAlertSettings {
  enabled: boolean;
  recipientEmail: string;
  notifyLowStock: boolean;
  notifyNearExpiry: boolean;
  nearExpiryDaysThreshold: number;
  frequency: "instant" | "daily" | "weekly";
  autoSimulateOnStockChange: boolean;
}

declare global {
  interface Window {
    storage?: {
      get: (key: string, shared: boolean) => Promise<{ value: string } | null>;
      set: (key: string, value: string, shared: boolean) => Promise<void>;
    };
  }
}

