import React, { useState } from "react";
import {
  AlertTriangle,
  AlertOctagon,
  ShoppingBag,
  Pencil,
  Truck,
  Building,
  Calendar,
  DollarSign,
  PackageCheck,
  ClipboardList,
  Copy,
  X,
  Check,
  ArrowRight,
  TrendingDown,
  Info,
  Mail,
} from "lucide-react";
import type { InventoryState, HerbalItem } from "../types";
import { lotQtyForItem, fmtDate, today } from "../utils/storage";

interface LowStockAlertCardProps {
  inv: InventoryState;
  lowStockItems: HerbalItem[];
  persistInv: (next: InventoryState) => Promise<void>;
  showToast: (msg: string) => void;
  onOpenMoveWithItem?: (itemId: string) => void;
  onOpenEmailModal?: (type?: "low_stock" | "near_expiry" | "combined" | "digest") => void;
}

export function LowStockAlertCard({
  inv,
  lowStockItems,
  persistInv,
  showToast,
  onOpenMoveWithItem,
  onOpenEmailModal,
}: LowStockAlertCardProps) {
  const [selectedItemForReorder, setSelectedItemForReorder] = useState<HerbalItem | null>(null);
  const [showSummaryModal, setShowSummaryModal] = useState(false);
  const [copiedSummary, setCopiedSummary] = useState(false);

  // Form states for the reorder modal
  const [minStockVal, setMinStockVal] = useState<number | string>(10);
  const [reorderQtyVal, setReorderQtyVal] = useState<number | string>(20);
  const [priceVal, setPriceVal] = useState<number | string>(0);
  const [supplierVal, setSupplierVal] = useState("");
  const [leadTimeVal, setLeadTimeVal] = useState<number | string>(3);
  const [orderNotesVal, setOrderNotesVal] = useState("");
  const [lastOrderDateVal, setLastOrderDateVal] = useState("");
  const [saving, setSaving] = useState(false);

  // Compute total estimated procurement cost for all low stock items
  const totalEstimatedReorderCost = lowStockItems.reduce((sum, item) => {
    const current = lotQtyForItem(inv.lots, item.id);
    const deficit = Math.max(0, item.minStock - current);
    const qtyToOrder = item.reorderQty && item.reorderQty > 0 ? item.reorderQty : deficit;
    return sum + qtyToOrder * (Number(item.price) || 0);
  }, 0);

  function openReorderModal(item: HerbalItem) {
    const current = lotQtyForItem(inv.lots, item.id);
    const deficit = Math.max(0, item.minStock - current);
    setSelectedItemForReorder(item);
    setMinStockVal(item.minStock);
    setReorderQtyVal(item.reorderQty ?? (deficit > 0 ? deficit : item.minStock));
    setPriceVal(item.price || 0);
    setSupplierVal(item.supplier || "");
    setLeadTimeVal(item.leadTimeDays ?? 3);
    setOrderNotesVal(item.orderNotes || "");
    setLastOrderDateVal(item.lastOrderDate || today());
  }

  function closeReorderModal() {
    setSelectedItemForReorder(null);
  }

  async function handleSaveReorder(goToReceive = false) {
    if (!selectedItemForReorder) return;
    setSaving(true);
    try {
      const updatedItems = inv.items.map((it) => {
        if (it.id === selectedItemForReorder.id) {
          return {
            ...it,
            minStock: Math.max(0, Number(minStockVal) || 0),
            price: Math.max(0, Number(priceVal) || 0),
            supplier: supplierVal.trim(),
            reorderQty: Math.max(0, Number(reorderQtyVal) || 0),
            leadTimeDays: Math.max(0, Number(leadTimeVal) || 0),
            orderNotes: orderNotesVal.trim(),
            lastOrderDate: lastOrderDateVal || today(),
          };
        }
        return it;
      });

      await persistInv({
        ...inv,
        items: updatedItems,
      });

      showToast(`อัปเดตข้อมูลสั่งซื้อของ "${selectedItemForReorder.name}" เรียบร้อยแล้ว`);
      const targetItemId = selectedItemForReorder.id;
      closeReorderModal();

      if (goToReceive && onOpenMoveWithItem) {
        onOpenMoveWithItem(targetItemId);
      }
    } catch (err) {
      console.error(err);
      showToast("เกิดข้อผิดพลาดในการบันทึกข้อมูล");
    } finally {
      setSaving(false);
    }
  }

  function copyPurchaseSummary() {
    const lines = [
      `📋 สรุปรายการยาที่ต้องจัดซื้อเร่งด่วน (คลังยาสมุนไพร)`,
      `วันที่สรุป: ${new Date().toLocaleDateString("th-TH")}`,
      `จำนวนรายการ: ${lowStockItems.length} รายการ`,
      `งบประมาณประมาณการรวม: ฿${totalEstimatedReorderCost.toLocaleString()}`,
      `------------------------------------------`,
    ];

    lowStockItems.forEach((it, idx) => {
      const current = lotQtyForItem(inv.lots, it.id);
      const deficit = Math.max(0, it.minStock - current);
      const qtyToOrder = it.reorderQty && it.reorderQty > 0 ? it.reorderQty : deficit;
      const cost = qtyToOrder * (Number(it.price) || 0);

      lines.push(
        `${idx + 1}. ${it.name} (${it.category})`,
        `   • สต็อกปัจจุบัน: ${current} ${it.unit} (ขั้นต่ำ ${it.minStock} ${it.unit})`,
        `   • จำนวนสั่งซื้อแนะนำ: ${qtyToOrder} ${it.unit} @ ฿${it.price}/${it.unit}`,
        `   • มูลค่าสั่งซื้อ: ฿${cost.toLocaleString()}`,
        `   • ผู้จัดจำหน่าย: ${it.supplier || "ยังไม่ระบุ"}`,
        it.orderNotes ? `   • หมายเหตุ: ${it.orderNotes}` : "",
        ""
      );
    });

    navigator.clipboard.writeText(lines.filter(Boolean).join("\n"));
    setCopiedSummary(true);
    showToast("คัดลอกรายการสั่งซื้อสำหรับประสานงานจัดซื้อแล้ว");
    setTimeout(() => setCopiedSummary(false), 2500);
  }

  return (
    <div id="highlighted-low-stock-section" style={{ marginBottom: 20 }}>
      {/* Highlighted Alert Card Container */}
      <div
        id="card-low-stock-alert"
        style={{
          background: lowStockItems.length > 0 ? "linear-gradient(135deg, #FFF9F9 0%, #FFF5F4 100%)" : "#F6F8F6",
          border: lowStockItems.length > 0 ? "1.5px solid #F5C6C2" : "1px solid #D8E4DB",
          borderRadius: 12,
          padding: "18px 20px",
          boxShadow: lowStockItems.length > 0 ? "0 4px 18px rgba(168, 59, 50, 0.08)" : "none",
          position: "relative",
          overflow: "hidden",
        }}
      >
        {/* Accent Top Border Strip */}
        <div
          style={{
            position: "absolute",
            top: 0,
            left: 0,
            right: 0,
            height: 4,
            background: lowStockItems.length > 0 ? "linear-gradient(90deg, #A83B32, #C08A2E)" : "#3C5A45",
          }}
        />

        {/* Header of the Highlighted Alert Card */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            flexWrap: "wrap",
            gap: 12,
            marginBottom: lowStockItems.length > 0 ? 16 : 0,
          }}
        >
          <div style={{ display: "flex", alignItems: "flex-start", gap: 12 }}>
            <div
              style={{
                background: lowStockItems.length > 0 ? "#A83B32" : "#3C5A45",
                color: "#FFFFFF",
                padding: "9px 10px",
                borderRadius: 10,
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                boxShadow: lowStockItems.length > 0 ? "0 2px 8px rgba(168, 59, 50, 0.25)" : "none",
                flexShrink: 0,
                marginTop: 2,
              }}
            >
              {lowStockItems.length > 0 ? <AlertTriangle size={22} /> : <PackageCheck size={22} />}
            </div>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                <h3
                  style={{
                    fontFamily: "'Noto Serif Thai', serif",
                    fontSize: 18,
                    fontWeight: 700,
                    margin: 0,
                    color: lowStockItems.length > 0 ? "#842A22" : "#1F2D24",
                  }}
                >
                  {lowStockItems.length > 0
                    ? `แจ้งเตือนยาใกล้หมดสต็อก & เตรียมจัดซื้อ (${lowStockItems.length} รายการ)`
                    : "สถานะสต็อกยาสมุนไพรปลอดภัยทุกรายการ"}
                </h3>
                {lowStockItems.length > 0 && (
                  <span
                    style={{
                      background: "#A83B32",
                      color: "#FFFFFF",
                      fontSize: 11.5,
                      fontWeight: 700,
                      padding: "2px 8px",
                      borderRadius: 12,
                      display: "inline-flex",
                      alignItems: "center",
                      gap: 4,
                    }}
                  >
                    <span
                      style={{
                        width: 6,
                        height: 6,
                        borderRadius: "50%",
                        background: "#FFF",
                        display: "inline-block",
                      }}
                    />
                    ต้องสั่งซื้อเร่งด่วน
                  </span>
                )}
              </div>
              <p
                style={{
                  margin: "4px 0 0",
                  fontSize: 13,
                  color: lowStockItems.length > 0 ? "#6B433F" : "#5B7A63",
                  lineHeight: 1.5,
                }}
              >
                {lowStockItems.length > 0
                  ? "มียาสมุนไพรที่ปริมาณคงเหลือต่ำกว่าเกณฑ์ความปลอดภัย สามารถกด 'แก้ไขข้อมูลการสั่งซื้อ' ที่แต่ละรายการเพื่อปรับเกณฑ์และวางแผนสั่งซื้อได้ทันที"
                  : "ปริมาณคงเหลือทุกรายการยาสมุนไพรสูงกว่าเกณฑ์สต็อกขั้นต่ำที่กำหนด พร้อมรองรับการจ่ายยาอย่างต่อเนื่อง"}
              </p>
            </div>
          </div>

          {/* Quick Summary & Action Buttons */}
          {lowStockItems.length > 0 && (
            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
              <div
                style={{
                  background: "#FFFFFF",
                  border: "1px solid #EED8D6",
                  borderRadius: 8,
                  padding: "6px 12px",
                  fontSize: 12.5,
                  color: "#5B5747",
                  display: "flex",
                  alignItems: "center",
                  gap: 6,
                }}
              >
                <span>งบจัดซื้อประมาณการ:</span>
                <strong style={{ color: "#A83B32", fontSize: 14 }}>
                  ฿{totalEstimatedReorderCost.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </strong>
              </div>

              <button
                id="btn-copy-po-summary"
                onClick={copyPurchaseSummary}
                style={{
                  background: "#FFFFFF",
                  border: "1px solid #D8D3C2",
                  color: "#1F2D24",
                  borderRadius: 8,
                  padding: "7px 12px",
                  fontSize: 12.5,
                  fontWeight: 600,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  cursor: "pointer",
                  fontFamily: "Sarabun, sans-serif",
                  transition: "all 0.15s ease",
                }}
              >
                {copiedSummary ? <Check size={14} color="#3C5A45" /> : <Copy size={14} color="#5B5747" />}
                <span>{copiedSummary ? "คัดลอกแล้ว!" : "คัดลอกสรุปใบสั่งซื้อ"}</span>
              </button>

              {onOpenEmailModal && (
                <button
                  id="btn-low-stock-send-mock-email"
                  onClick={() => onOpenEmailModal("low_stock")}
                  style={{
                    background: "#2D4834",
                    border: "1px solid #2D4834",
                    color: "#FFFFFF",
                    borderRadius: 8,
                    padding: "7px 13px",
                    fontSize: 12.5,
                    fontWeight: 700,
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    cursor: "pointer",
                    fontFamily: "Sarabun, sans-serif",
                    boxShadow: "0 2px 6px rgba(45, 72, 52, 0.2)",
                    transition: "all 0.15s ease",
                  }}
                  title="จำลองการส่งการแจ้งเตือนอีเมลไปยังผู้รับผิดชอบ"
                >
                  <Mail size={14} color="#9CE6B4" />
                  <span>จำลองส่งอีเมลแจ้งเตือน</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* Low Stock Items Cards Grid */}
        {lowStockItems.length > 0 && (
          <div
            id="low-stock-cards-grid"
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(auto-fit, minmax(320px, 1fr))",
              gap: 12,
              marginTop: 10,
            }}
          >
            {lowStockItems.map((item) => {
              const current = lotQtyForItem(inv.lots, item.id);
              const deficit = Math.max(0, item.minStock - current);
              const reorderQty = item.reorderQty && item.reorderQty > 0 ? item.reorderQty : deficit;
              const estimatedCost = reorderQty * (Number(item.price) || 0);
              const stockRatio = item.minStock > 0 ? current / item.minStock : 0;
              const isCritical = stockRatio <= 0.5 || current === 0;

              return (
                <div
                  key={item.id}
                  id={`low-stock-card-${item.id}`}
                  style={{
                    background: "#FFFFFF",
                    border: isCritical ? "1.5px solid #EAA49E" : "1px solid #EEDCD9",
                    borderRadius: 10,
                    padding: "14px 16px",
                    display: "flex",
                    flexDirection: "column",
                    justifyContent: "space-between",
                    boxShadow: "0 2px 6px rgba(0,0,0,0.02)",
                    transition: "transform 0.15s ease, box-shadow 0.15s ease",
                  }}
                >
                  {/* Item Title & Category */}
                  <div>
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8, marginBottom: 8 }}>
                      <div>
                        <div style={{ fontWeight: 700, fontSize: 14.5, color: "#1F2D24", lineHeight: 1.3 }}>
                          {item.name}
                        </div>
                        <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 4 }}>
                          <span
                            style={{
                              background: "#F5F5F0",
                              color: "#5B5747",
                              fontSize: 11,
                              padding: "2px 6px",
                              borderRadius: 4,
                              fontWeight: 600,
                            }}
                          >
                            {item.category}
                          </span>
                          <span
                            style={{
                              background: isCritical ? "#FDF0EE" : "#FFF7EB",
                              color: isCritical ? "#A83B32" : "#C08A2E",
                              fontSize: 11,
                              padding: "2px 6px",
                              borderRadius: 4,
                              fontWeight: 700,
                              display: "inline-flex",
                              alignItems: "center",
                              gap: 3,
                            }}
                          >
                            <TrendingDown size={12} />
                            {isCritical ? "วิกฤต (เหลือน้อยมาก)" : "เฝ้าระวัง (ต่ำกว่าเกณฑ์)"}
                          </span>
                        </div>
                      </div>

                      {/* Stock Ratio Pill */}
                      <div style={{ textAlign: "right" }}>
                        <div style={{ fontSize: 11, color: "#8A8874" }}>ขาดอีก</div>
                        <div style={{ fontSize: 15, fontWeight: 700, color: "#A83B32" }}>
                          {deficit} {item.unit}
                        </div>
                      </div>
                    </div>

                    {/* Stock Level Progress Bar */}
                    <div style={{ marginBottom: 12, marginTop: 6 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 4 }}>
                        <span style={{ color: "#5B5747" }}>
                          คงเหลือ: <strong style={{ color: isCritical ? "#A83B32" : "#C08A2E" }}>{current}</strong> {item.unit}
                        </span>
                        <span style={{ color: "#8A8874" }}>
                          เกณฑ์ขั้นต่ำ: <strong>{item.minStock}</strong> {item.unit}
                        </span>
                      </div>
                      <div style={{ width: "100%", height: 7, background: "#EAE6DA", borderRadius: 4, overflow: "hidden" }}>
                        <div
                          style={{
                            width: `${Math.min(100, Math.round(stockRatio * 100))}%`,
                            height: "100%",
                            background: isCritical ? "#A83B32" : "#C08A2E",
                            borderRadius: 4,
                            transition: "width 0.4s ease",
                          }}
                        />
                      </div>
                    </div>

                    {/* Procurement Details Strip */}
                    <div
                      style={{
                        background: "#FCFAF6",
                        border: "1px dashed #E2DDCF",
                        borderRadius: 7,
                        padding: "8px 10px",
                        fontSize: 12,
                        display: "flex",
                        flexDirection: "column",
                        gap: 4,
                        marginBottom: 14,
                      }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <span style={{ color: "#8A8874", display: "flex", alignItems: "center", gap: 4 }}>
                          <ShoppingBag size={12} color="#5B7A63" /> สั่งซื้อแนะนำ:
                        </span>
                        <strong style={{ color: "#1F2D24" }}>
                          {reorderQty} {item.unit} (ประมาณการ ฿{estimatedCost.toLocaleString()})
                        </strong>
                      </div>

                      <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <span style={{ color: "#8A8874", display: "flex", alignItems: "center", gap: 4 }}>
                          <Building size={12} color="#8A8874" /> ผู้จัดจำหน่าย:
                        </span>
                        <span style={{ color: "#1F2D24", fontWeight: 500, maxWidth: 180, textAlign: "right", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {item.supplier || "ยังไม่ระบุ (กดแก้ไขเพื่อบันทึก)"}
                        </span>
                      </div>

                      {item.leadTimeDays && (
                        <div style={{ display: "flex", justifyContent: "space-between" }}>
                          <span style={{ color: "#8A8874", display: "flex", alignItems: "center", gap: 4 }}>
                            <Truck size={12} color="#8A8874" /> ระยะเวลาจัดส่ง:
                          </span>
                          <span style={{ color: "#1F2D24" }}>{item.leadTimeDays} วัน</span>
                        </div>
                      )}

                      {item.orderNotes && (
                        <div style={{ fontSize: 11.5, color: "#6B5B3E", borderTop: "1px solid #ECE7DC", paddingTop: 4, marginTop: 2 }}>
                          📝 {item.orderNotes}
                        </div>
                      )}
                    </div>
                  </div>

                  {/* Immediate Action Buttons */}
                  <div style={{ display: "flex", gap: 8 }}>
                    <button
                      id={`btn-edit-reorder-${item.id}`}
                      onClick={() => openReorderModal(item)}
                      style={{
                        flex: 1,
                        background: "#A83B32",
                        color: "#FFFFFF",
                        border: "none",
                        borderRadius: 7,
                        padding: "8px 10px",
                        fontSize: 12.5,
                        fontWeight: 700,
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        gap: 6,
                        fontFamily: "Sarabun, sans-serif",
                        boxShadow: "0 2px 6px rgba(168, 59, 50, 0.2)",
                        transition: "background 0.15s ease",
                      }}
                    >
                      <Pencil size={13} />
                      <span>แก้ไขข้อมูลการสั่งซื้อ</span>
                    </button>

                    {onOpenMoveWithItem && (
                      <button
                        id={`btn-receive-now-${item.id}`}
                        onClick={() => onOpenMoveWithItem(item.id)}
                        title="บันทึกรับเข้าสต็อกเมื่อของมาส่ง"
                        style={{
                          background: "#F2F6F3",
                          border: "1px solid #C4D6C9",
                          color: "#3C5A45",
                          borderRadius: 7,
                          padding: "8px 10px",
                          fontSize: 12.5,
                          fontWeight: 600,
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          gap: 4,
                          fontFamily: "Sarabun, sans-serif",
                          whiteSpace: "nowrap",
                        }}
                      >
                        <span>รับเข้าสต็อก</span>
                        <ArrowRight size={13} />
                      </button>
                    )}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Reorder / Purchase Information Edit Modal */}
      {selectedItemForReorder && (
        <div
          id="reorder-edit-modal-backdrop"
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(31, 45, 36, 0.55)",
            backdropFilter: "blur(3px)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1000,
            padding: 16,
          }}
          onClick={(e) => {
            if (e.target === e.currentTarget) closeReorderModal();
          }}
        >
          <div
            id="reorder-edit-modal"
            style={{
              background: "#FFFFFF",
              borderRadius: 14,
              border: "1px solid #E4E0D2",
              boxShadow: "0 8px 32px rgba(0, 0, 0, 0.16)",
              width: "100%",
              maxWidth: 580,
              maxHeight: "90vh",
              overflowY: "auto",
              padding: "24px 26px",
              display: "flex",
              flexDirection: "column",
              gap: 16,
              animation: "fadeIn 0.2s ease-out",
            }}
          >
            {/* Modal Header */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", borderBottom: "1px solid #EBE7DA", paddingBottom: 14 }}>
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 7 }}>
                  <div style={{ background: "#A83B32", color: "#FFF", padding: 6, borderRadius: 6 }}>
                    <ShoppingBag size={18} />
                  </div>
                  <div>
                    <h3 style={{ fontFamily: "'Noto Serif Thai', serif", fontSize: 18, fontWeight: 700, margin: 0, color: "#1F2D24" }}>
                      แก้ไขข้อมูลการสั่งซื้อ & วางแผนจัดซื้อ
                    </h3>
                    <div style={{ fontSize: 13, color: "#8A8874", marginTop: 2 }}>
                      {selectedItemForReorder.name} ({selectedItemForReorder.category})
                    </div>
                  </div>
                </div>
              </div>

              <button
                onClick={closeReorderModal}
                style={{
                  background: "none",
                  border: "none",
                  color: "#8A8874",
                  cursor: "pointer",
                  padding: 4,
                  borderRadius: 6,
                }}
              >
                <X size={20} />
              </button>
            </div>

            {/* Current Stock Snapshot Banner */}
            {(() => {
              const cur = lotQtyForItem(inv.lots, selectedItemForReorder.id);
              const def = Math.max(0, Number(minStockVal || 0) - cur);
              return (
                <div
                  style={{
                    background: "#FCFAF6",
                    border: "1px solid #EAE6DA",
                    borderRadius: 8,
                    padding: "10px 14px",
                    display: "grid",
                    gridTemplateColumns: "repeat(3, 1fr)",
                    gap: 8,
                    textAlign: "center",
                  }}
                >
                  <div>
                    <div style={{ fontSize: 11, color: "#8A8874" }}>สต็อกปัจจุบัน</div>
                    <div style={{ fontSize: 16, fontWeight: 700, color: "#A83B32" }}>
                      {cur} {selectedItemForReorder.unit}
                    </div>
                  </div>
                  <div style={{ borderLeft: "1px solid #EAE6DA", borderRight: "1px solid #EAE6DA" }}>
                    <div style={{ fontSize: 11, color: "#8A8874" }}>เกณฑ์ขั้นต่ำ</div>
                    <div style={{ fontSize: 16, fontWeight: 700, color: "#1F2D24" }}>
                      {minStockVal} {selectedItemForReorder.unit}
                    </div>
                  </div>
                  <div>
                    <div style={{ fontSize: 11, color: "#8A8874" }}>ขาดจากเกณฑ์</div>
                    <div style={{ fontSize: 16, fontWeight: 700, color: def > 0 ? "#A83B32" : "#3C5A45" }}>
                      {def > 0 ? `ขาด ${def}` : "พอดีเกณฑ์"} {selectedItemForReorder.unit}
                    </div>
                  </div>
                </div>
              );
            })()}

            {/* Form Fields */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(2, 1fr)", gap: 14 }}>
              {/* Min Stock */}
              <label style={{ display: "flex", flexDirection: "column", gap: 5, fontSize: 13 }}>
                <span style={{ fontWeight: 600, color: "#1F2D24" }}>
                  เกณฑ์สต็อกขั้นต่ำ ({selectedItemForReorder.unit}) <span style={{ color: "#A83B32" }}>*</span>
                </span>
                <input
                  id="input-reorder-min-stock"
                  type="number"
                  min="0"
                  value={minStockVal}
                  onChange={(e) => setMinStockVal(e.target.value)}
                  style={{
                    border: "1px solid #D8D3C2",
                    borderRadius: 7,
                    padding: "8px 10px",
                    fontSize: 14,
                    fontFamily: "Sarabun",
                    background: "#FBFAF6",
                  }}
                />
                <span style={{ fontSize: 11, color: "#8A8874" }}>ระบบจะแจ้งเตือนเมื่อสต็อกต่ำกว่าจำนวนนี้</span>
              </label>

              {/* Suggested Reorder Qty */}
              <label style={{ display: "flex", flexDirection: "column", gap: 5, fontSize: 13 }}>
                <span style={{ fontWeight: 600, color: "#1F2D24" }}>
                  ปริมาณแนะนำสั่งซื้อต่อรอบ ({selectedItemForReorder.unit})
                </span>
                <input
                  id="input-reorder-qty"
                  type="number"
                  min="1"
                  value={reorderQtyVal}
                  onChange={(e) => setReorderQtyVal(e.target.value)}
                  style={{
                    border: "1px solid #D8D3C2",
                    borderRadius: 7,
                    padding: "8px 10px",
                    fontSize: 14,
                    fontFamily: "Sarabun",
                    background: "#FBFAF6",
                  }}
                />
                <span style={{ fontSize: 11, color: "#8A8874" }}>จำนวนที่เหมาะสมในการออกใบสั่งซื้อแต่ละครั้ง</span>
              </label>

              {/* Unit Price */}
              <label style={{ display: "flex", flexDirection: "column", gap: 5, fontSize: 13 }}>
                <span style={{ fontWeight: 600, color: "#1F2D24" }}>
                  ราคาซื้อ / ต่อหน่วย (บาท) <span style={{ color: "#A83B32" }}>*</span>
                </span>
                <input
                  id="input-reorder-price"
                  type="number"
                  min="0"
                  step="0.01"
                  value={priceVal}
                  onChange={(e) => setPriceVal(e.target.value)}
                  style={{
                    border: "1px solid #D8D3C2",
                    borderRadius: 7,
                    padding: "8px 10px",
                    fontSize: 14,
                    fontFamily: "Sarabun",
                    background: "#FBFAF6",
                  }}
                />
                <span style={{ fontSize: 11, color: "#8A8874" }}>ใช้คำนวณมูลค่าจัดซื้อและมูลค่าคลัง</span>
              </label>

              {/* Lead Time */}
              <label style={{ display: "flex", flexDirection: "column", gap: 5, fontSize: 13 }}>
                <span style={{ fontWeight: 600, color: "#1F2D24" }}>
                  ระยะเวลารอสินค้า (วัน)
                </span>
                <input
                  id="input-reorder-lead-time"
                  type="number"
                  min="0"
                  value={leadTimeVal}
                  onChange={(e) => setLeadTimeVal(e.target.value)}
                  placeholder="เช่น 3"
                  style={{
                    border: "1px solid #D8D3C2",
                    borderRadius: 7,
                    padding: "8px 10px",
                    fontSize: 14,
                    fontFamily: "Sarabun",
                    background: "#FBFAF6",
                  }}
                />
                <span style={{ fontSize: 11, color: "#8A8874" }}>เวลาเฉลี่ยตั้งแต่สั่งจนได้รับสินค้า</span>
              </label>
            </div>

            {/* Supplier / Vendor */}
            <label style={{ display: "flex", flexDirection: "column", gap: 5, fontSize: 13 }}>
              <span style={{ fontWeight: 600, color: "#1F2D24" }}>
                ผู้จัดจำหน่าย / บริษัทคู่ค้า / แหล่งผลิต
              </span>
              <input
                id="input-reorder-supplier"
                type="text"
                value={supplierVal}
                onChange={(e) => setSupplierVal(e.target.value)}
                placeholder="เช่น วิสาหกิจชุมชนสมุนไพรอินทรีย์ หรือ องค์การเภสัชกรรม"
                style={{
                  border: "1px solid #D8D3C2",
                  borderRadius: 7,
                  padding: "8px 10px",
                  fontSize: 14,
                  fontFamily: "Sarabun",
                  background: "#FBFAF6",
                }}
              />
            </label>

            {/* Last Order Date & Notes */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 2fr", gap: 14 }}>
              <label style={{ display: "flex", flexDirection: "column", gap: 5, fontSize: 13 }}>
                <span style={{ fontWeight: 600, color: "#1F2D24" }}>วันที่สั่งซื้อล่าสุด</span>
                <input
                  id="input-reorder-last-date"
                  type="date"
                  value={lastOrderDateVal}
                  onChange={(e) => setLastOrderDateVal(e.target.value)}
                  style={{
                    border: "1px solid #D8D3C2",
                    borderRadius: 7,
                    padding: "8px 10px",
                    fontSize: 13,
                    fontFamily: "Sarabun",
                    background: "#FBFAF6",
                  }}
                />
              </label>

              <label style={{ display: "flex", flexDirection: "column", gap: 5, fontSize: 13 }}>
                <span style={{ fontWeight: 600, color: "#1F2D24" }}>บันทึกการสั่งซื้อ / เลขที่ใบสั่งซื้อ (PO)</span>
                <input
                  id="input-reorder-notes"
                  type="text"
                  value={orderNotesVal}
                  onChange={(e) => setOrderNotesVal(e.target.value)}
                  placeholder="เช่น PO-2026/09-001, สั่งขั้นต่ำ 20 กระปุก"
                  style={{
                    border: "1px solid #D8D3C2",
                    borderRadius: 7,
                    padding: "8px 10px",
                    fontSize: 13,
                    fontFamily: "Sarabun",
                    background: "#FBFAF6",
                  }}
                />
              </label>
            </div>

            {/* Calculation Preview Box */}
            <div
              style={{
                background: "#F2F6F3",
                border: "1px solid #C9DBD0",
                borderRadius: 8,
                padding: "10px 14px",
                fontSize: 13,
                color: "#1F2D24",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
              }}
            >
              <div>
                <span style={{ color: "#5B7A63" }}>คำนวณงบสั่งซื้อรอบนี้: </span>
                <strong>
                  {reorderQtyVal || 0} {selectedItemForReorder.unit} × ฿{priceVal || 0}
                </strong>
              </div>
              <div style={{ fontSize: 15, fontWeight: 700, color: "#3C5A45" }}>
                = ฿{((Number(reorderQtyVal) || 0) * (Number(priceVal) || 0)).toLocaleString()}
              </div>
            </div>

            {/* Modal Actions */}
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 10, marginTop: 6 }}>
              <button
                type="button"
                onClick={closeReorderModal}
                disabled={saving}
                style={{
                  background: "#F5F5F0",
                  border: "1px solid #D8D3C2",
                  color: "#5B5747",
                  borderRadius: 7,
                  padding: "9px 16px",
                  fontSize: 13.5,
                  fontWeight: 600,
                  cursor: "pointer",
                  fontFamily: "Sarabun",
                }}
              >
                ยกเลิก
              </button>

              <div style={{ display: "flex", gap: 8 }}>
                {onOpenMoveWithItem && (
                  <button
                    type="button"
                    onClick={() => handleSaveReorder(true)}
                    disabled={saving}
                    title="บันทึกข้อมูลและนำทางไปยังหน้ารับเข้าสต็อกทันที"
                    style={{
                      background: "#F2F6F3",
                      border: "1px solid #C4D6C9",
                      color: "#3C5A45",
                      borderRadius: 7,
                      padding: "9px 14px",
                      fontSize: 13.5,
                      fontWeight: 600,
                      cursor: "pointer",
                      fontFamily: "Sarabun",
                      display: "flex",
                      alignItems: "center",
                      gap: 6,
                    }}
                  >
                    <span>บันทึก & ไปหน้ารับเข้าสต็อก</span>
                    <ArrowRight size={14} />
                  </button>
                )}

                <button
                  id="btn-save-reorder"
                  type="button"
                  onClick={() => handleSaveReorder(false)}
                  disabled={saving}
                  style={{
                    background: "#3C5A45",
                    color: "#FFFFFF",
                    border: "none",
                    borderRadius: 7,
                    padding: "9px 18px",
                    fontSize: 13.5,
                    fontWeight: 700,
                    cursor: saving ? "wait" : "pointer",
                    fontFamily: "Sarabun",
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    boxShadow: "0 2px 8px rgba(60, 90, 69, 0.25)",
                  }}
                >
                  <Check size={16} />
                  <span>{saving ? "กำลังบันทึก..." : "บันทึกข้อมูลการสั่งซื้อ"}</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
