import React, { useState, useMemo } from "react";
import {
  Search,
  Filter,
  X,
  ArrowDownToLine,
  ArrowUpFromLine,
  Package,
  Clock,
  AlertTriangle,
  CheckCircle2,
  ChevronDown,
  ChevronUp,
  LayoutGrid,
  List,
  ExternalLink,
  Layers,
  Sparkles,
  Building,
} from "lucide-react";
import type { InventoryState, HerbalItem, HerbalLot } from "../types";
import { lotQtyForItem, fmtDate, daysUntil, CATEGORIES } from "../utils/storage";

interface DashboardQuickSearchProps {
  inv: InventoryState;
  setTab: (t: "dashboard" | "items" | "move" | "history") => void;
  onOpenMoveWithItem?: (itemId: string, mode?: "in" | "out") => void;
  persistInv?: (next: InventoryState) => Promise<void>;
  showToast?: (msg: string) => void;
}

export function DashboardQuickSearch({
  inv,
  setTab,
  onOpenMoveWithItem,
  persistInv,
  showToast,
}: DashboardQuickSearchProps) {
  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState<string>("all");
  const [statusFilter, setStatusFilter] = useState<"all" | "low" | "near_expiry" | "normal">("all");
  const [sortBy, setSortBy] = useState<"name_asc" | "qty_asc" | "qty_desc" | "value_desc" | "expiry_asc">("name_asc");
  const [viewMode, setViewMode] = useState<"grid" | "table">("grid");
  const [expandedLotsItemId, setExpandedLotsItemId] = useState<string | null>(null);

  // Helper mapping: item lots and earliest expiry
  const itemLotsMap = useMemo(() => {
    const map = new Map<string, HerbalLot[]>();
    inv.lots.forEach((lot) => {
      if (lot.qty > 0) {
        const existing = map.get(lot.itemId) || [];
        existing.push(lot);
        map.set(lot.itemId, existing);
      }
    });

    // Sort lots by expiry ascending
    map.forEach((lots) => {
      lots.sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());
    });

    return map;
  }, [inv.lots]);

  // Pre-calculate counts for badges
  const stats = useMemo(() => {
    let lowCount = 0;
    let nearExpiryCount = 0;
    let normalCount = 0;

    inv.items.forEach((item) => {
      const current = lotQtyForItem(inv.lots, item.id);
      const isLow = current < item.minStock;
      const lots = itemLotsMap.get(item.id) || [];
      const hasNearExpiry = lots.some((l) => daysUntil(l.expiryDate) <= 90);

      if (isLow) lowCount++;
      if (hasNearExpiry) nearExpiryCount++;
      if (!isLow) normalCount++;
    });

    const categoryCounts: Record<string, number> = {};
    CATEGORIES.forEach((cat) => {
      categoryCounts[cat] = inv.items.filter((it) => it.category === cat).length;
    });

    return { lowCount, nearExpiryCount, normalCount, categoryCounts };
  }, [inv.items, inv.lots, itemLotsMap]);

  // Filtered and sorted items
  const filteredItems = useMemo(() => {
    const query = searchTerm.trim().toLowerCase();

    const filtered = inv.items.filter((item) => {
      // 1. Text Search matching name, category, supplier, notes
      const matchText =
        !query ||
        item.name.toLowerCase().includes(query) ||
        item.category.toLowerCase().includes(query) ||
        (item.supplier && item.supplier.toLowerCase().includes(query)) ||
        (item.orderNotes && item.orderNotes.toLowerCase().includes(query));

      if (!matchText) return false;

      // 2. Category Filter
      if (selectedCategory !== "all" && item.category !== selectedCategory) {
        return false;
      }

      // 3. Status Filter
      const current = lotQtyForItem(inv.lots, item.id);
      const isLow = current < item.minStock;
      const lots = itemLotsMap.get(item.id) || [];
      const hasNearExpiry = lots.some((l) => daysUntil(l.expiryDate) <= 90);

      if (statusFilter === "low" && !isLow) return false;
      if (statusFilter === "near_expiry" && !hasNearExpiry) return false;
      if (statusFilter === "normal" && isLow) return false;

      return true;
    });

    // 4. Sorting
    return filtered.sort((a, b) => {
      const qtyA = lotQtyForItem(inv.lots, a.id);
      const qtyB = lotQtyForItem(inv.lots, b.id);
      const valA = qtyA * (Number(a.price) || 0);
      const valB = qtyB * (Number(b.price) || 0);

      const earliestA = itemLotsMap.get(a.id)?.[0]?.expiryDate || "9999-12-31";
      const earliestB = itemLotsMap.get(b.id)?.[0]?.expiryDate || "9999-12-31";

      switch (sortBy) {
        case "qty_asc":
          return qtyA - qtyB;
        case "qty_desc":
          return qtyB - qtyA;
        case "value_desc":
          return valB - valA;
        case "expiry_asc":
          return new Date(earliestA).getTime() - new Date(earliestB).getTime();
        case "name_asc":
        default:
          return a.name.localeCompare(b.name, "th");
      }
    });
  }, [inv.items, inv.lots, searchTerm, selectedCategory, statusFilter, sortBy, itemLotsMap]);

  function resetFilters() {
    setSearchTerm("");
    setSelectedCategory("all");
    setStatusFilter("all");
    setSortBy("name_asc");
  }

  const isFiltered = searchTerm !== "" || selectedCategory !== "all" || statusFilter !== "all";

  return (
    <div
      id="dashboard-quick-search-section"
      style={{
        background: "#FFFFFF",
        border: "1px solid #DCE5DE",
        borderRadius: 12,
        padding: "20px 22px",
        marginBottom: 20,
        boxShadow: "0 2px 10px rgba(0, 0, 0, 0.03)",
      }}
    >
      {/* Top Header of the Search & Filter Box */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          flexWrap: "wrap",
          gap: 12,
          marginBottom: 16,
        }}
      >
        <div>
          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <div
              style={{
                background: "#3C5A45",
                color: "#FFFFFF",
                borderRadius: 8,
                padding: "6px 8px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Search size={17} />
            </div>
            <h2
              style={{
                fontFamily: "'Noto Serif Thai', serif",
                fontSize: 18,
                fontWeight: 700,
                margin: 0,
                color: "#1F2D24",
              }}
            >
              ค้นหาและตรวจสอบรายการยาในคลัง (Quick Search & Filter)
            </h2>
          </div>
          <p style={{ margin: "4px 0 0", fontSize: 13, color: "#707A72" }}>
            ค้นหาตามชื่อยา, หมวดหมู่, ผู้ผลิต หรือสถานะสต็อกเพื่อดูข้อมูลและทำรายการรับเข้า-เบิกออกได้ทันที
          </p>
        </div>

        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
          <span
            style={{
              background: "#F2F6F3",
              color: "#3C5A45",
              fontSize: 12.5,
              fontWeight: 700,
              padding: "4px 10px",
              borderRadius: 20,
              border: "1px solid #D5E2D8",
            }}
          >
            พบ {filteredItems.length} จาก {inv.items.length} รายการ
          </span>

          {isFiltered && (
            <button
              id="btn-reset-filters"
              onClick={resetFilters}
              style={{
                background: "none",
                border: "1px solid #D8D3C2",
                color: "#8A8874",
                borderRadius: 6,
                padding: "4px 8px",
                fontSize: 12,
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
                gap: 4,
                fontFamily: "Sarabun",
              }}
            >
              <X size={13} /> ล้างตัวกรอง
            </button>
          )}

          {/* View Mode Toggle */}
          <div
            style={{
              display: "flex",
              border: "1px solid #DCE5DE",
              borderRadius: 6,
              overflow: "hidden",
              background: "#F9FAF9",
            }}
          >
            <button
              id="btn-viewmode-grid"
              onClick={() => setViewMode("grid")}
              title="มุมมองการ์ด (Grid)"
              style={{
                background: viewMode === "grid" ? "#3C5A45" : "transparent",
                color: viewMode === "grid" ? "#FFFFFF" : "#6B756E",
                border: "none",
                padding: "6px 9px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
              }}
            >
              <LayoutGrid size={15} />
            </button>
            <button
              id="btn-viewmode-table"
              onClick={() => setViewMode("table")}
              title="มุมมองตาราง (Table)"
              style={{
                background: viewMode === "table" ? "#3C5A45" : "transparent",
                color: viewMode === "table" ? "#FFFFFF" : "#6B756E",
                border: "none",
                padding: "6px 9px",
                cursor: "pointer",
                display: "flex",
                alignItems: "center",
              }}
            >
              <List size={15} />
            </button>
          </div>
        </div>
      </div>

      {/* Primary Search Input Field */}
      <div style={{ position: "relative", marginBottom: 14 }}>
        <div
          style={{
            position: "absolute",
            left: 12,
            top: "50%",
            transform: "translateY(-50%)",
            color: "#8A8874",
            pointerEvents: "none",
            display: "flex",
            alignItems: "center",
          }}
        >
          <Search size={18} />
        </div>

        <input
          id="dashboard-search-input"
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder="พิมพ์ค้นหาชื่อยา, ผู้จัดจำหน่าย, สรรพคุณ หรือคำอธิบาย เช่น ฟ้าทะลายโจร, ขมิ้นชัน, ยาหอม..."
          style={{
            width: "100%",
            padding: "11px 38px 11px 40px",
            fontSize: 14,
            border: "1.5px solid #C4D5C7",
            borderRadius: 8,
            outline: "none",
            background: "#FBFCFB",
            color: "#1F2D24",
            boxSizing: "border-box",
            fontFamily: "Sarabun, sans-serif",
            transition: "border-color 0.15s ease, box-shadow 0.15s ease",
          }}
          onFocus={(e) => {
            e.currentTarget.style.borderColor = "#3C5A45";
            e.currentTarget.style.boxShadow = "0 0 0 3px rgba(60, 90, 69, 0.12)";
          }}
          onBlur={(e) => {
            e.currentTarget.style.borderColor = "#C4D5C7";
            e.currentTarget.style.boxShadow = "none";
          }}
        />

        {searchTerm && (
          <button
            onClick={() => setSearchTerm("")}
            title="ล้างคำค้นหา"
            style={{
              position: "absolute",
              right: 12,
              top: "50%",
              transform: "translateY(-50%)",
              background: "#EAE7DD",
              border: "none",
              borderRadius: "50%",
              width: 22,
              height: 22,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#5B5747",
              cursor: "pointer",
            }}
          >
            <X size={13} />
          </button>
        )}
      </div>

      {/* Category Pills Filter Bar */}
      <div style={{ marginBottom: 14 }}>
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 6,
            overflowX: "auto",
            paddingBottom: 4,
            WebkitOverflowScrolling: "touch",
          }}
        >
          <span style={{ fontSize: 12, fontWeight: 700, color: "#8A8874", marginRight: 4, whiteSpace: "nowrap" }}>
            หมวดหมู่:
          </span>

          {/* All Category Pill */}
          <button
            id="cat-filter-all"
            onClick={() => setSelectedCategory("all")}
            style={{
              padding: "5px 12px",
              borderRadius: 20,
              fontSize: 12.5,
              fontWeight: 600,
              cursor: "pointer",
              whiteSpace: "nowrap",
              fontFamily: "Sarabun, sans-serif",
              display: "inline-flex",
              alignItems: "center",
              gap: 5,
              border: selectedCategory === "all" ? "1px solid #3C5A45" : "1px solid #DFE5E0",
              background: selectedCategory === "all" ? "#3C5A45" : "#F8FAF8",
              color: selectedCategory === "all" ? "#FFFFFF" : "#4A564D",
              transition: "all 0.15s ease",
            }}
          >
            <span>ทั้งหมด</span>
            <span
              style={{
                fontSize: 11,
                padding: "1px 6px",
                borderRadius: 10,
                background: selectedCategory === "all" ? "rgba(255,255,255,0.25)" : "#EAEFEA",
                color: selectedCategory === "all" ? "#FFFFFF" : "#556358",
              }}
            >
              {inv.items.length}
            </span>
          </button>

          {/* Individual Category Pills */}
          {CATEGORIES.map((cat) => {
            const isSelected = selectedCategory === cat;
            const count = stats.categoryCounts[cat] || 0;
            return (
              <button
                key={cat}
                id={`cat-filter-${cat}`}
                onClick={() => setSelectedCategory(cat)}
                style={{
                  padding: "5px 12px",
                  borderRadius: 20,
                  fontSize: 12.5,
                  fontWeight: 600,
                  cursor: "pointer",
                  whiteSpace: "nowrap",
                  fontFamily: "Sarabun, sans-serif",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 5,
                  border: isSelected ? "1px solid #3C5A45" : "1px solid #DFE5E0",
                  background: isSelected ? "#3C5A45" : "#F8FAF8",
                  color: isSelected ? "#FFFFFF" : "#4A564D",
                  transition: "all 0.15s ease",
                }}
              >
                <span>{cat}</span>
                <span
                  style={{
                    fontSize: 11,
                    padding: "1px 6px",
                    borderRadius: 10,
                    background: isSelected ? "rgba(255,255,255,0.25)" : "#EAEFEA",
                    color: isSelected ? "#FFFFFF" : "#556358",
                  }}
                >
                  {count}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Secondary Row: Status Quick-Filter & Sort Controls */}
      <div
        style={{
          display: "flex",
          justifyContent: "space-between",
          alignItems: "center",
          flexWrap: "wrap",
          gap: 10,
          paddingTop: 10,
          borderTop: "1px solid #EDF2EE",
          marginBottom: 16,
        }}
      >
        {/* Status Filters */}
        <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
          <span style={{ fontSize: 12, fontWeight: 700, color: "#8A8874", marginRight: 4 }}>
            สถานะสต็อก:
          </span>

          <button
            onClick={() => setStatusFilter("all")}
            style={{
              padding: "4px 10px",
              borderRadius: 6,
              fontSize: 12,
              fontWeight: statusFilter === "all" ? 700 : 500,
              cursor: "pointer",
              border: statusFilter === "all" ? "1px solid #3C5A45" : "1px solid #DFE5E0",
              background: statusFilter === "all" ? "#EEF3EF" : "#FFFFFF",
              color: statusFilter === "all" ? "#3C5A45" : "#5B5747",
              fontFamily: "Sarabun",
            }}
          >
            ทั้งหมด ({inv.items.length})
          </button>

          <button
            onClick={() => setStatusFilter("low")}
            style={{
              padding: "4px 10px",
              borderRadius: 6,
              fontSize: 12,
              fontWeight: statusFilter === "low" ? 700 : 500,
              cursor: "pointer",
              border: statusFilter === "low" ? "1px solid #A83B32" : "1px solid #F1D8D6",
              background: statusFilter === "low" ? "#FBF1F0" : "#FFFFFF",
              color: "#A83B32",
              fontFamily: "Sarabun",
              display: "inline-flex",
              alignItems: "center",
              gap: 4,
            }}
          >
            <AlertTriangle size={12} /> ต่ำกว่าเกณฑ์ ({stats.lowCount})
          </button>

          <button
            onClick={() => setStatusFilter("near_expiry")}
            style={{
              padding: "4px 10px",
              borderRadius: 6,
              fontSize: 12,
              fontWeight: statusFilter === "near_expiry" ? 700 : 500,
              cursor: "pointer",
              border: statusFilter === "near_expiry" ? "1px solid #C08A2E" : "1px solid #F3E7CE",
              background: statusFilter === "near_expiry" ? "#FDF8ED" : "#FFFFFF",
              color: "#996B1E",
              fontFamily: "Sarabun",
              display: "inline-flex",
              alignItems: "center",
              gap: 4,
            }}
          >
            <Clock size={12} /> ใกล้หมดอายุ ({stats.nearExpiryCount})
          </button>

          <button
            onClick={() => setStatusFilter("normal")}
            style={{
              padding: "4px 10px",
              borderRadius: 6,
              fontSize: 12,
              fontWeight: statusFilter === "normal" ? 700 : 500,
              cursor: "pointer",
              border: statusFilter === "normal" ? "1px solid #3C5A45" : "1px solid #DFE5E0",
              background: statusFilter === "normal" ? "#EEF3EF" : "#FFFFFF",
              color: "#3C5A45",
              fontFamily: "Sarabun",
              display: "inline-flex",
              alignItems: "center",
              gap: 4,
            }}
          >
            <CheckCircle2 size={12} /> สต็อกปกติ ({stats.normalCount})
          </button>
        </div>

        {/* Sort Dropdown */}
        <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
          <span style={{ fontSize: 12, color: "#8A8874" }}>เรียงตาม:</span>
          <select
            id="select-dashboard-sort"
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value as any)}
            style={{
              border: "1px solid #D5DFD7",
              borderRadius: 6,
              padding: "5px 10px",
              fontSize: 12.5,
              background: "#FFFFFF",
              color: "#1F2D24",
              fontFamily: "Sarabun",
              cursor: "pointer",
              outline: "none",
            }}
          >
            <option value="name_asc">ชื่อยา ก-ฮ</option>
            <option value="qty_asc">สต็อกน้อยสุดก่อน (เตือนขาด)</option>
            <option value="qty_desc">สต็อกมากสุดก่อน</option>
            <option value="value_desc">มูลค่าสต็อกสูงสุด (฿)</option>
            <option value="expiry_asc">วันหมดอายุเร็วสุด</option>
          </select>
        </div>
      </div>

      {/* Results Section */}
      {inv.items.length === 0 ? (
        <div
          id="dashboard-search-no-items"
          style={{
            padding: "36px 20px",
            textAlign: "center",
            background: "#FAFBF9",
            border: "1px dashed #D6E0D8",
            borderRadius: 8,
          }}
        >
          <div style={{ color: "#8A8874", marginBottom: 8 }}>
            <Search size={28} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 15, color: "#1F2D24" }}>
            ยังไม่มีรายการยาในคลังให้ค้นหา (ข้อมูลตัวอย่างถูกล้างแล้ว)
          </div>
          <div style={{ fontSize: 13, color: "#8A8874", marginTop: 4 }}>
            สามารถเริ่มต้นเพิ่มรายการยาสมุนไพรใหม่ได้ที่เมนู "รายการยา"
          </div>
          <button
            onClick={() => setTab("items")}
            style={{
              marginTop: 14,
              background: "#3C5A45",
              color: "#FFFFFF",
              border: "none",
              borderRadius: 6,
              padding: "7px 16px",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
              fontFamily: "Sarabun",
            }}
          >
            + ไปเพิ่มรายการยา
          </button>
        </div>
      ) : filteredItems.length === 0 ? (
        <div
          style={{
            padding: "36px 20px",
            textAlign: "center",
            background: "#FAFBF9",
            border: "1px dashed #D6E0D8",
            borderRadius: 8,
          }}
        >
          <div style={{ color: "#8A8874", marginBottom: 8 }}>
            <Search size={32} />
          </div>
          <div style={{ fontWeight: 700, fontSize: 15, color: "#1F2D24" }}>
            ไม่พบรายการยาที่ตรงกับเงื่อนไขการค้นหา
          </div>
          <div style={{ fontSize: 13, color: "#8A8874", marginTop: 4 }}>
            {searchTerm && `คำค้นหา "${searchTerm}"`} {selectedCategory !== "all" && `หมวดหมู่ "${selectedCategory}"`}
          </div>
          <button
            onClick={resetFilters}
            style={{
              marginTop: 14,
              background: "#3C5A45",
              color: "#FFFFFF",
              border: "none",
              borderRadius: 6,
              padding: "7px 16px",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
              fontFamily: "Sarabun",
            }}
          >
            ล้างตัวกรองและแสดงยาทั้งหมด
          </button>
        </div>
      ) : viewMode === "grid" ? (
        /* Grid Card View */
        <div
          id="dashboard-items-grid"
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fill, minmax(310px, 1fr))",
            gap: 14,
          }}
        >
          {filteredItems.map((item) => {
            const current = lotQtyForItem(inv.lots, item.id);
            const isLow = current < item.minStock;
            const isZero = current === 0;
            const lots = itemLotsMap.get(item.id) || [];
            const earliestLot = lots[0];
            const daysLeft = earliestLot ? daysUntil(earliestLot.expiryDate) : null;
            const isNearExpiry = daysLeft !== null && daysLeft <= 90;
            const isExpired = daysLeft !== null && daysLeft < 0;
            const totalItemValue = current * (Number(item.price) || 0);
            const isLotsExpanded = expandedLotsItemId === item.id;
            const stockRatio = item.minStock > 0 ? current / item.minStock : 1;

            return (
              <div
                key={item.id}
                id={`quick-item-card-${item.id}`}
                style={{
                  background: "#FFFFFF",
                  border: isLow ? "1.5px solid #F1C3BF" : "1px solid #E1E8E2",
                  borderRadius: 10,
                  padding: "14px 16px",
                  display: "flex",
                  flexDirection: "column",
                  justifyContent: "space-between",
                  boxShadow: isLow ? "0 2px 8px rgba(168, 59, 50, 0.05)" : "0 1px 4px rgba(0, 0, 0, 0.02)",
                  transition: "all 0.15s ease",
                }}
              >
                <div>
                  {/* Item Header */}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", gap: 8 }}>
                    <div style={{ flex: 1 }}>
                      <div style={{ fontWeight: 700, fontSize: 15, color: "#1F2D24", lineHeight: 1.3 }}>
                        {item.name}
                      </div>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 4, flexWrap: "wrap" }}>
                        <span
                          style={{
                            background: "#F2F5F2",
                            color: "#3C5A45",
                            fontSize: 11,
                            fontWeight: 600,
                            padding: "2px 7px",
                            borderRadius: 4,
                          }}
                        >
                          {item.category}
                        </span>

                        {isZero ? (
                          <span
                            style={{
                              background: "#FBEDEB",
                              color: "#A83B32",
                              fontSize: 11,
                              fontWeight: 700,
                              padding: "2px 6px",
                              borderRadius: 4,
                            }}
                          >
                            หมดสต็อก
                          </span>
                        ) : isLow ? (
                          <span
                            style={{
                              background: "#FDF1F0",
                              color: "#A83B32",
                              fontSize: 11,
                              fontWeight: 700,
                              padding: "2px 6px",
                              borderRadius: 4,
                              display: "inline-flex",
                              alignItems: "center",
                              gap: 3,
                            }}
                          >
                            <AlertTriangle size={11} /> ต่ำกว่าเกณฑ์
                          </span>
                        ) : (
                          <span
                            style={{
                              background: "#EDF5EF",
                              color: "#2E693D",
                              fontSize: 11,
                              fontWeight: 600,
                              padding: "2px 6px",
                              borderRadius: 4,
                            }}
                          >
                            ปกติ
                          </span>
                        )}

                        {isNearExpiry && (
                          <span
                            style={{
                              background: isExpired ? "#FBEDEB" : "#FEF7E8",
                              color: isExpired ? "#A83B32" : "#996B1E",
                              fontSize: 11,
                              fontWeight: 700,
                              padding: "2px 6px",
                              borderRadius: 4,
                              display: "inline-flex",
                              alignItems: "center",
                              gap: 3,
                            }}
                          >
                            <Clock size={11} /> {isExpired ? "มีล็อตหมดอายุ" : `EXP ใน ${daysLeft} วัน`}
                          </span>
                        )}
                      </div>
                    </div>

                    {/* Stock Value */}
                    <div style={{ textAlign: "right", flexShrink: 0 }}>
                      <div style={{ fontSize: 11, color: "#8A8874" }}>มูลค่าสต็อก</div>
                      <div style={{ fontSize: 13.5, fontWeight: 700, color: "#3C5A45" }}>
                        ฿{totalItemValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                      </div>
                    </div>
                  </div>

                  {/* Stock Level Bar & Counts */}
                  <div style={{ marginTop: 10, marginBottom: 10 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12.5, marginBottom: 4 }}>
                      <span>
                        คงเหลือ:{" "}
                        <strong style={{ fontSize: 14, color: isLow ? "#A83B32" : "#1F2D24" }}>
                          {current}
                        </strong>{" "}
                        <span style={{ color: "#6C7A70" }}>{item.unit}</span>
                      </span>
                      <span style={{ color: "#8A8874", fontSize: 12 }}>
                        เกณฑ์ขั้นต่ำ: <strong>{item.minStock}</strong> {item.unit}
                      </span>
                    </div>

                    <div style={{ width: "100%", height: 6, background: "#EAE7DD", borderRadius: 3, overflow: "hidden" }}>
                      <div
                        style={{
                          width: `${Math.min(100, Math.round(stockRatio * 100))}%`,
                          height: "100%",
                          background: isZero ? "#A83B32" : isLow ? "#C08A2E" : "#3C5A45",
                          borderRadius: 3,
                          transition: "width 0.3s ease",
                        }}
                      />
                    </div>
                  </div>

                  {/* Lot & Procurement Information Box */}
                  <div
                    style={{
                      background: "#F9FAF8",
                      border: "1px solid #E6ECE7",
                      borderRadius: 7,
                      padding: "8px 10px",
                      fontSize: 12,
                      display: "flex",
                      flexDirection: "column",
                      gap: 4,
                      marginBottom: 10,
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between" }}>
                      <span style={{ color: "#77857A", display: "flex", alignItems: "center", gap: 4 }}>
                        <Layers size={12} color="#5B7A63" /> ล็อตคงคลัง:
                      </span>
                      <span style={{ fontWeight: 600, color: "#1F2D24" }}>
                        {lots.length > 0 ? `${lots.length} ล็อต` : "ไม่มีล็อตยา"}
                      </span>
                    </div>

                    {earliestLot && (
                      <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <span style={{ color: "#77857A", display: "flex", alignItems: "center", gap: 4 }}>
                          <Clock size={12} color="#8A8874" /> หมดอายุเร็วสุด:
                        </span>
                        <span
                          style={{
                            color: isExpired ? "#A83B32" : isNearExpiry ? "#996B1E" : "#1F2D24",
                            fontWeight: isNearExpiry ? 700 : 500,
                          }}
                        >
                          {fmtDate(earliestLot.expiryDate)} {daysLeft !== null && `(${daysLeft} วัน)`}
                        </span>
                      </div>
                    )}

                    {item.supplier && (
                      <div style={{ display: "flex", justifyContent: "space-between" }}>
                        <span style={{ color: "#77857A", display: "flex", alignItems: "center", gap: 4 }}>
                          <Building size={12} color="#8A8874" /> ผู้จัดจำหน่าย:
                        </span>
                        <span style={{ color: "#1F2D24", maxWidth: 160, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          {item.supplier}
                        </span>
                      </div>
                    )}
                  </div>

                  {/* Expandable Lots Detail Table */}
                  {isLotsExpanded && (
                    <div
                      style={{
                        background: "#FFFFFF",
                        border: "1px solid #DCE5DE",
                        borderRadius: 6,
                        padding: "8px 10px",
                        marginBottom: 10,
                        fontSize: 11.5,
                      }}
                    >
                      <div style={{ fontWeight: 700, color: "#3C5A45", marginBottom: 6, display: "flex", justifyContent: "space-between" }}>
                        <span>รายละเอียดทุกล็อต ({item.name})</span>
                        <span style={{ color: "#8A8874" }}>{lots.length} รายการ</span>
                      </div>
                      {lots.length === 0 ? (
                        <div style={{ color: "#8A8874", textAlign: "center", padding: "6px 0" }}>ไม่มีล็อตคงเหลือ</div>
                      ) : (
                        <div style={{ display: "flex", flexDirection: "column", gap: 5 }}>
                          {lots.map((l) => {
                            const d = daysUntil(l.expiryDate);
                            return (
                              <div
                                key={l.id}
                                style={{
                                  display: "flex",
                                  justifyContent: "space-between",
                                  alignItems: "center",
                                  padding: "4px 6px",
                                  background: d < 0 ? "#FDEEEE" : d <= 90 ? "#FDF8EE" : "#F8FAF8",
                                  borderRadius: 4,
                                  border: "1px solid #EBEFEA",
                                }}
                              >
                                <div>
                                  <strong style={{ color: "#1F2D24" }}>ล็อต {l.lotNo || "-"}</strong>
                                  <div style={{ color: "#8A8874", fontSize: 11 }}>
                                    รับเข้า: {fmtDate(l.receivedDate)}
                                  </div>
                                </div>
                                <div style={{ textAlign: "right" }}>
                                  <div style={{ fontWeight: 700, color: "#1F2D24" }}>
                                    {l.qty} {item.unit}
                                  </div>
                                  <div style={{ color: d < 0 ? "#A83B32" : d <= 90 ? "#996B1E" : "#5B7A63", fontSize: 11 }}>
                                    EXP: {fmtDate(l.expiryDate)}
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}
                    </div>
                  )}
                </div>

                {/* Card Action Buttons */}
                <div>
                  <div style={{ display: "flex", gap: 6, marginBottom: 6 }}>
                    {/* Quick Receive Button */}
                    {onOpenMoveWithItem && (
                      <button
                        id={`btn-quick-in-${item.id}`}
                        onClick={() => onOpenMoveWithItem(item.id, "in")}
                        title="ทำรายการรับเข้าสต็อก"
                        style={{
                          flex: 1,
                          background: "#EEF4F0",
                          border: "1px solid #C4D7C8",
                          color: "#2E583A",
                          borderRadius: 6,
                          padding: "7px 8px",
                          fontSize: 12,
                          fontWeight: 700,
                          cursor: "pointer",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          gap: 4,
                          fontFamily: "Sarabun, sans-serif",
                          transition: "all 0.15s ease",
                        }}
                      >
                        <ArrowDownToLine size={13} />
                        <span>รับเข้า</span>
                      </button>
                    )}

                    {/* Quick Issue Button */}
                    {onOpenMoveWithItem && (
                      <button
                        id={`btn-quick-out-${item.id}`}
                        onClick={() => onOpenMoveWithItem(item.id, "out")}
                        disabled={isZero}
                        title={isZero ? "ไม่มียาในสต็อกให้เบิก" : "ทำรายการเบิกจ่ายออกจากสต็อก"}
                        style={{
                          flex: 1,
                          background: isZero ? "#F5F5F0" : "#FFF5F4",
                          border: isZero ? "1px solid #E0DED4" : "1px solid #F1C3BF",
                          color: isZero ? "#9E9C8D" : "#A83B32",
                          borderRadius: 6,
                          padding: "7px 8px",
                          fontSize: 12,
                          fontWeight: 700,
                          cursor: isZero ? "not-allowed" : "pointer",
                          display: "flex",
                          alignItems: "center",
                          justifyContent: "center",
                          gap: 4,
                          fontFamily: "Sarabun, sans-serif",
                          transition: "all 0.15s ease",
                        }}
                      >
                        <ArrowUpFromLine size={13} />
                        <span>เบิกออก</span>
                      </button>
                    )}
                  </div>

                  {/* Toggle Lots & Details */}
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", pt: 2 }}>
                    <button
                      onClick={() => setExpandedLotsItemId(isLotsExpanded ? null : item.id)}
                      style={{
                        background: "none",
                        border: "none",
                        color: "#5B7A63",
                        fontSize: 11.5,
                        fontWeight: 600,
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: 3,
                        padding: 0,
                      }}
                    >
                      {isLotsExpanded ? (
                        <>
                          <ChevronUp size={13} /> ซ่อนล็อตยา
                        </>
                      ) : (
                        <>
                          <ChevronDown size={13} /> ดูทุกล็อต ({lots.length})
                        </>
                      )}
                    </button>

                    <button
                      onClick={() => setTab("items")}
                      style={{
                        background: "none",
                        border: "none",
                        color: "#8A8874",
                        fontSize: 11.5,
                        cursor: "pointer",
                        display: "flex",
                        alignItems: "center",
                        gap: 2,
                        padding: 0,
                      }}
                    >
                      <span>ดูในคลัง</span>
                      <ExternalLink size={11} />
                    </button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      ) : (
        /* Compact Table View */
        <div style={{ overflowX: "auto", border: "1px solid #E1E8E2", borderRadius: 8 }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13, textAlign: "left" }}>
            <thead>
              <tr style={{ background: "#F5F8F6", borderBottom: "1px solid #DCE5DE", color: "#4A564D" }}>
                <th style={{ padding: "10px 14px", fontWeight: 700 }}>ชื่อยาสมุนไพร</th>
                <th style={{ padding: "10px 12px", fontWeight: 700 }}>หมวดหมู่</th>
                <th style={{ padding: "10px 12px", fontWeight: 700 }}>สต็อกคงเหลือ / เกณฑ์</th>
                <th style={{ padding: "10px 12px", fontWeight: 700 }}>สถานะ</th>
                <th style={{ padding: "10px 12px", fontWeight: 700 }}>ล็อตหมดอายุเร็วสุด</th>
                <th style={{ padding: "10px 12px", fontWeight: 700, textAlign: "right" }}>มูลค่าสต็อก (฿)</th>
                <th style={{ padding: "10px 14px", fontWeight: 700, textAlign: "center" }}>ทำรายการด่วน</th>
              </tr>
            </thead>
            <tbody>
              {filteredItems.map((item, idx) => {
                const current = lotQtyForItem(inv.lots, item.id);
                const isLow = current < item.minStock;
                const isZero = current === 0;
                const lots = itemLotsMap.get(item.id) || [];
                const earliest = lots[0];
                const daysLeft = earliest ? daysUntil(earliest.expiryDate) : null;
                const isNearExpiry = daysLeft !== null && daysLeft <= 90;
                const isExpired = daysLeft !== null && daysLeft < 0;
                const totalItemValue = current * (Number(item.price) || 0);

                return (
                  <tr
                    key={item.id}
                    style={{
                      borderBottom: "1px solid #EBEFEA",
                      background: idx % 2 === 0 ? "#FFFFFF" : "#FCFDFC",
                    }}
                  >
                    <td style={{ padding: "10px 14px" }}>
                      <div style={{ fontWeight: 700, color: "#1F2D24" }}>{item.name}</div>
                      {item.supplier && (
                        <div style={{ fontSize: 11, color: "#8A8874" }}>
                          ผู้ผลิต: {item.supplier}
                        </div>
                      )}
                    </td>
                    <td style={{ padding: "10px 12px" }}>
                      <span
                        style={{
                          background: "#F2F5F2",
                          color: "#3C5A45",
                          fontSize: 11,
                          fontWeight: 600,
                          padding: "2px 6px",
                          borderRadius: 4,
                        }}
                      >
                        {item.category}
                      </span>
                    </td>
                    <td style={{ padding: "10px 12px" }}>
                      <strong style={{ color: isLow ? "#A83B32" : "#1F2D24" }}>{current}</strong>
                      <span style={{ color: "#77857A", fontSize: 12 }}> / {item.minStock} {item.unit}</span>
                    </td>
                    <td style={{ padding: "10px 12px" }}>
                      {isZero ? (
                        <span style={{ color: "#A83B32", fontWeight: 700, fontSize: 12 }}>หมดสต็อก</span>
                      ) : isLow ? (
                        <span style={{ color: "#A83B32", fontWeight: 700, fontSize: 12, display: "flex", alignItems: "center", gap: 3 }}>
                          <AlertTriangle size={12} /> ต่ำกว่าเกณฑ์
                        </span>
                      ) : (
                        <span style={{ color: "#2E693D", fontWeight: 600, fontSize: 12 }}>ปกติ</span>
                      )}
                    </td>
                    <td style={{ padding: "10px 12px", fontSize: 12 }}>
                      {earliest ? (
                        <div>
                          <span style={{ color: isExpired ? "#A83B32" : isNearExpiry ? "#996B1E" : "#1F2D24", fontWeight: isNearExpiry ? 700 : 500 }}>
                            {fmtDate(earliest.expiryDate)}
                          </span>
                          <span style={{ color: "#8A8874", fontSize: 11, marginLeft: 4 }}>
                            ({daysLeft} วัน)
                          </span>
                        </div>
                      ) : (
                        <span style={{ color: "#B0ADA1" }}>-</span>
                      )}
                    </td>
                    <td style={{ padding: "10px 12px", textAlign: "right", fontWeight: 700, color: "#3C5A45" }}>
                      ฿{totalItemValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                    </td>
                    <td style={{ padding: "10px 14px", textAlign: "center" }}>
                      <div style={{ display: "flex", justifyContent: "center", gap: 6 }}>
                        {onOpenMoveWithItem && (
                          <>
                            <button
                              onClick={() => onOpenMoveWithItem(item.id, "in")}
                              title="รับเข้าสต็อก"
                              style={{
                                background: "#EEF4F0",
                                border: "1px solid #C4D7C8",
                                color: "#2E583A",
                                borderRadius: 5,
                                padding: "4px 8px",
                                fontSize: 11.5,
                                fontWeight: 600,
                                cursor: "pointer",
                                display: "inline-flex",
                                alignItems: "center",
                                gap: 3,
                              }}
                            >
                              <ArrowDownToLine size={12} /> รับเข้า
                            </button>
                            <button
                              onClick={() => onOpenMoveWithItem(item.id, "out")}
                              disabled={isZero}
                              title={isZero ? "สต็อกว่าง" : "เบิกจ่ายออก"}
                              style={{
                                background: isZero ? "#F5F5F0" : "#FFF5F4",
                                border: isZero ? "1px solid #E0DED4" : "1px solid #F1C3BF",
                                color: isZero ? "#9E9C8D" : "#A83B32",
                                borderRadius: 5,
                                padding: "4px 8px",
                                fontSize: 11.5,
                                fontWeight: 600,
                                cursor: isZero ? "not-allowed" : "pointer",
                                display: "inline-flex",
                                alignItems: "center",
                                gap: 3,
                              }}
                            >
                              <ArrowUpFromLine size={12} /> เบิกออก
                            </button>
                          </>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
