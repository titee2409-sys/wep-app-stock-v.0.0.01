import React from "react";

export interface PanelProps {
  accent?: string;
  children: React.ReactNode;
  style?: React.CSSProperties;
  className?: string;
  id?: string;
}

export function Panel({
  accent = "#3C5A45",
  children,
  style,
  className,
  id,
}: PanelProps) {
  return (
    <div
      id={id}
      className={className}
      style={{
        background: "#FFFFFF",
        borderRadius: 10,
        border: "1px solid #E4E0D2",
        borderLeft: `4px solid ${accent}`,
        padding: "18px 20px",
        boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
        ...style,
      }}
    >
      {children}
    </div>
  );
}

export function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6, fontSize: 14 }}>
      <span style={{ color: "#5B5747", fontWeight: 600 }}>{label}</span>
      {children}
    </label>
  );
}

export const inputStyle: React.CSSProperties = {
  border: "1px solid #D8D3C2",
  borderRadius: 7,
  padding: "9px 11px",
  fontSize: 14,
  fontFamily: "Sarabun, sans-serif",
  background: "#FBFAF6",
  color: "#1F2D24",
  outline: "none",
  width: "100%",
  boxSizing: "border-box",
};

export function Btn({
  children,
  onClick,
  variant = "primary",
  type = "button",
  disabled,
  style,
  id,
}: {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: "primary" | "ghost" | "danger" | "subtle";
  type?: "button" | "submit" | "reset";
  disabled?: boolean;
  style?: React.CSSProperties;
  id?: string;
}) {
  const variants = {
    primary: { background: "#3C5A45", color: "#fff", border: "1px solid #3C5A45" },
    ghost: { background: "transparent", color: "#3C5A45", border: "1px solid #3C5A45" },
    danger: { background: "#fff", color: "#A83B32", border: "1px solid #E4B7B0" },
    subtle: { background: "#EEF1E8", color: "#3C5A45", border: "1px solid #EEF1E8" },
  };
  return (
    <button
      id={id}
      type={type}
      disabled={disabled}
      onClick={onClick}
      style={{
        ...variants[variant],
        borderRadius: 7,
        padding: "9px 14px",
        fontSize: 14,
        fontWeight: 600,
        fontFamily: "Sarabun, sans-serif",
        cursor: disabled ? "not-allowed" : "pointer",
        opacity: disabled ? 0.5 : 1,
        display: "inline-flex",
        alignItems: "center",
        justifyContent: "center",
        gap: 6,
        transition: "all .15s ease",
        whiteSpace: "nowrap",
        ...style,
      }}
    >
      {children}
    </button>
  );
}
