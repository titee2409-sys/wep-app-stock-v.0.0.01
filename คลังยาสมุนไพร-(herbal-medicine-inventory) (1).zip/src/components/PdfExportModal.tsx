import React, { useState, useRef } from "react";
import {
  FileDown,
  Printer,
  X,
  AlertTriangle,
  Clock,
  CheckCircle,
  FileText,
  Building,
  Calendar,
  User,
  Package,
  Layers,
  ChevronDown,
  ShieldAlert,
} from "lucide-react";
import type { HerbalItem, HerbalLot, InventoryState } from "../types";
import { lotQtyForItem, daysUntil, fmtDate } from "../utils/storage";
import { exportElementToPdf } from "../utils/pdfExport";

interface PdfExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  inv: InventoryState;
  lowStockItems: HerbalItem[];
  nearExpiryLots: HerbalLot[];
  showToast: (msg: string) => void;
  staffName?: string;
}

export function PdfExportModal({
  isOpen,
  onClose,
  inv,
  lowStockItems,
  nearExpiryLots,
  showToast,
  staffName = "เภสัชกร ประจำการ",
}: PdfExportModalProps) {
  const [includeLowStock, setIncludeLowStock] = useState(true);
  const [includeNearExpiry, setIncludeNearExpiry] = useState(true);
  const [includeSignatures, setIncludeSignatures] = useState(true);
  const [customRemarks, setCustomRemarks] = useState(
    "รายงานสรุปเพื่อประกอบการพิจารณาจัดซื้อทดแทนและวางแผนเบิกจ่ายยาสมุนไพรประจำงวด"
  );
  const [isExporting, setIsExporting] = useState(false);
  const [exportStatus, setExportStatus] = useState("");

  const printAreaRef = useRef<HTMLDivElement>(null);

  if (!isOpen) return null;

  // Calculate totals
  const totalLowStockCount = lowStockItems.length;
  const totalNearExpiryCount = nearExpiryLots.length;
  const expiredCount = nearExpiryLots.filter((l) => daysUntil(l.expiryDate) < 0).length;

  // Estimated reorder budget
  const estimatedReorderCost = lowStockItems.reduce((acc, it) => {
    const current = lotQtyForItem(inv.lots, it.id);
    const deficit = Math.max(0, it.minStock - current);
    const reorderQty = it.reorderQty && it.reorderQty > 0 ? it.reorderQty : deficit;
    return acc + reorderQty * (Number(it.price) || 0);
  }, 0);

  const currentDateFormatted = new Date().toLocaleDateString("th-TH", {
    day: "numeric",
    month: "long",
    year: "numeric",
  });

  const currentTimeFormatted = new Date().toLocaleTimeString("th-TH", {
    hour: "2-digit",
    minute: "2-digit",
  }) + " น.";

  async function handleExportPdf() {
    setIsExporting(true);
    setExportStatus("กำลังเตรียมข้อมูลเอกสาร...");
    try {
      const todayStr = new Date().toISOString().slice(0, 10);
      const filename = `รายงานคลังยาสมุนไพร_สต็อกต่ำและใกล้หมดอายุ_${todayStr}.pdf`;

      await exportElementToPdf("pdf-report-printable-content", {
        filename,
        onProgress: (status) => setExportStatus(status),
      });

      showToast("ส่งออกรายงาน PDF สต็อกต่ำและใกล้หมดอายุสำเร็จ");
      onClose();
    } catch (err) {
      console.error("PDF export error", err);
      showToast("เกิดข้อผิดพลาดในการสร้างไฟล์ PDF");
    } finally {
      setIsExporting(false);
      setExportStatus("");
    }
  }

  function handlePrint() {
    window.print();
  }

  return (
    <div
      id="modal-pdf-export-overlay"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: "rgba(0, 0, 0, 0.65)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1100,
        padding: "16px",
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget && !isExporting) onClose();
      }}
    >
      <div
        style={{
          background: "#FFFFFF",
          borderRadius: 12,
          width: "100%",
          maxWidth: 920,
          maxHeight: "92vh",
          display: "flex",
          flexDirection: "column",
          boxShadow: "0 20px 50px rgba(0, 0, 0, 0.35)",
          overflow: "hidden",
        }}
      >
        {/* Modal Top Control Header */}
        <div
          style={{
            padding: "16px 22px",
            background: "#2D4834",
            color: "#FFFFFF",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 12,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div
              style={{
                background: "rgba(255, 255, 255, 0.15)",
                padding: "8px",
                borderRadius: 8,
                display: "flex",
              }}
            >
              <FileDown size={22} color="#FFFFFF" />
            </div>
            <div>
              <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, fontFamily: "'Noto Serif Thai', serif" }}>
                ส่งออกรายงาน PDF คลังยาสมุนไพร
              </h2>
              <div style={{ fontSize: 12, opacity: 0.85 }}>
                รายงานสต็อกต่ำกว่าเกณฑ์ (Low Stock) และยาสมุนไพรใกล้หมดอายุ (Near Expiry)
              </div>
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button
              id="btn-download-pdf-now"
              onClick={handleExportPdf}
              disabled={isExporting || (!includeLowStock && !includeNearExpiry)}
              style={{
                background: "#E8F0EA",
                color: "#1F3826",
                border: "none",
                borderRadius: 6,
                padding: "8px 18px",
                fontSize: 13.5,
                fontWeight: 700,
                cursor: isExporting ? "wait" : "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                boxShadow: "0 2px 6px rgba(0, 0, 0, 0.2)",
                fontFamily: "Sarabun, sans-serif",
              }}
            >
              <FileDown size={16} />
              <span>{isExporting ? exportStatus || "กำลังสร้าง PDF..." : "ดาวน์โหลดไฟล์ PDF"}</span>
            </button>

            <button
              id="btn-print-report-now"
              onClick={handlePrint}
              style={{
                background: "rgba(255, 255, 255, 0.15)",
                color: "#FFFFFF",
                border: "1px solid rgba(255, 255, 255, 0.3)",
                borderRadius: 6,
                padding: "8px 14px",
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                fontFamily: "Sarabun, sans-serif",
              }}
              title="พิมพ์เอกสารออกเครื่องพิมพ์โดยตรง"
            >
              <Printer size={15} />
              <span>พิมพ์</span>
            </button>

            <button
              id="btn-close-pdf-modal"
              onClick={onClose}
              disabled={isExporting}
              style={{
                background: "transparent",
                border: "none",
                color: "#FFFFFF",
                cursor: "pointer",
                padding: "4px",
                opacity: 0.8,
              }}
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Options Toolbar */}
        <div
          style={{
            padding: "10px 20px",
            background: "#F7F5EE",
            borderBottom: "1px solid #E5E0D2",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: 12,
            fontSize: 12.5,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
            <span style={{ fontWeight: 700, color: "#2D4834" }}>ส่วนเนื้อหาในรายงาน:</span>
            <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
              <input
                id="checkbox-include-low-stock"
                type="checkbox"
                checked={includeLowStock}
                onChange={(e) => setIncludeLowStock(e.target.checked)}
                style={{ accentColor: "#2D4834", cursor: "pointer" }}
              />
              <span>รายงานสต็อกต่ำ ({lowStockItems.length} รายการ)</span>
            </label>

            <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
              <input
                id="checkbox-include-near-expiry"
                type="checkbox"
                checked={includeNearExpiry}
                onChange={(e) => setIncludeNearExpiry(e.target.checked)}
                style={{ accentColor: "#2D4834", cursor: "pointer" }}
              />
              <span>รายงานใกล้หมดอายุ ({nearExpiryLots.length} ล็อต)</span>
            </label>

            <label style={{ display: "inline-flex", alignItems: "center", gap: 6, cursor: "pointer" }}>
              <input
                id="checkbox-include-signatures"
                type="checkbox"
                checked={includeSignatures}
                onChange={(e) => setIncludeSignatures(e.target.checked)}
                style={{ accentColor: "#2D4834", cursor: "pointer" }}
              />
              <span>ช่องลงลายมือชื่อ</span>
            </label>
          </div>

          <div style={{ fontSize: 11.5, color: "#746E5D" }}>
            * ตารางเอกสารจัดรูปแบบรองรับขนาดมาตรฐานกระดาษ A4
          </div>
        </div>

        {/* Report Preview Body (Scrollable container, with printable A4 sheet inside) */}
        <div
          style={{
            flex: 1,
            overflowY: "auto",
            padding: "20px",
            background: "#EBE8DF",
            display: "flex",
            justifyContent: "center",
          }}
        >
          {/* A4 Sheet Container */}
          <div
            id="pdf-report-printable-content"
            ref={printAreaRef}
            style={{
              background: "#FFFFFF",
              width: "100%",
              maxWidth: 780,
              padding: "36px 40px",
              boxShadow: "0 4px 16px rgba(0, 0, 0, 0.08)",
              borderRadius: 6,
              color: "#1F2D24",
              fontFamily: "'Sarabun', 'Noto Serif Thai', sans-serif",
              boxSizing: "border-box",
            }}
          >
            {/* Report Header */}
            <div
              style={{
                borderBottom: "2px solid #2D4834",
                paddingBottom: 14,
                marginBottom: 18,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
              }}
            >
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, color: "#2D4834", marginBottom: 4 }}>
                  <Building size={20} />
                  <span style={{ fontWeight: 700, fontSize: 14, textTransform: "uppercase", letterSpacing: "0.5px" }}>
                    ระบบบริหารจัดการคลังยาสมุนไพรและเภสัชกรรมแผนไทย
                  </span>
                </div>
                <h1
                  style={{
                    margin: "2px 0 6px",
                    fontSize: 22,
                    fontWeight: 800,
                    color: "#1A2E20",
                    fontFamily: "'Noto Serif Thai', serif",
                  }}
                >
                  รายงานสถานะแจ้งเตือนสต็อกต่ำกว่าเกณฑ์และยาใกล้หมดอายุ
                </h1>
                <div style={{ fontSize: 12.5, color: "#5F6C62" }}>
                  Herbal Medicine Inventory Management System · Alert & Expiry Status Report
                </div>
              </div>

              <div style={{ textAlign: "right", fontSize: 12, color: "#5F6C62" }}>
                <div>
                  วันที่พิมพ์รายงาน: <b>{currentDateFormatted}</b>
                </div>
                <div>
                  เวลา: <b>{currentTimeFormatted}</b>
                </div>
                <div>
                  ผู้พิมพ์รายงาน: <b>{staffName}</b>
                </div>
              </div>
            </div>

            {/* KPI Summary Strip */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(4, 1fr)",
                gap: 12,
                marginBottom: 20,
              }}
            >
              <div
                style={{
                  background: "#FBF3F2",
                  border: "1px solid #F1C3BF",
                  borderRadius: 6,
                  padding: "10px 12px",
                  textAlign: "center",
                }}
              >
                <div style={{ fontSize: 11, color: "#8E342C", fontWeight: 600 }}>สต็อกต่ำกว่าเกณฑ์</div>
                <div style={{ fontSize: 22, fontWeight: 800, color: "#A83B32", marginTop: 2 }}>
                  {totalLowStockCount} <span style={{ fontSize: 12, fontWeight: 500 }}>รายการ</span>
                </div>
              </div>

              <div
                style={{
                  background: "#FBF7ED",
                  border: "1px solid #EDDCB2",
                  borderRadius: 6,
                  padding: "10px 12px",
                  textAlign: "center",
                }}
              >
                <div style={{ fontSize: 11, color: "#87601B", fontWeight: 600 }}>ใกล้หมดอายุ (≤90 วัน)</div>
                <div style={{ fontSize: 22, fontWeight: 800, color: "#C08A2E", marginTop: 2 }}>
                  {totalNearExpiryCount} <span style={{ fontSize: 12, fontWeight: 500 }}>ล็อต</span>
                </div>
              </div>

              <div
                style={{
                  background: expiredCount > 0 ? "#FBEDEB" : "#F6F8F5",
                  border: expiredCount > 0 ? "1px solid #F1C3BF" : "1px solid #D7E3D9",
                  borderRadius: 6,
                  padding: "10px 12px",
                  textAlign: "center",
                }}
              >
                <div style={{ fontSize: 11, color: expiredCount > 0 ? "#A83B32" : "#3C5A45", fontWeight: 600 }}>
                  หมดอายุแล้ว
                </div>
                <div
                  style={{
                    fontSize: 22,
                    fontWeight: 800,
                    color: expiredCount > 0 ? "#A83B32" : "#3C5A45",
                    marginTop: 2,
                  }}
                >
                  {expiredCount} <span style={{ fontSize: 12, fontWeight: 500 }}>ล็อต</span>
                </div>
              </div>

              <div
                style={{
                  background: "#EEF3EF",
                  border: "1px solid #CCDDCF",
                  borderRadius: 6,
                  padding: "10px 12px",
                  textAlign: "center",
                }}
              >
                <div style={{ fontSize: 11, color: "#2E5739", fontWeight: 600 }}>ประมาณการงบสั่งซื้อ</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: "#1F4228", marginTop: 4 }}>
                  ฿{estimatedReorderCost.toLocaleString(undefined, { minimumFractionDigits: 0, maximumFractionDigits: 0 })}
                </div>
              </div>
            </div>

            {/* Custom Remarks */}
            {customRemarks && (
              <div
                style={{
                  background: "#F9F8F4",
                  borderLeft: "3px solid #2D4834",
                  padding: "8px 12px",
                  fontSize: 12,
                  color: "#5B5747",
                  marginBottom: 18,
                }}
              >
                <b>หมายเหตุรายงาน:</b> {customRemarks}
              </div>
            )}

            {/* Section 1: Low Stock Items */}
            {includeLowStock && (
              <div style={{ marginBottom: 24 }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 15,
                    fontWeight: 700,
                    color: "#A83B32",
                    marginBottom: 8,
                    borderBottom: "1.5px solid #F1C3BF",
                    paddingBottom: 4,
                  }}
                >
                  <AlertTriangle size={16} />
                  <span>1. รายการยาสมุนไพรที่สต็อกต่ำกว่าเกณฑ์ขั้นต่ำ (Low Stock Items)</span>
                  <span style={{ fontSize: 12, color: "#8E342C", fontWeight: 500 }}>
                    ({lowStockItems.length} รายการ)
                  </span>
                </div>

                {lowStockItems.length === 0 ? (
                  <div
                    style={{
                      padding: "12px",
                      textAlign: "center",
                      fontSize: 12.5,
                      color: "#3C5A45",
                      background: "#F4F8F5",
                      borderRadius: 4,
                    }}
                  >
                    ✓ ยอดเยี่ยม! ไม่มีรายการยาที่สต็อกต่ำกว่าเกณฑ์ในขณะนี้
                  </div>
                ) : (
                  <table
                    style={{
                      width: "100%",
                      borderCollapse: "collapse",
                      fontSize: 11.5,
                      marginTop: 4,
                    }}
                  >
                    <thead>
                      <tr style={{ background: "#F6F3EA", borderBottom: "1.5px solid #DCD7C8", textAlign: "left" }}>
                        <th style={{ padding: "6px 8px", width: 28 }}>#</th>
                        <th style={{ padding: "6px 8px" }}>ชื่อยาสมุนไพร</th>
                        <th style={{ padding: "6px 8px", width: 85 }}>หมวดหมู่</th>
                        <th style={{ padding: "6px 8px", textAlign: "right", width: 65 }}>คงเหลือ</th>
                        <th style={{ padding: "6px 8px", textAlign: "right", width: 65 }}>เกณฑ์ขั้นต่ำ</th>
                        <th style={{ padding: "6px 8px", textAlign: "right", width: 60, color: "#A83B32" }}>ขาดอีก</th>
                        <th style={{ padding: "6px 8px", textAlign: "right", width: 80 }}>แนะนำสั่ง</th>
                        <th style={{ padding: "6px 8px", width: 120 }}>ผู้จัดจำหน่าย</th>
                        <th style={{ padding: "6px 8px", textAlign: "right", width: 80 }}>ประมาณการ</th>
                      </tr>
                    </thead>
                    <tbody>
                      {lowStockItems.map((it, idx) => {
                        const current = lotQtyForItem(inv.lots, it.id);
                        const deficit = Math.max(0, it.minStock - current);
                        const reorderQty = it.reorderQty && it.reorderQty > 0 ? it.reorderQty : deficit;
                        const cost = reorderQty * (Number(it.price) || 0);

                        return (
                          <tr
                            key={it.id}
                            style={{
                              borderBottom: "1px solid #EFECE1",
                              background: idx % 2 === 0 ? "#FFFFFF" : "#FCFAF6",
                            }}
                          >
                            <td style={{ padding: "6px 8px", color: "#8A8874" }}>{idx + 1}</td>
                            <td style={{ padding: "6px 8px", fontWeight: 600 }}>{it.name}</td>
                            <td style={{ padding: "6px 8px", color: "#556358" }}>{it.category}</td>
                            <td style={{ padding: "6px 8px", textAlign: "right", fontWeight: 700, color: "#A83B32" }}>
                              {current} {it.unit}
                            </td>
                            <td style={{ padding: "6px 8px", textAlign: "right", color: "#5B5747" }}>
                              {it.minStock} {it.unit}
                            </td>
                            <td style={{ padding: "6px 8px", textAlign: "right", fontWeight: 700, color: "#A83B32" }}>
                              -{deficit}
                            </td>
                            <td style={{ padding: "6px 8px", textAlign: "right", fontWeight: 600, color: "#2D4834" }}>
                              {reorderQty} {it.unit}
                            </td>
                            <td style={{ padding: "6px 8px", color: "#776F5E" }}>{it.supplier || "-"}</td>
                            <td style={{ padding: "6px 8px", textAlign: "right", color: "#2D4834", fontWeight: 600 }}>
                              {cost > 0 ? `฿${cost.toLocaleString()}` : "-"}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {/* Section 2: Near Expiry Lots */}
            {includeNearExpiry && (
              <div style={{ marginBottom: 26 }}>
                <div
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 6,
                    fontSize: 15,
                    fontWeight: 700,
                    color: "#946A1F",
                    marginBottom: 8,
                    borderBottom: "1.5px solid #F0DAA8",
                    paddingBottom: 4,
                  }}
                >
                  <Clock size={16} />
                  <span>2. รายการล็อตยาสมุนไพรที่ใกล้หมดอายุใน 90 วัน (Near Expiry Lots)</span>
                  <span style={{ fontSize: 12, color: "#87601B", fontWeight: 500 }}>
                    ({nearExpiryLots.length} ล็อต)
                  </span>
                </div>

                {nearExpiryLots.length === 0 ? (
                  <div
                    style={{
                      padding: "12px",
                      textAlign: "center",
                      fontSize: 12.5,
                      color: "#3C5A45",
                      background: "#F4F8F5",
                      borderRadius: 4,
                    }}
                  >
                    ✓ ไม่มีล็อตยาสมุนไพรที่หมดอายุหรือใกล้หมดอายุใน 90 วัน
                  </div>
                ) : (
                  <table
                    style={{
                      width: "100%",
                      borderCollapse: "collapse",
                      fontSize: 11.5,
                      marginTop: 4,
                    }}
                  >
                    <thead>
                      <tr style={{ background: "#FBF7ED", borderBottom: "1.5px solid #ECD9AA", textAlign: "left" }}>
                        <th style={{ padding: "6px 8px", width: 28 }}>#</th>
                        <th style={{ padding: "6px 8px" }}>ชื่อยาสมุนไพร</th>
                        <th style={{ padding: "6px 8px", width: 90 }}>ล็อตยา</th>
                        <th style={{ padding: "6px 8px", textAlign: "right", width: 75 }}>จำนวนคงเหลือ</th>
                        <th style={{ padding: "6px 8px", width: 85 }}>วันรับเข้า</th>
                        <th style={{ padding: "6px 8px", width: 85 }}>วันหมดอายุ</th>
                        <th style={{ padding: "6px 8px", textAlign: "center", width: 85 }}>สถานะคงเหลือ</th>
                        <th style={{ padding: "6px 8px", width: 110 }}>คำแนะนำการจัดการ</th>
                      </tr>
                    </thead>
                    <tbody>
                      {nearExpiryLots.map((l, idx) => {
                        const item = inv.items.find((i) => i.id === l.itemId);
                        const d = daysUntil(l.expiryDate);
                        const isExpired = d < 0;

                        return (
                          <tr
                            key={l.id}
                            style={{
                              borderBottom: "1px solid #EFECE1",
                              background: isExpired ? "#FFF5F5" : idx % 2 === 0 ? "#FFFFFF" : "#FDFBF7",
                            }}
                          >
                            <td style={{ padding: "6px 8px", color: "#8A8874" }}>{idx + 1}</td>
                            <td style={{ padding: "6px 8px", fontWeight: 600 }}>{item?.name || "ไม่ทราบชื่อยา"}</td>
                            <td style={{ padding: "6px 8px", color: "#465449", fontFamily: "monospace", fontSize: 11 }}>
                              {l.lotNo || "-"}
                            </td>
                            <td style={{ padding: "6px 8px", textAlign: "right", fontWeight: 700 }}>
                              {l.qty} {item?.unit || "หน่วย"}
                            </td>
                            <td style={{ padding: "6px 8px", color: "#746E5D" }}>{fmtDate(l.receivedDate)}</td>
                            <td style={{ padding: "6px 8px", fontWeight: 600, color: isExpired ? "#A83B32" : "#946A1F" }}>
                              {fmtDate(l.expiryDate)}
                            </td>
                            <td style={{ padding: "6px 8px", textAlign: "center" }}>
                              <span
                                style={{
                                  padding: "2px 6px",
                                  borderRadius: 4,
                                  fontSize: 10.5,
                                  fontWeight: 700,
                                  background: isExpired ? "#FBEDEB" : d <= 30 ? "#FBF0DC" : "#F7F5EA",
                                  color: isExpired ? "#A83B32" : d <= 30 ? "#946A1F" : "#6E6852",
                                }}
                              >
                                {isExpired ? "หมดอายุแล้ว" : `เหลือ ${d} วัน`}
                              </span>
                            </td>
                            <td style={{ padding: "6px 8px", fontSize: 11, color: isExpired ? "#A83B32" : "#2E5739" }}>
                              {isExpired ? "กักกัน/จำหน่ายทิ้ง" : d <= 30 ? "เร่งเบิกจ่ายด่วน (FEFO)" : "ติดตามการใช้"}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                )}
              </div>
            )}

            {/* Section 3: Signatures */}
            {includeSignatures && (
              <div
                style={{
                  marginTop: 32,
                  paddingTop: 16,
                  borderTop: "1px dashed #D6D1C1",
                  display: "grid",
                  gridTemplateColumns: "1fr 1fr",
                  gap: 40,
                }}
              >
                <div style={{ textAlign: "center", fontSize: 12 }}>
                  <div style={{ marginBottom: 40 }}>ผู้จัดทำรายงาน:</div>
                  <div style={{ borderBottom: "1px solid #8A8874", width: 180, margin: "0 auto 6px" }}></div>
                  <div style={{ fontWeight: 600 }}>({staffName})</div>
                  <div style={{ color: "#746E5D", fontSize: 11, marginTop: 2 }}>เภสัชกร / เจ้าหน้าที่คลังยา</div>
                  <div style={{ color: "#8A8874", fontSize: 11, marginTop: 4 }}>
                    วันที่: ......... / ......... / .............
                  </div>
                </div>

                <div style={{ textAlign: "center", fontSize: 12 }}>
                  <div style={{ marginBottom: 40 }}>ผู้ตรวจสอบ / อนุมัติ:</div>
                  <div style={{ borderBottom: "1px solid #8A8874", width: 180, margin: "0 auto 6px" }}></div>
                  <div style={{ fontWeight: 600 }}>(........................................................)</div>
                  <div style={{ color: "#746E5D", fontSize: 11, marginTop: 2 }}>
                    หัวหน้ากลุ่มงานเภสัชกรรม / ผู้อำนวยการ
                  </div>
                  <div style={{ color: "#8A8874", fontSize: 11, marginTop: 4 }}>
                    วันที่: ......... / ......... / .............
                  </div>
                </div>
              </div>
            )}

            {/* Document Footer Note */}
            <div
              style={{
                marginTop: 24,
                textAlign: "center",
                fontSize: 10.5,
                color: "#9C9788",
                borderTop: "1px solid #F0EEE3",
                paddingTop: 8,
              }}
            >
              เอกสารฉบับนี้สร้างขึ้นโดยอัตโนมัติจากระบบบริหารคลังยาสมุนไพร (Herbal Inventory System) เพื่อใช้เป็นหลักฐานการบริหารจัดการคลัง
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
