import React, { useState } from "react";
import { AlertTriangle, Clock, ArrowLeftRight, ChevronRight, Pencil, Mail, Trash2, RotateCcw, Sparkles, Plus, FileDown } from "lucide-react";
import type { InventoryState, HerbalItem, HerbalLot, StockTransaction } from "../types";
import { Panel, Btn } from "./Panel";
import { lotQtyForItem, fmtDate, daysUntil, CATEGORIES } from "../utils/storage";
import { DashboardCharts } from "./DashboardCharts";
import { LowStockAlertCard } from "./LowStockAlertCard";
import { DashboardQuickSearch } from "./DashboardQuickSearch";
import { MockEmailNotificationModal } from "./MockEmailNotificationModal";
import { ActivityFeed } from "./ActivityFeed";
import { PdfExportModal } from "./PdfExportModal";

function StatCard({
  label,
  value,
  accent,
  sub,
  id,
}: {
  label: string;
  value: string | number;
  accent: string;
  sub?: string;
  id?: string;
}) {
  return (
    <Panel id={id} accent={accent} style={{ flex: 1, minWidth: 150 }}>
      <div style={{ fontSize: 12.5, color: "#8A8874", fontWeight: 600 }}>{label}</div>
      <div style={{ fontSize: 26, fontFamily: "'Noto Serif Thai', serif", fontWeight: 700, marginTop: 4 }}>
        {value}
      </div>
      {sub && <div style={{ fontSize: 12, color: "#8A8874", marginTop: 2 }}>{sub}</div>}
    </Panel>
  );
}

export function Dashboard({
  inv,
  lowStockItems,
  nearExpiryLots,
  tx,
  setTab,
  persistInv,
  showToast,
  onOpenMoveWithItem,
  onClearSampleData,
  onLoadSampleData,
  onOpenLotLifecycle,
}: {
  inv: InventoryState;
  lowStockItems: HerbalItem[];
  nearExpiryLots: HerbalLot[];
  tx: StockTransaction[];
  setTab: (t: "dashboard" | "items" | "move" | "history") => void;
  persistInv?: (next: InventoryState) => Promise<void>;
  showToast?: (msg: string) => void;
  onOpenMoveWithItem?: (itemId: string, mode?: "in" | "out") => void;
  onClearSampleData?: () => Promise<void>;
  onLoadSampleData?: () => Promise<void>;
  onOpenLotLifecycle?: (lotId: string) => void;
}) {
  const totalUnits = inv.lots.reduce((s, l) => s + l.qty, 0);
  const totalValue = inv.items.reduce((s, it) => s + lotQtyForItem(inv.lots, it.id) * (Number(it.price) || 0), 0);
  const recent = [...tx].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()).slice(0, 6);

  // Mock Email Notification Modal States
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [emailModalType, setEmailModalType] = useState<"combined" | "low_stock" | "near_expiry" | "digest">("combined");
  const [emailModalTab, setEmailModalTab] = useState<"preview" | "settings" | "history">("preview");

  // PDF Export Modal State
  const [showPdfModal, setShowPdfModal] = useState(false);

  function handleOpenEmailModal(type: "combined" | "low_stock" | "near_expiry" | "digest" = "combined", tab: "preview" | "settings" | "history" = "preview") {
    setEmailModalType(type);
    setEmailModalTab(tab);
    setShowEmailModal(true);
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 8, marginBottom: 18 }}>
        <div>
          <h1 style={{ fontFamily: "'Noto Serif Thai', serif", fontSize: 24, margin: "2px 0 4px", fontWeight: 700 }}>
            ภาพรวมคลังยาสมุนไพร
          </h1>
          <div style={{ color: "#8A8874", fontSize: 13 }}>
            {new Date().toLocaleDateString("th-TH", { weekday: "long", day: "numeric", month: "long", year: "numeric" })}
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "center" }}>
          {inv.items.length > 0 && onClearSampleData && (
            <button
              id="btn-header-clear-sample-data"
              onClick={onClearSampleData}
              style={{
                background: "#FFFFFF",
                border: "1px solid #F1C3BF",
                color: "#A83B32",
                borderRadius: 8,
                padding: "7px 12px",
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
                fontFamily: "Sarabun, sans-serif",
                transition: "all 0.15s ease",
              }}
              title="ล้างข้อมูลตัวอย่างทั้งหมดในคลังยา"
            >
              <Trash2 size={14} color="#A83B32" />
              <span>ล้างข้อมูลตัวอย่าง</span>
            </button>
          )}

          {/* PDF Export Button for Low Stock and Near Expiry reports */}
          <button
            id="btn-export-pdf-report"
            onClick={() => setShowPdfModal(true)}
            style={{
              background: "#3C5A45",
              border: "1px solid #2F4A37",
              color: "#FFFFFF",
              borderRadius: 8,
              padding: "7px 14px",
              fontSize: 13,
              fontWeight: 700,
              cursor: "pointer",
              display: "inline-flex",
              alignItems: "center",
              gap: 6,
              boxShadow: "0 2px 6px rgba(60, 90, 69, 0.25)",
              fontFamily: "Sarabun, sans-serif",
              transition: "all 0.15s ease",
            }}
            title="ส่งออกรายงาน PDF สรุปสถานะสต็อกต่ำกว่าเกณฑ์และยาใกล้หมดอายุ"
          >
            <FileDown size={15} color="#FFFFFF" />
            <span>ส่งออกรายงาน PDF</span>
            {(lowStockItems.length > 0 || nearExpiryLots.length > 0) && (
              <span
                style={{
                  background: "rgba(255, 255, 255, 0.25)",
                  color: "#FFFFFF",
                  fontSize: 11,
                  fontWeight: 700,
                  borderRadius: 10,
                  padding: "1px 6px",
                  lineHeight: 1.2,
                }}
              >
                {lowStockItems.length + nearExpiryLots.length}
              </span>
            )}
          </button>

          <button
            id="btn-open-email-alerts"
            onClick={() => handleOpenEmailModal("combined", "preview")}
            style={{
              background: "#FFFFFF",
              border: "1px solid #C4D5C7",
              color: "#2D4834",
              borderRadius: 8,
              padding: "7px 14px",
              fontSize: 13,
              fontWeight: 700,
              cursor: "pointer",
              display: "inline-flex",
              alignItems: "center",
              gap: 6,
              boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
              fontFamily: "Sarabun, sans-serif",
              transition: "all 0.15s ease",
            }}
            title="เปิดระบบจำลองการส่งอีเมลแจ้งเตือนสต็อกต่ำและยาใกล้หมดอายุ"
          >
            <Mail size={15} color="#2D4834" />
            <span>จำลองแจ้งเตือนอีเมล</span>
            {(lowStockItems.length > 0 || nearExpiryLots.length > 0) && (
              <span
                style={{
                  background: lowStockItems.length > 0 ? "#A83B32" : "#C08A2E",
                  color: "#FFFFFF",
                  fontSize: 11,
                  fontWeight: 700,
                  borderRadius: 10,
                  padding: "1px 6px",
                  lineHeight: 1.2,
                }}
              >
                {lowStockItems.length + nearExpiryLots.length}
              </span>
            )}
          </button>

          <Btn onClick={() => setTab("move")}>
            <ArrowLeftRight size={14} /> ทำรายการ รับเข้า / เบิกออก
          </Btn>
        </div>
      </div>

      <div style={{ display: "flex", gap: 14, flexWrap: "wrap", marginBottom: 20 }}>
        <StatCard id="stat-total-items" label="รายการยาทั้งหมด" value={inv.items.length} accent="#3C5A45" sub={`${CATEGORIES.length} หมวดหมู่`} />
        <StatCard id="stat-total-units" label="จำนวนคงเหลือรวม" value={totalUnits.toLocaleString()} accent="#3C5A45" sub="ชิ้น/ขวด/กล่อง" />
        <StatCard id="stat-total-value" label="มูลค่าสต็อกรวม" value={`฿${totalValue.toLocaleString(undefined, { maximumFractionDigits: 0 })}`} accent="#5B7A63" />
        <StatCard id="stat-low-stock" label="สต็อกต่ำกว่าเกณฑ์" value={lowStockItems.length} accent={lowStockItems.length > 0 ? "#A83B32" : "#3C5A45"} sub="ต้องสั่งซื้อเพิ่ม" />
        <StatCard id="stat-near-expiry" label="ใกล้หมดอายุ (≤90 วัน)" value={nearExpiryLots.length} accent={nearExpiryLots.length > 0 ? "#C08A2E" : "#3C5A45"} sub="ควรเร่งเบิกจ่าย" />
      </div>

      {/* Empty State Banner when no items in inventory */}
      {inv.items.length === 0 && (
        <div
          id="banner-empty-inventory"
          style={{
            background: "#FFFFFF",
            border: "1.5px dashed #C8D8CB",
            borderRadius: 12,
            padding: "36px 24px",
            textAlign: "center",
            marginBottom: 20,
            boxShadow: "0 2px 10px rgba(42, 56, 44, 0.03)",
          }}
        >
          <div
            style={{
              width: 52,
              height: 52,
              borderRadius: "50%",
              background: "#EEF3EF",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              margin: "0 auto 12px",
              color: "#3C5A45",
            }}
          >
            <Sparkles size={26} />
          </div>
          <h3
            style={{
              fontFamily: "'Noto Serif Thai', serif",
              fontSize: 19,
              fontWeight: 700,
              color: "#1F2D24",
              margin: "0 0 6px",
            }}
          >
            คลังยาสมุนไพรว่างเปล่า (ล้างข้อมูลตัวอย่างแล้ว)
          </h3>
          <p
            style={{
              color: "#68776D",
              fontSize: 13.5,
              maxWidth: 540,
              margin: "0 auto 20px",
              lineHeight: 1.6,
            }}
          >
            ข้อมูลตัวอย่างทั้งหมดในคลังถูกล้างเรียบร้อยแล้ว คุณสามารถเริ่มต้นเพิ่มรายการยาสมุนไพรจริงของคลังเวชภัณฑ์ หรือหากต้องการทดสอบระบบ สามารถโหลดข้อมูลตัวอย่าง 5 รายการกลับมาได้ทุกเมื่อ
          </p>
          <div style={{ display: "flex", justifyContent: "center", gap: 12, flexWrap: "wrap" }}>
            <button
              id="btn-empty-add-item"
              onClick={() => setTab("items")}
              style={{
                background: "#3C5A45",
                color: "#FFFFFF",
                border: "none",
                borderRadius: 8,
                padding: "9px 18px",
                fontSize: 13.5,
                fontWeight: 700,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                boxShadow: "0 2px 6px rgba(60, 90, 69, 0.2)",
                fontFamily: "Sarabun, sans-serif",
              }}
            >
              <Plus size={16} />
              <span>+ เพิ่มรายการยาสมุนไพรใหม่</span>
            </button>
            {onLoadSampleData && (
              <button
                id="btn-empty-load-sample"
                onClick={onLoadSampleData}
                style={{
                  background: "#FFFFFF",
                  color: "#3C5A45",
                  border: "1.5px solid #C8D8CB",
                  borderRadius: 8,
                  padding: "9px 18px",
                  fontSize: 13.5,
                  fontWeight: 600,
                  cursor: "pointer",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  fontFamily: "Sarabun, sans-serif",
                }}
              >
                <RotateCcw size={15} />
                <span>โหลดข้อมูลตัวอย่าง (5 รายการ) สำหรับทดสอบ</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* Highlighted Low Stock & Reorder Alert Card Section */}
      {inv.items.length > 0 && persistInv && showToast && (
        <LowStockAlertCard
          inv={inv}
          lowStockItems={lowStockItems}
          persistInv={persistInv}
          showToast={showToast}
          onOpenMoveWithItem={onOpenMoveWithItem}
          onOpenEmailModal={(type) => handleOpenEmailModal(type || "low_stock", "preview")}
        />
      )}

      {/* Quick Search & Filter Section */}
      <DashboardQuickSearch
        inv={inv}
        setTab={setTab}
        onOpenMoveWithItem={onOpenMoveWithItem}
        persistInv={persistInv}
        showToast={showToast}
      />

      {/* Recharts Analytics Section */}
      <DashboardCharts inv={inv} tx={tx} />

      <div style={{ display: "flex", gap: 16, flexWrap: "wrap", marginTop: 20 }}>
        <Panel id="panel-low-stock" accent="#A83B32" style={{ flex: "1 1 320px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, fontWeight: 700, color: "#A83B32" }}>
              <AlertTriangle size={17} />
              <span>สต็อกต่ำกว่าเกณฑ์ ({lowStockItems.length})</span>
            </div>
            <button
              onClick={() => setTab("items")}
              style={{ background: "none", border: "none", color: "#3C5A45", fontSize: 12.5, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 2, padding: 0 }}
            >
              ดูทั้งหมดในคลัง <ChevronRight size={14} />
            </button>
          </div>
          {lowStockItems.length === 0 ? (
            <div style={{ fontSize: 13, color: "#8A8874", padding: "12px 0" }}>
              ยอดเยี่ยม! ไม่มีรายการยาที่สต็อกต่ำกว่าเกณฑ์
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
              {lowStockItems.slice(0, 5).map((it) => {
                const current = lotQtyForItem(inv.lots, it.id);
                return (
                  <div
                    key={it.id}
                    style={{
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "center",
                      fontSize: 13,
                      padding: "8px 10px",
                      background: "#FBF5F4",
                      borderRadius: 6,
                    }}
                  >
                    <div>
                      <div style={{ fontWeight: 600, color: "#1F2D24" }}>{it.name}</div>
                      <div style={{ fontSize: 11.5, color: "#8A8874" }}>
                        {it.supplier ? `ผู้จัดจำหน่าย: ${it.supplier}` : it.category}
                      </div>
                    </div>
                    <div style={{ textAlign: "right" }}>
                      <div style={{ color: "#A83B32", fontWeight: 700, whiteSpace: "nowrap" }}>
                        {current} / ขั้นต่ำ {it.minStock} {it.unit}
                      </div>
                      <button
                        onClick={() => {
                          const elem = document.getElementById(`btn-edit-reorder-${it.id}`);
                          if (elem) {
                            elem.click();
                          } else {
                            setTab("items");
                          }
                        }}
                        style={{
                          background: "none",
                          border: "none",
                          color: "#A83B32",
                          fontSize: 11,
                          fontWeight: 700,
                          cursor: "pointer",
                          padding: 0,
                          marginTop: 2,
                          textDecoration: "underline",
                        }}
                      >
                        แก้ไขสั่งซื้อ
                      </button>
                    </div>
                  </div>
                );
              })}

              <div style={{ marginTop: 10, textAlign: "right" }}>
                <button
                  id="btn-low-stock-export-pdf"
                  onClick={() => setShowPdfModal(true)}
                  style={{
                    background: "none",
                    border: "none",
                    color: "#A83B32",
                    fontSize: 12,
                    fontWeight: 700,
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                    padding: "2px 0",
                    textDecoration: "underline",
                  }}
                >
                  <FileDown size={13} />
                  <span>ส่งออกรายงาน PDF สต็อกต่ำ & ใกล้หมดอายุ</span>
                </button>
              </div>
            </div>
          )}
        </Panel>

        <Panel id="panel-near-expiry" accent="#C08A2E" style={{ flex: "1 1 320px" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 8, fontWeight: 700, color: "#946A1F" }}>
              <Clock size={17} />
              <span>ใกล้หมดอายุ ({nearExpiryLots.length})</span>
            </div>
            <button
              onClick={() => setTab("move")}
              style={{ background: "none", border: "none", color: "#3C5A45", fontSize: 12.5, fontWeight: 700, cursor: "pointer", display: "flex", alignItems: "center", gap: 2, padding: 0 }}
            >
              เบิกจ่ายก่อน <ChevronRight size={14} />
            </button>
          </div>
          {nearExpiryLots.length === 0 ? (
            <div style={{ fontSize: 13, color: "#8A8874", padding: "12px 0" }}>
              ไม่มีล็อตยาที่หมดอายุหรือใกล้หมดอายุใน 90 วัน
            </div>
          ) : (
            <>
              <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                {nearExpiryLots.slice(0, 5).map((l) => {
                  const item = inv.items.find((i) => i.id === l.itemId);
                  const d = daysUntil(l.expiryDate);
                  const isExpired = d < 0;
                  return (
                    <div
                      key={l.id}
                      id={`dashboard-near-expiry-lot-${l.id}`}
                      onClick={() => onOpenLotLifecycle?.(l.id)}
                      style={{
                        display: "flex",
                        justifyContent: "space-between",
                        alignItems: "center",
                        fontSize: 13,
                        padding: "6px 8px",
                        background: isExpired ? "#FBEDEB" : "#FBF7ED",
                        borderRadius: 6,
                        cursor: "pointer",
                        transition: "background 0.15s ease",
                      }}
                      title="คลิกเพื่อดูวงจรชีวิตล็อตยานี้ตั้งแต่รับเข้าจนหมดสต็อก"
                    >
                      <span>
                        <b style={{ fontWeight: 600 }}>{item?.name || "?"}</b>{" "}
                        <span style={{ fontSize: 11.5, color: "#8A8874" }}>ล็อต {l.lotNo || "-"} ({l.qty} {item?.unit})</span>
                      </span>
                      <span style={{ color: isExpired ? "#A83B32" : "#946A1F", fontWeight: 700, whiteSpace: "nowrap" }}>
                        {isExpired ? "หมดอายุแล้ว" : `เหลือ ${d} วัน`}
                      </span>
                    </div>
                  );
                })}
              </div>

              <div style={{ marginTop: 10, display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 8 }}>
                <button
                  id="btn-near-expiry-export-pdf"
                  onClick={() => setShowPdfModal(true)}
                  style={{
                    background: "none",
                    border: "none",
                    color: "#996B1E",
                    fontSize: 12,
                    fontWeight: 700,
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                    padding: "2px 0",
                    textDecoration: "underline",
                  }}
                >
                  <FileDown size={13} />
                  <span>ส่งออกรายงาน PDF</span>
                </button>

                <button
                  id="btn-near-expiry-send-email"
                  onClick={() => handleOpenEmailModal("near_expiry", "preview")}
                  style={{
                    background: "none",
                    border: "none",
                    color: "#996B1E",
                    fontSize: 12,
                    fontWeight: 700,
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 4,
                    padding: "2px 0",
                    textDecoration: "underline",
                  }}
                >
                  <Mail size={13} />
                  <span>จำลองส่งอีเมลแจ้งเตือน</span>
                </button>
              </div>
            </>
          )}
        </Panel>
      </div>

      {/* Activity Feed Section: 5 most recent transactions with user names and timestamps */}
      <ActivityFeed
        inv={inv}
        tx={tx}
        setTab={setTab}
        onOpenMoveWithItem={onOpenMoveWithItem}
        onOpenLotLifecycle={onOpenLotLifecycle}
      />

      {/* Mock Email Notification Modal */}
      <MockEmailNotificationModal
        isOpen={showEmailModal}
        onClose={() => setShowEmailModal(false)}
        inv={inv}
        lowStockItems={lowStockItems}
        nearExpiryLots={nearExpiryLots}
        showToast={showToast || (() => {})}
        initialTab={emailModalTab}
        initialType={emailModalType}
        onNavigateToMove={() => setTab("move")}
      />

      {/* PDF Export Modal for Low Stock & Near Expiry Reports */}
      <PdfExportModal
        isOpen={showPdfModal}
        onClose={() => setShowPdfModal(false)}
        inv={inv}
        lowStockItems={lowStockItems}
        nearExpiryLots={nearExpiryLots}
        showToast={showToast || (() => {})}
      />
    </div>
  );
}
