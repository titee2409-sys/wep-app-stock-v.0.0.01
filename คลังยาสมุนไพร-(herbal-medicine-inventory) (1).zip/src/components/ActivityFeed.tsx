import React, { useState, useMemo } from "react";
import {
  Activity,
  ArrowDownLeft,
  ArrowUpRight,
  User,
  Clock,
  ChevronRight,
  Tag,
  Package,
  FileText,
  Calendar,
  ExternalLink,
  Plus,
  Search,
  X,
} from "lucide-react";
import type { InventoryState, StockTransaction } from "../types";
import { Panel } from "./Panel";
import { fmtDate } from "../utils/storage";

interface ActivityFeedProps {
  inv: InventoryState;
  tx: StockTransaction[];
  setTab: (t: "dashboard" | "items" | "move" | "history") => void;
  onOpenMoveWithItem?: (itemId: string, mode?: "in" | "out") => void;
  onOpenLotLifecycle?: (lotId: string) => void;
}

/**
 * Format timestamp into Thai human-readable string with date and time
 */
function formatTransactionTimestamp(t: StockTransaction): { full: string; relative: string; timeStr: string } {
  if (t.timestamp) {
    try {
      const dt = new Date(t.timestamp);
      if (!isNaN(dt.getTime())) {
        const now = new Date();
        const diffMs = now.getTime() - dt.getTime();
        const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
        const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
        const diffMins = Math.floor(diffMs / (1000 * 60));

        let relative = "";
        if (diffMins < 2) {
          relative = "เมื่อสักครู่";
        } else if (diffMins < 60) {
          relative = `${diffMins} นาทีที่แล้ว`;
        } else if (diffHours < 24 && dt.getDate() === now.getDate()) {
          relative = `วันนี้ (${diffHours} ชม. ที่แล้ว)`;
        } else if (diffDays === 1 || (diffHours < 48 && dt.getDate() === now.getDate() - 1)) {
          relative = "เมื่อวานนี้";
        } else if (diffDays < 30) {
          relative = `${diffDays} วันที่แล้ว`;
        } else {
          relative = fmtDate(t.date);
        }

        const dateStr = dt.toLocaleDateString("th-TH", {
          day: "2-digit",
          month: "short",
          year: "numeric",
        });

        const timeStr = dt.toLocaleTimeString("th-TH", {
          hour: "2-digit",
          minute: "2-digit",
        }) + " น.";

        return {
          full: `${dateStr} · ${timeStr}`,
          relative,
          timeStr,
        };
      }
    } catch {
      // fallback
    }
  }

  // Fallback to t.date only
  return {
    full: fmtDate(t.date),
    relative: fmtDate(t.date),
    timeStr: "",
  };
}

export function ActivityFeed({ inv, tx, setTab, onOpenMoveWithItem, onOpenLotLifecycle }: ActivityFeedProps) {
  const [filterType, setFilterType] = useState<"all" | "in" | "out">("all");
  const [searchQuery, setSearchQuery] = useState("");

  // Map item ID to item for fast lookup
  const itemMap = useMemo(() => {
    const map = new Map<string, typeof inv.items[0]>();
    inv.items.forEach((it) => map.set(it.id, it));
    return map;
  }, [inv.items]);

  // Sort by timestamp or date descending
  const sortedTransactions = useMemo(() => {
    return [...tx].sort((a, b) => {
      const timeA = a.timestamp ? new Date(a.timestamp).getTime() : new Date(a.date + "T00:00:00").getTime();
      const timeB = b.timestamp ? new Date(b.timestamp).getTime() : new Date(b.date + "T00:00:00").getTime();
      return timeB - timeA;
    });
  }, [tx]);

  // Filter transactions by filterType and searchQuery (medicine name)
  const filteredTransactions = useMemo(() => {
    const q = searchQuery.trim().toLowerCase();

    return sortedTransactions.filter((t) => {
      // 1. Transaction Type Filter
      if (filterType !== "all" && t.type !== filterType) {
        return false;
      }

      // 2. Search query by medicine name
      if (q) {
        const item = itemMap.get(t.itemId);
        const name = (item?.name || "").toLowerCase();
        const category = (item?.category || "").toLowerCase();
        if (!name.includes(q) && !category.includes(q)) {
          return false;
        }
      }

      return true;
    });
  }, [sortedTransactions, filterType, searchQuery, itemMap]);

  // Take the 5 most recent transactions after filtering
  const displayedRecent = useMemo(() => {
    return filteredTransactions.slice(0, 5);
  }, [filteredTransactions]);

  // Extract unique medicine names present in transactions for quick suggestion chips
  const quickMedicineSuggestions = useMemo(() => {
    const names = new Set<string>();
    tx.forEach((t) => {
      const item = itemMap.get(t.itemId);
      if (item?.name) {
        // Extract main name before parentheses if any
        const cleanName = item.name.split(" (")[0].trim();
        names.add(cleanName);
      }
    });
    return Array.from(names).slice(0, 6);
  }, [tx, itemMap]);

  // Quick counts
  const totalIn = useMemo(() => tx.filter((t) => t.type === "in").length, [tx]);
  const totalOut = useMemo(() => tx.filter((t) => t.type === "out").length, [tx]);

  return (
    <div id="activity-feed-section" style={{ marginTop: 20 }}>
      <Panel accent="#3C5A45" style={{ padding: "18px 20px" }}>
        {/* Activity Feed Header */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            flexWrap: "wrap",
            gap: 12,
            marginBottom: 16,
            paddingBottom: 14,
            borderBottom: "1px solid #EBE7DA",
          }}
        >
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <div
                style={{
                  background: "#EEF3EF",
                  color: "#3C5A45",
                  padding: "6px 8px",
                  borderRadius: 8,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                }}
              >
                <Activity size={18} />
              </div>
              <h2
                style={{
                  fontFamily: "'Noto Serif Thai', serif",
                  fontSize: 18,
                  fontWeight: 700,
                  margin: 0,
                  color: "#1F2D24",
                }}
              >
                Activity Feed (กิจกรรมความเคลื่อนไหวล่าสุด)
              </h2>
              <span
                style={{
                  background: "#E7ECE8",
                  color: "#3C5A45",
                  fontSize: 11,
                  fontWeight: 700,
                  padding: "2px 8px",
                  borderRadius: 12,
                }}
              >
                5 รายการล่าสุด
              </span>
            </div>
            <div style={{ fontSize: 12.5, color: "#8A8874", marginTop: 4 }}>
              แสดงธุรกรรมการรับเข้าและเบิกจ่ายยาสมุนไพร 5 รายการล่าสุด พร้อมชื่อผู้บันทึกและเวลาที่ทำรายการ
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            {/* Filter Buttons */}
            <div
              style={{
                display: "inline-flex",
                background: "#F6F3EA",
                borderRadius: 7,
                padding: "2px",
                border: "1px solid #DCD7C8",
                gap: 2,
              }}
            >
              <button
                id="btn-feed-filter-all"
                onClick={() => setFilterType("all")}
                style={{
                  border: "none",
                  background: filterType === "all" ? "#3C5A45" : "transparent",
                  color: filterType === "all" ? "#FFFFFF" : "#5B5747",
                  fontSize: 11.5,
                  fontWeight: 600,
                  padding: "4px 8px",
                  borderRadius: 5,
                  cursor: "pointer",
                  fontFamily: "Sarabun, sans-serif",
                }}
              >
                ทั้งหมด ({tx.length})
              </button>
              <button
                id="btn-feed-filter-in"
                onClick={() => setFilterType("in")}
                style={{
                  border: "none",
                  background: filterType === "in" ? "#3C5A45" : "transparent",
                  color: filterType === "in" ? "#FFFFFF" : "#5B5747",
                  fontSize: 11.5,
                  fontWeight: 600,
                  padding: "4px 8px",
                  borderRadius: 5,
                  cursor: "pointer",
                  fontFamily: "Sarabun, sans-serif",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 3,
                }}
              >
                <ArrowDownLeft size={12} />
                <span>รับเข้า ({totalIn})</span>
              </button>
              <button
                id="btn-feed-filter-out"
                onClick={() => setFilterType("out")}
                style={{
                  border: "none",
                  background: filterType === "out" ? "#A83B32" : "transparent",
                  color: filterType === "out" ? "#FFFFFF" : "#5B5747",
                  fontSize: 11.5,
                  fontWeight: 600,
                  padding: "4px 8px",
                  borderRadius: 5,
                  cursor: "pointer",
                  fontFamily: "Sarabun, sans-serif",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 3,
                }}
              >
                <ArrowUpRight size={12} />
                <span>เบิกออก ({totalOut})</span>
              </button>
            </div>

            <button
              id="btn-feed-view-all-history"
              onClick={() => setTab("history")}
              style={{
                background: "#FFFFFF",
                border: "1px solid #D5DFD7",
                color: "#3C5A45",
                fontSize: 12.5,
                fontWeight: 700,
                padding: "6px 12px",
                borderRadius: 7,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 4,
                fontFamily: "Sarabun, sans-serif",
                transition: "all 0.15s ease",
              }}
            >
              <span>ดูประวัติทั้งหมด</span>
              <ChevronRight size={14} />
            </button>
          </div>
        </div>

        {/* Search Input Field above the Activity Feed list to filter transactions by medicine name */}
        <div
          id="activity-feed-search-section"
          style={{
            background: "#FAF8F2",
            border: "1px solid #E5DFD1",
            borderRadius: 8,
            padding: "10px 14px",
            marginBottom: 14,
            display: "flex",
            flexDirection: "column",
            gap: 8,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 8 }}>
            <label
              htmlFor="input-feed-search-medicine"
              style={{
                fontSize: 12.5,
                fontWeight: 700,
                color: "#2D4834",
                display: "flex",
                alignItems: "center",
                gap: 6,
                cursor: "pointer",
              }}
            >
              <Search size={14} color="#3C5A45" />
              <span>ค้นหาธุรกรรมตามชื่อยาสมุนไพร (Filter by Medicine Name):</span>
            </label>

            {searchQuery && (
              <span style={{ fontSize: 11.5, color: "#6A7B6E" }}>
                พบ <b>{filteredTransactions.length}</b> รายการ (แสดง 5 รายการล่าสุด)
              </span>
            )}
          </div>

          <div style={{ position: "relative", width: "100%" }}>
            <div
              style={{
                position: "absolute",
                left: 12,
                top: "50%",
                transform: "translateY(-50%)",
                color: "#8A8874",
                display: "flex",
                alignItems: "center",
                pointerEvents: "none",
              }}
            >
              <Search size={15} />
            </div>

            <input
              id="input-feed-search-medicine"
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="พิมพ์ชื่อยาสมุนไพรเพื่อกรองธุรกรรม เช่น ฟ้าทะลายโจร, ขมิ้นชัน, มะขามป้อม..."
              style={{
                width: "100%",
                boxSizing: "border-box",
                padding: "8px 34px 8px 36px",
                borderRadius: 6,
                border: searchQuery ? "1.5px solid #3C5A45" : "1px solid #D8D3C2",
                background: "#FFFFFF",
                color: "#1F2D24",
                fontSize: 13,
                fontFamily: "Sarabun, sans-serif",
                outline: "none",
                transition: "border-color 0.15s ease",
              }}
            />

            {searchQuery && (
              <button
                id="btn-feed-clear-search"
                onClick={() => setSearchQuery("")}
                title="ล้างคำค้นหา"
                style={{
                  position: "absolute",
                  right: 9,
                  top: "50%",
                  transform: "translateY(-50%)",
                  background: "#EAE6DA",
                  border: "none",
                  borderRadius: "50%",
                  width: 20,
                  height: 20,
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  cursor: "pointer",
                  color: "#5B5747",
                  padding: 0,
                }}
              >
                <X size={12} />
              </button>
            )}
          </div>

          {/* Quick Suggestions Chips */}
          {quickMedicineSuggestions.length > 0 && (
            <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap", paddingTop: 2 }}>
              <span style={{ fontSize: 11.5, color: "#8A8874" }}>กรองด่วน:</span>
              {quickMedicineSuggestions.map((name) => {
                const isSelected = searchQuery.toLowerCase() === name.toLowerCase();
                return (
                  <button
                    key={name}
                    id={`btn-feed-chip-${name}`}
                    onClick={() => setSearchQuery(isSelected ? "" : name)}
                    style={{
                      border: isSelected ? "1px solid #3C5A45" : "1px solid #DCD7C8",
                      background: isSelected ? "#3C5A45" : "#FFFFFF",
                      color: isSelected ? "#FFFFFF" : "#556358",
                      fontSize: 11,
                      fontWeight: isSelected ? 700 : 500,
                      padding: "2px 8px",
                      borderRadius: 12,
                      cursor: "pointer",
                      fontFamily: "Sarabun, sans-serif",
                      transition: "all 0.15s ease",
                    }}
                  >
                    {name}
                  </button>
                );
              })}
              {searchQuery && (
                <button
                  id="btn-feed-reset-search-chip"
                  onClick={() => setSearchQuery("")}
                  style={{
                    background: "none",
                    border: "none",
                    color: "#A83B32",
                    fontSize: 11,
                    fontWeight: 600,
                    cursor: "pointer",
                    textDecoration: "underline",
                    padding: "2px 4px",
                  }}
                >
                  ล้างตัวกรอง
                </button>
              )}
            </div>
          )}
        </div>

        {/* Feed List Items */}
        {tx.length === 0 ? (
          <div
            id="feed-empty-state"
            style={{
              padding: "36px 16px",
              textAlign: "center",
              background: "#FAFBF9",
              borderRadius: 8,
              border: "1px dashed #D6E0D8",
            }}
          >
            <div style={{ color: "#8A8874", marginBottom: 6 }}>
              <Activity size={26} />
            </div>
            <div style={{ fontWeight: 700, fontSize: 14.5, color: "#1F2D24" }}>
              ยังไม่มีประวัติการทำรายการรับเข้าหรือเบิกออกในระบบ
            </div>
            <div style={{ fontSize: 12.5, color: "#8A8874", marginTop: 4 }}>
              เมื่อมีการทำรายการรับเข้าหรือเบิกออกยาสมุนไพร รายการ 5 รายการล่าสุดจะแสดงที่นี่โดยอัตโนมัติ
            </div>
            <button
              onClick={() => setTab("move")}
              style={{
                marginTop: 14,
                background: "#3C5A45",
                color: "#FFFFFF",
                border: "none",
                borderRadius: 6,
                padding: "7px 16px",
                fontSize: 13,
                fontWeight: 600,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 6,
                fontFamily: "Sarabun, sans-serif",
              }}
            >
              <Plus size={14} />
              <span>+ บันทึกรับเข้า / เบิกออกสต็อก</span>
            </button>
          </div>
        ) : displayedRecent.length === 0 ? (
          <div
            id="feed-no-matching-results"
            style={{
              padding: "32px 16px",
              textAlign: "center",
              background: "#FAFBF9",
              borderRadius: 8,
              border: "1px dashed #D6E0D8",
            }}
          >
            <div style={{ color: "#8A8874", marginBottom: 6 }}>
              <Search size={26} />
            </div>
            <div style={{ fontWeight: 700, fontSize: 14.5, color: "#1F2D24" }}>
              {searchQuery
                ? `ไม่พบรายการธุรกรรมของยา "${searchQuery}"${filterType !== "all" ? ` (ประเภท ${filterType === "in" ? "รับเข้า" : "เบิกออก"})` : ""}`
                : `ไม่มีรายการประเภท ${filterType === "in" ? "รับเข้า" : "เบิกออก"} ในระบบ`}
            </div>
            <div style={{ fontSize: 12.5, color: "#8A8874", marginTop: 4 }}>
              ลองเปลี่ยนคำค้นหา หรือกดปุ่มล้างคำค้นหาเพื่อดูรายการธุรกรรมทั้งหมด
            </div>
            <div style={{ display: "flex", justifyContent: "center", gap: 8, marginTop: 12 }}>
              {searchQuery && (
                <button
                  onClick={() => setSearchQuery("")}
                  style={{
                    background: "#3C5A45",
                    color: "#FFFFFF",
                    border: "none",
                    borderRadius: 6,
                    padding: "6px 14px",
                    fontSize: 12.5,
                    fontWeight: 600,
                    cursor: "pointer",
                    fontFamily: "Sarabun, sans-serif",
                  }}
                >
                  ล้างคำค้นหา
                </button>
              )}
              {filterType !== "all" && (
                <button
                  onClick={() => setFilterType("all")}
                  style={{
                    background: "#FFFFFF",
                    color: "#3C5A45",
                    border: "1px solid #D5DFD7",
                    borderRadius: 6,
                    padding: "6px 14px",
                    fontSize: 12.5,
                    fontWeight: 600,
                    cursor: "pointer",
                    fontFamily: "Sarabun, sans-serif",
                  }}
                >
                  แสดงทุกประเภท
                </button>
              )}
            </div>
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {displayedRecent.map((t, idx) => {
              const item = inv.items.find((i) => i.id === t.itemId);
              const lot = inv.lots.find((l) => l.id === t.lotId);
              const isReceive = t.type === "in";
              const timeInfo = formatTransactionTimestamp(t);

              return (
                <div
                  key={t.id}
                  id={`activity-feed-item-${idx + 1}`}
                  style={{
                    background: isReceive ? "#FCFAF6" : "#FFFBFB",
                    border: isReceive ? "1px solid #EBE7DA" : "1px solid #F5E6E4",
                    borderRadius: 8,
                    padding: "12px 14px",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    flexWrap: "wrap",
                    gap: 12,
                    transition: "all 0.15s ease",
                  }}
                >
                  {/* Left: Type Badge & Herb Details */}
                  <div style={{ display: "flex", alignItems: "center", gap: 12, minWidth: 260 }}>
                    {/* Direction Icon Badge */}
                    <div
                      style={{
                        width: 36,
                        height: 36,
                        borderRadius: 8,
                        background: isReceive ? "#EEF3EF" : "#FBF0EF",
                        border: isReceive ? "1px solid #D5E2D8" : "1px solid #F3D2CF",
                        color: isReceive ? "#2E683D" : "#A83B32",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        flexShrink: 0,
                      }}
                      title={isReceive ? "รับเข้าสต็อก (Received)" : "เบิกจ่ายออกจากสต็อก (Issued)"}
                    >
                      {isReceive ? <ArrowDownLeft size={18} /> : <ArrowUpRight size={18} />}
                    </div>

                    <div>
                      <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                        <span
                          style={{
                            fontWeight: 700,
                            fontSize: 14,
                            color: "#1F2D24",
                          }}
                        >
                          {item?.name || "ไม่ทราบชื่อยา"}
                        </span>

                        <span
                          style={{
                            padding: "1px 7px",
                            borderRadius: 4,
                            fontSize: 11,
                            fontWeight: 700,
                            background: isReceive ? "#E8F0EA" : "#FBEDEB",
                            color: isReceive ? "#2D683D" : "#A83B32",
                            border: isReceive ? "1px solid #C8DDD0" : "1px solid #F1C3BF",
                          }}
                        >
                          {isReceive ? "รับเข้า (Received)" : "เบิกออก (Issued)"}
                        </span>

                        {item?.category && (
                          <span
                            style={{
                              fontSize: 11,
                              color: "#6B726D",
                              background: "#F1EFE8",
                              padding: "1px 6px",
                              borderRadius: 4,
                            }}
                          >
                            {item.category}
                          </span>
                        )}
                      </div>

                      <div style={{ display: "flex", alignItems: "center", gap: 10, marginTop: 4, fontSize: 12, color: "#6A7B6E", flexWrap: "wrap" }}>
                        {lot?.lotNo && (
                          <button
                            onClick={() => onOpenLotLifecycle?.(lot.id)}
                            style={{
                              display: "inline-flex",
                              alignItems: "center",
                              gap: 3,
                              background: "#EEF3EF",
                              border: "1px solid #C8DDD0",
                              borderRadius: 4,
                              padding: "1px 6px",
                              cursor: "pointer",
                              fontSize: 11,
                              color: "#2D4834",
                              fontFamily: "Sarabun, sans-serif",
                            }}
                            title={`คลิกเพื่อดูวงจรชีวิตล็อต ${lot.lotNo} ตั้งแต่รับเข้าจนหมดสต็อก`}
                          >
                            <Tag size={11} color="#3C5A45" />
                            <span>ล็อต: <b style={{ color: "#2D4834" }}>{lot.lotNo}</b></span>
                          </button>
                        )}
                        {t.note && (
                          <span style={{ color: "#746E5D", fontStyle: "italic" }}>
                            "{t.note}"
                          </span>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Middle: Quantity */}
                  <div style={{ textAlign: "right", minWidth: 90 }}>
                    <div
                      style={{
                        fontWeight: 700,
                        fontSize: 15,
                        color: isReceive ? "#2E683D" : "#A83B32",
                      }}
                    >
                      {isReceive ? `+${t.qty}` : `-${t.qty}`} {item?.unit || "หน่วย"}
                    </div>
                    {item?.price && item.price > 0 && (
                      <div style={{ fontSize: 11, color: "#8A8874" }}>
                        ≈ ฿{(t.qty * item.price).toLocaleString()}
                      </div>
                    )}
                  </div>

                  {/* Right: User and Timestamps (Prompt requirement: user names and timestamps) */}
                  <div
                    style={{
                      display: "flex",
                      flexDirection: "column",
                      alignItems: "flex-end",
                      gap: 4,
                      minWidth: 170,
                      paddingLeft: 8,
                      borderLeft: "1px solid #EBE7DA",
                    }}
                  >
                    {/* User Name */}
                    <div
                      id={`feed-item-user-${idx + 1}`}
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 5,
                        fontSize: 12.5,
                        fontWeight: 600,
                        color: "#2A382C",
                        background: "#EEF3EF",
                        padding: "2px 8px",
                        borderRadius: 6,
                        border: "1px solid #DFE7E1",
                      }}
                    >
                      <User size={12} color="#3C5A45" />
                      <span>{t.user || "เจ้าหน้าที่"}</span>
                    </div>

                    {/* Timestamp */}
                    <div
                      id={`feed-item-timestamp-${idx + 1}`}
                      style={{
                        display: "inline-flex",
                        alignItems: "center",
                        gap: 5,
                        fontSize: 11.5,
                        color: "#5C6A60",
                      }}
                      title={`วันที่บันทึก: ${fmtDate(t.date)} ${t.timestamp ? `(เวลา ${new Date(t.timestamp).toLocaleTimeString()})` : ""}`}
                    >
                      <Clock size={11} color="#8A8874" />
                      <span>{timeInfo.full}</span>
                      {timeInfo.relative && timeInfo.relative !== timeInfo.full && (
                        <span
                          style={{
                            background: "#EBEAE1",
                            color: "#5B5747",
                            padding: "0 5px",
                            borderRadius: 4,
                            fontSize: 10.5,
                            fontWeight: 600,
                          }}
                        >
                          {timeInfo.relative}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Panel>
    </div>
  );
}
