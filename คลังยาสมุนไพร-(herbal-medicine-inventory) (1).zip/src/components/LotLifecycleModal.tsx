import React, { useMemo } from "react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ReferenceLine,
} from "recharts";
import {
  X,
  Package,
  Calendar,
  Clock,
  ArrowDownLeft,
  ArrowUpRight,
  CheckCircle2,
  AlertTriangle,
  Building,
  User,
  ShieldCheck,
  Printer,
  ChevronRight,
  Flag,
  RotateCcw,
  Sparkles,
  TrendingDown,
} from "lucide-react";
import type { InventoryState, StockTransaction, HerbalLot, HerbalItem } from "../types";
import { fmtDate, daysUntil } from "../utils/storage";

interface LotLifecycleModalProps {
  isOpen: boolean;
  onClose: () => void;
  lotId: string | null;
  inv: InventoryState;
  tx: StockTransaction[];
  onNavigateToMove?: (itemId: string, lotId?: string) => void;
  showToast?: (msg: string) => void;
}

export function LotLifecycleModal({
  isOpen,
  onClose,
  lotId,
  inv,
  tx,
  onNavigateToMove,
  showToast = () => {},
}: LotLifecycleModalProps) {
  if (!isOpen || !lotId) return null;

  // Locate the lot in inventory
  const lot = inv.lots.find((l) => l.id === lotId);

  // Locate the parent medicine item
  const item = inv.items.find((i) => i.id === lot?.itemId);

  // Chronologically sorted transactions associated with this lot
  const lotHistory = useMemo(() => {
    const matching = tx.filter((t) => t.lotId === lotId);

    // Sort chronologically ascending (from entry to latest dispensation)
    return [...matching].sort((a, b) => {
      const timeA = a.timestamp ? new Date(a.timestamp).getTime() : new Date(a.date + "T00:00:00").getTime();
      const timeB = b.timestamp ? new Date(b.timestamp).getTime() : new Date(b.date + "T00:00:00").getTime();
      return timeA - timeB;
    });
  }, [tx, lotId]);

  // Calculate lifecycle metrics step by step
  const lifecycle = useMemo(() => {
    let runningBalance = 0;
    let totalInflow = 0;
    let totalOutflow = 0;
    let firstInDate = lot?.receivedDate || "";
    let finalDepletionDate = "";

    const timelineEvents = lotHistory.map((t, index) => {
      if (t.type === "in") {
        runningBalance += t.qty;
        totalInflow += t.qty;
        if (!firstInDate) firstInDate = t.date;
      } else {
        runningBalance = Math.max(0, runningBalance - t.qty);
        totalOutflow += t.qty;
        if (runningBalance === 0 && !finalDepletionDate) {
          finalDepletionDate = t.date;
        }
      }

      return {
        ...t,
        balanceAfter: runningBalance,
        eventIndex: index + 1,
      };
    });

    // If totalInflow is 0 (e.g. lot created directly without a logged in transaction), fallback
    const effectiveTotalReceived = totalInflow > 0 ? totalInflow : (lot?.qty || 0) + totalOutflow;
    const currentBalance = lot ? lot.qty : runningBalance;
    const isDepleted = currentBalance === 0;

    // Depletion progress percentage
    const depletionPct = effectiveTotalReceived > 0
      ? Math.min(100, Math.round((totalOutflow / effectiveTotalReceived) * 100))
      : (isDepleted ? 100 : 0);

    // Calculate shelf-life & age in warehouse
    const expiry = lot?.expiryDate || "";
    const daysToExpiry = expiry ? daysUntil(expiry) : 999;
    const isExpired = daysToExpiry < 0;
    const isNearExpiry = daysToExpiry <= 90 && daysToExpiry >= 0;

    // Days in inventory
    const entryDateObj = new Date((firstInDate || lot?.receivedDate || "") + "T00:00:00");
    const endDateObj = isDepleted && finalDepletionDate
      ? new Date(finalDepletionDate + "T00:00:00")
      : new Date();
    
    let daysInInventory = 0;
    if (!isNaN(entryDateObj.getTime()) && !isNaN(endDateObj.getTime())) {
      daysInInventory = Math.max(0, Math.ceil((endDateObj.getTime() - entryDateObj.getTime()) / (1000 * 60 * 60 * 24)));
    }

    return {
      timelineEvents,
      totalReceived: effectiveTotalReceived,
      totalDispensed: totalOutflow,
      currentBalance,
      isDepleted,
      depletionPct,
      daysToExpiry,
      isExpired,
      isNearExpiry,
      daysInInventory,
      firstInDate,
      finalDepletionDate,
    };
  }, [lot, lotHistory]);

  // Points for quantity depletion line chart over time
  const depletionChartData = useMemo(() => {
    if (!lot) return [];

    const points: {
      date: string;
      displayDate: string;
      fullDate: string;
      qty: number;
      changeText?: string;
      note?: string;
      user?: string;
      event: string;
      pct: number;
    }[] = [];

    const initialDate = lot.receivedDate || lifecycle.firstInDate || "";
    const initialQty = lifecycle.totalReceived;

    // 1. Initial Batch Receipt Point
    points.push({
      date: initialDate,
      displayDate: fmtDate(initialDate),
      fullDate: initialDate,
      qty: initialQty,
      changeText: `+${initialQty} ${item?.unit || "หน่วย"}`,
      note: "รับเข้าคลังครั้งแรก",
      event: "รับเข้าคลัง",
      pct: 100,
    });

    let runningBal = initialQty;

    // 2. Add points for each transaction in the timeline
    lifecycle.timelineEvents.forEach((t) => {
      // If the very first transaction in tx is an in-type matching the initial receipt, annotate point 0
      if (t.type === "in" && t.date === initialDate && t.qty === initialQty && points.length === 1) {
        points[0].user = t.user;
        if (t.note) points[0].note = t.note;
        return;
      }

      runningBal = t.balanceAfter;
      const pct = initialQty > 0 ? Math.round((runningBal / initialQty) * 100) : 0;

      points.push({
        date: t.date,
        displayDate: fmtDate(t.date),
        fullDate: t.date,
        qty: runningBal,
        changeText: t.type === "in" ? `+${t.qty} ${item?.unit || "หน่วย"}` : `-${t.qty} ${item?.unit || "หน่วย"}`,
        note: t.note,
        user: t.user,
        event: t.type === "in" ? "รับเข้าเพิ่ม" : "เบิกจ่าย",
        pct,
      });
    });

    // 3. If batch is active (not depleted) and last point is before today, add current state point
    const todayStr = new Date().toISOString().slice(0, 10);
    const lastPointDate = points.length > 0 ? points[points.length - 1].date : "";
    if (!lifecycle.isDepleted && lastPointDate && lastPointDate < todayStr) {
      const curPct = initialQty > 0 ? Math.round((lifecycle.currentBalance / initialQty) * 100) : 0;
      points.push({
        date: todayStr,
        displayDate: "ปัจจุบัน",
        fullDate: todayStr,
        qty: lifecycle.currentBalance,
        changeText: `คงเหลือ ${lifecycle.currentBalance} ${item?.unit || "หน่วย"}`,
        note: "สต็อกพร้อมใช้งานในปัจจุบัน",
        event: "คงเหลือปัจจุบัน",
        pct: curPct,
      });
    }

    return points;
  }, [lot, lifecycle, item]);

  if (!lot && !item) {
    return (
      <div
        id="modal-lot-lifecycle-overlay"
        style={{
          position: "fixed",
          top: 0,
          left: 0,
          right: 0,
          bottom: 0,
          background: "rgba(0,0,0,0.5)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          zIndex: 1100,
        }}
        onClick={onClose}
      >
        <div style={{ background: "#fff", padding: 24, borderRadius: 10, maxWidth: 400, textAlign: "center" }}>
          <div style={{ color: "#A83B32", fontWeight: 700, fontSize: 16 }}>ไม่พบข้อมูลล็อตยานี้ในระบบ</div>
          <button onClick={onClose} style={{ marginTop: 12, padding: "6px 14px", borderRadius: 6, border: "none", background: "#3C5A45", color: "#fff", cursor: "pointer" }}>
            ปิดหน้าต่าง
          </button>
        </div>
      </div>
    );
  }

  function handlePrint() {
    window.print();
  }

  function handleIssueFromLot() {
    if (onNavigateToMove && lot) {
      onNavigateToMove(lot.itemId, lot.id);
      onClose();
    }
  }

  return (
    <div
      id="modal-lot-lifecycle-overlay"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: "rgba(0, 0, 0, 0.6)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1100,
        padding: "16px",
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        style={{
          background: "#FFFFFF",
          borderRadius: 12,
          width: "100%",
          maxWidth: 780,
          maxHeight: "92vh",
          display: "flex",
          flexDirection: "column",
          boxShadow: "0 20px 50px rgba(0, 0, 0, 0.35)",
          overflow: "hidden",
        }}
      >
        {/* Header */}
        <div
          style={{
            padding: "16px 22px",
            background: "#2D4834",
            color: "#FFFFFF",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 12,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div
              style={{
                background: "rgba(255, 255, 255, 0.15)",
                padding: "8px",
                borderRadius: 8,
                display: "flex",
              }}
            >
              <Package size={22} color="#FFFFFF" />
            </div>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, fontFamily: "'Noto Serif Thai', serif" }}>
                  วงจรชีวิตล็อตยา (Lot Lifecycle History)
                </h2>
                <span
                  style={{
                    background: "rgba(255, 255, 255, 0.2)",
                    fontSize: 11.5,
                    padding: "2px 8px",
                    borderRadius: 12,
                    fontWeight: 600,
                  }}
                >
                  ล็อต #{lot?.lotNo || "ไม่ระบุ"}
                </span>
              </div>
              <div style={{ fontSize: 12.5, opacity: 0.88, marginTop: 2 }}>
                {item?.name || "ไม่ทราบชื่อยา"} · หมวดหมู่: {item?.category || "เวชภัณฑ์"}
              </div>
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
            <button
              id="btn-print-lot-lifecycle"
              onClick={handlePrint}
              style={{
                background: "rgba(255, 255, 255, 0.15)",
                color: "#FFFFFF",
                border: "1px solid rgba(255, 255, 255, 0.3)",
                borderRadius: 6,
                padding: "6px 12px",
                fontSize: 12.5,
                fontWeight: 600,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 5,
                fontFamily: "Sarabun, sans-serif",
              }}
              title="พิมพ์ใบรายงานประวัติล็อตยา"
            >
              <Printer size={14} />
              <span>พิมพ์</span>
            </button>

            <button
              id="btn-close-lot-modal"
              onClick={onClose}
              style={{
                background: "transparent",
                border: "none",
                color: "#FFFFFF",
                cursor: "pointer",
                padding: "4px",
                opacity: 0.85,
              }}
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px", background: "#FAF9F5" }}>
          {/* Status Alert Banner */}
          <div
            style={{
              padding: "12px 16px",
              borderRadius: 8,
              marginBottom: 18,
              display: "flex",
              justifyContent: "space-between",
              alignItems: "center",
              flexWrap: "wrap",
              gap: 12,
              background: lifecycle.isDepleted
                ? "#F0EEF8"
                : lifecycle.isExpired
                ? "#FBEDEB"
                : lifecycle.isNearExpiry
                ? "#FBF7ED"
                : "#EEF3EF",
              border: lifecycle.isDepleted
                ? "1px solid #D6D0EA"
                : lifecycle.isExpired
                ? "1px solid #F1C3BF"
                : lifecycle.isNearExpiry
                ? "1px solid #ECD9AA"
                : "1px solid #C8D8CB",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
              {lifecycle.isDepleted ? (
                <div style={{ background: "#6B5B95", color: "#fff", padding: 6, borderRadius: "50%", display: "flex" }}>
                  <CheckCircle2 size={16} />
                </div>
              ) : lifecycle.isExpired ? (
                <div style={{ background: "#A83B32", color: "#fff", padding: 6, borderRadius: "50%", display: "flex" }}>
                  <AlertTriangle size={16} />
                </div>
              ) : lifecycle.isNearExpiry ? (
                <div style={{ background: "#C08A2E", color: "#fff", padding: 6, borderRadius: "50%", display: "flex" }}>
                  <Clock size={16} />
                </div>
              ) : (
                <div style={{ background: "#3C5A45", color: "#fff", padding: 6, borderRadius: "50%", display: "flex" }}>
                  <ShieldCheck size={16} />
                </div>
              )}

              <div>
                <div style={{ fontWeight: 700, fontSize: 13.5, color: "#1F2D24" }}>
                  {lifecycle.isDepleted
                    ? "สถานะ: เบิกจ่ายครบถ้วนสมบูรณ์ (Fully Depleted)"
                    : lifecycle.isExpired
                    ? "สถานะ: ยาหมดอายุแล้ว (Expired)"
                    : lifecycle.isNearExpiry
                    ? `สถานะ: ยาใกล้หมดอายุใน ${lifecycle.daysToExpiry} วัน (Near Expiry)`
                    : "สถานะ: กำลังใช้งานในคลังปกติ (Active Stock)"}
                </div>
                <div style={{ fontSize: 12, color: "#5F6C62", marginTop: 1 }}>
                  {lifecycle.isDepleted
                    ? `ล็อตนี้ปิดการใช้งานเมื่อวันที่ ${fmtDate(lifecycle.finalDepletionDate)} รวมระยะเวลาหมุนเวียน ${lifecycle.daysInInventory} วัน`
                    : `คงเหลือ ${lifecycle.currentBalance} ${item?.unit || "หน่วย"} (วันหมดอายุ: ${fmtDate(lot?.expiryDate)})`}
                </div>
              </div>
            </div>

            {/* If still in stock, allow quick issue */}
            {!lifecycle.isDepleted && onNavigateToMove && (
              <button
                id="btn-modal-issue-from-lot"
                onClick={handleIssueFromLot}
                style={{
                  background: "#3C5A45",
                  color: "#FFFFFF",
                  border: "none",
                  borderRadius: 6,
                  padding: "6px 14px",
                  fontSize: 12.5,
                  fontWeight: 600,
                  cursor: "pointer",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 5,
                  fontFamily: "Sarabun, sans-serif",
                }}
              >
                <ArrowUpRight size={13} />
                <span>เบิกจ่ายจากล็อตนี้</span>
              </button>
            )}
          </div>

          {/* Depletion Progress Gauge */}
          <div
            style={{
              background: "#FFFFFF",
              border: "1px solid #E5E0D2",
              borderRadius: 8,
              padding: "14px 18px",
              marginBottom: 18,
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 6 }}>
              <span style={{ fontSize: 12.5, fontWeight: 700, color: "#2D4834" }}>
                ความคืบหน้าการเบิกจ่ายของล็อต (Lifecycle Depletion Progress):
              </span>
              <span style={{ fontSize: 13, fontWeight: 800, color: lifecycle.isDepleted ? "#6B5B95" : "#3C5A45" }}>
                {lifecycle.depletionPct}% เบิกจ่ายแล้ว
              </span>
            </div>

            {/* Progress Track */}
            <div style={{ height: 10, background: "#EAE6DA", borderRadius: 5, overflow: "hidden", position: "relative" }}>
              <div
                style={{
                  height: "100%",
                  width: `${lifecycle.depletionPct}%`,
                  background: lifecycle.isDepleted
                    ? "#6B5B95"
                    : lifecycle.depletionPct > 80
                    ? "#C08A2E"
                    : "#3C5A45",
                  borderRadius: 5,
                  transition: "width 0.4s ease",
                }}
              />
            </div>

            <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11.5, color: "#746E5D", marginTop: 6 }}>
              <span>รับเข้า: <b>{lifecycle.totalReceived} {item?.unit}</b></span>
              <span>เบิกจ่ายแล้ว: <b>{lifecycle.totalDispensed} {item?.unit}</b></span>
              <span>คงเหลือ: <b>{lifecycle.currentBalance} {item?.unit}</b></span>
            </div>
          </div>

          {/* 4 KPI Milestone Cards */}
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "repeat(4, 1fr)",
              gap: 12,
              marginBottom: 22,
            }}
          >
            <div style={{ background: "#FFFFFF", border: "1px solid #E5E0D2", borderRadius: 8, padding: "10px 12px" }}>
              <div style={{ fontSize: 11, color: "#8A8874" }}>ยอดรับเข้าแรกเริ่ม</div>
              <div style={{ fontSize: 17, fontWeight: 800, color: "#3C5A45", marginTop: 2 }}>
                {lifecycle.totalReceived} <span style={{ fontSize: 11, fontWeight: 500 }}>{item?.unit}</span>
              </div>
              <div style={{ fontSize: 11, color: "#5B7A63", marginTop: 1 }}>{fmtDate(lot?.receivedDate)}</div>
            </div>

            <div style={{ background: "#FFFFFF", border: "1px solid #E5E0D2", borderRadius: 8, padding: "10px 12px" }}>
              <div style={{ fontSize: 11, color: "#8A8874" }}>เบิกจ่ายสะสม</div>
              <div style={{ fontSize: 17, fontWeight: 800, color: "#A83B32", marginTop: 2 }}>
                {lifecycle.totalDispensed} <span style={{ fontSize: 11, fontWeight: 500 }}>{item?.unit}</span>
              </div>
              <div style={{ fontSize: 11, color: "#8A8874", marginTop: 1 }}>{lotHistory.filter((t) => t.type === "out").length} ครั้ง</div>
            </div>

            <div style={{ background: "#FFFFFF", border: "1px solid #E5E0D2", borderRadius: 8, padding: "10px 12px" }}>
              <div style={{ fontSize: 11, color: "#8A8874" }}>ยอดคงเหลือในล็อต</div>
              <div style={{ fontSize: 17, fontWeight: 800, color: lifecycle.currentBalance === 0 ? "#6B5B95" : "#1F2D24", marginTop: 2 }}>
                {lifecycle.currentBalance} <span style={{ fontSize: 11, fontWeight: 500 }}>{item?.unit}</span>
              </div>
              <div style={{ fontSize: 11, color: "#8A8874", marginTop: 1 }}>
                {lifecycle.currentBalance === 0 ? "หมดสต็อกแล้ว" : `มูลค่า ฿${((lifecycle.currentBalance) * (Number(item?.price) || 0)).toLocaleString()}`}
              </div>
            </div>

            <div style={{ background: "#FFFFFF", border: "1px solid #E5E0D2", borderRadius: 8, padding: "10px 12px" }}>
              <div style={{ fontSize: 11, color: "#8A8874" }}>ระยะเวลาในคลัง</div>
              <div style={{ fontSize: 17, fontWeight: 800, color: "#8E691A", marginTop: 2 }}>
                {lifecycle.daysInInventory} <span style={{ fontSize: 11, fontWeight: 500 }}>วัน</span>
              </div>
              <div style={{ fontSize: 11, color: "#8E691A", marginTop: 1 }}>
                {lifecycle.isDepleted ? "ถึงวันเบิกหมด" : `หมดอายุใน ${lifecycle.daysToExpiry} ว.`}
              </div>
            </div>
          </div>

          {/* Small Line Chart: Batch Quantity Depletion Trend Over Time */}
          <div
            id="batch-depletion-chart-card"
            style={{
              background: "#FFFFFF",
              border: "1px solid #E5E0D2",
              borderRadius: 8,
              padding: "16px 20px",
              marginBottom: 20,
            }}
          >
            <div
              style={{
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                flexWrap: "wrap",
                gap: 8,
                marginBottom: 12,
              }}
            >
              <div>
                <div style={{ fontWeight: 700, fontSize: 14, color: "#1F2D24", display: "flex", alignItems: "center", gap: 6 }}>
                  <TrendingDown size={16} color={lifecycle.isDepleted ? "#6B5B95" : "#3C5A45"} />
                  <span>แนวโน้มการลดลงของจำนวนยาในล็อต (Batch Quantity Depletion Trend)</span>
                </div>
                <div style={{ fontSize: 11.5, color: "#8A8874", marginTop: 2 }}>
                  กราฟแสดงการทยอยเบิกจ่ายยาคงเหลือในล็อตนี้ตามลำดับเวลาตั้งแต่รับเข้าจนถึงปัจจุบัน / เบิกหมดสิ้น
                </div>
              </div>

              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <span
                  style={{
                    fontSize: 11.5,
                    padding: "3px 9px",
                    borderRadius: 12,
                    fontWeight: 700,
                    background: lifecycle.isDepleted ? "#F0EEF8" : "#EEF3EF",
                    color: lifecycle.isDepleted ? "#6B5B95" : "#2D683D",
                    border: lifecycle.isDepleted ? "1px solid #D6D0EA" : "1px solid #C8DDD0",
                  }}
                >
                  {lifecycle.isDepleted
                    ? "เบิกหมด 0 หน่วย (100%)"
                    : `คงเหลือ ${lifecycle.currentBalance} ${item?.unit || "หน่วย"} (${100 - lifecycle.depletionPct}%)`}
                </span>
              </div>
            </div>

            {depletionChartData.length <= 1 ? (
              <div style={{ textAlign: "center", padding: "26px 0", color: "#8A8874", fontSize: 12.5 }}>
                มีบันทึก 1 จุดรับเข้า ยังไม่มีประวัติการเบิกจ่ายจากล็อตนี้ (คงเหลือ 100%)
              </div>
            ) : (
              <div style={{ width: "100%", height: 180 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <AreaChart data={depletionChartData} margin={{ top: 10, right: 15, left: -15, bottom: 0 }}>
                    <defs>
                      <linearGradient id="depletionFill" x1="0" y1="0" x2="0" y2="1">
                        <stop offset="5%" stopColor={lifecycle.isDepleted ? "#6B5B95" : "#3C5A45"} stopOpacity={0.25} />
                        <stop offset="95%" stopColor={lifecycle.isDepleted ? "#6B5B95" : "#3C5A45"} stopOpacity={0.0} />
                      </linearGradient>
                    </defs>
                    <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EBE8DC" />
                    <XAxis
                      dataKey="displayDate"
                      stroke="#8A8874"
                      fontSize={11}
                      tickLine={false}
                    />
                    <YAxis
                      stroke="#8A8874"
                      fontSize={11}
                      tickLine={false}
                      axisLine={false}
                      domain={[0, (dataMax: number) => Math.max(dataMax, 5)]}
                    />
                    <Tooltip content={<DepletionTooltip unit={item?.unit} />} />
                    <ReferenceLine y={0} stroke="#D8D3C2" strokeDasharray="2 2" />
                    <Area
                      type="monotone"
                      dataKey="qty"
                      name="คงเหลือในล็อต"
                      stroke={lifecycle.isDepleted ? "#6B5B95" : "#3C5A45"}
                      strokeWidth={2.5}
                      fillOpacity={1}
                      fill="url(#depletionFill)"
                      dot={{
                        r: 4,
                        strokeWidth: 2,
                        fill: "#FFFFFF",
                        stroke: lifecycle.isDepleted ? "#6B5B95" : "#3C5A45",
                      }}
                      activeDot={{
                        r: 6,
                        fill: lifecycle.isDepleted ? "#6B5B95" : "#3C5A45",
                        stroke: "#FFFFFF",
                        strokeWidth: 2,
                      }}
                    />
                  </AreaChart>
                </ResponsiveContainer>
              </div>
            )}
          </div>

          {/* Chronological Timeline: Entry to Final Depletion */}
          <div
            style={{
              background: "#FFFFFF",
              border: "1px solid #E5E0D2",
              borderRadius: 8,
              padding: "18px 20px",
            }}
          >
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <div style={{ fontWeight: 700, fontSize: 14.5, color: "#1F2D24", display: "flex", alignItems: "center", gap: 6 }}>
                <Clock size={16} color="#3C5A45" />
                <span>ลำดับเหตุการณ์ในวงจรชีวิต (Batch Lifecycle Timeline)</span>
              </div>
              <span style={{ fontSize: 12, color: "#8A8874" }}>
                ทั้งหมด {lifecycle.timelineEvents.length + 1} เหตุการณ์
              </span>
            </div>

            {/* Vertical Stepper Timeline */}
            <div style={{ position: "relative", paddingLeft: 24, display: "flex", flexDirection: "column", gap: 18 }}>
              {/* Vertical connecting line */}
              <div
                style={{
                  position: "absolute",
                  left: 9,
                  top: 8,
                  bottom: 12,
                  width: 2,
                  background: "#D8D3C2",
                }}
              />

              {/* Step 1: Initial Batch Entry (If not already first event in tx) */}
              <div style={{ position: "relative" }}>
                {/* Node icon */}
                <div
                  style={{
                    position: "absolute",
                    left: -24,
                    top: 2,
                    width: 20,
                    height: 20,
                    borderRadius: "50%",
                    background: "#3C5A45",
                    color: "#FFFFFF",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    fontSize: 11,
                    fontWeight: 700,
                  }}
                >
                  <ArrowDownLeft size={12} />
                </div>

                <div
                  style={{
                    background: "#F5F8F6",
                    border: "1px solid #D5E2D8",
                    borderRadius: 6,
                    padding: "10px 14px",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 6 }}>
                    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                      <span style={{ fontWeight: 700, fontSize: 13, color: "#2D4834" }}>
                        จุดเริ่มต้น: รับเข้าคลัง (Batch Entry)
                      </span>
                      <span style={{ background: "#3C5A45", color: "#fff", fontSize: 10.5, fontWeight: 700, padding: "1px 6px", borderRadius: 4 }}>
                        +{lifecycle.totalReceived} {item?.unit}
                      </span>
                    </div>
                    <span style={{ fontSize: 11.5, color: "#5F6C62" }}>
                      วันที่: {fmtDate(lot?.receivedDate)}
                    </span>
                  </div>

                  <div style={{ fontSize: 12, color: "#556358", marginTop: 6, display: "flex", gap: 14, flexWrap: "wrap" }}>
                    <span>ล็อตหมายเลข: <b>{lot?.lotNo}</b></span>
                    <span>วันหมดอายุที่ระบุ: <b>{fmtDate(lot?.expiryDate)}</b></span>
                    {item?.supplier && <span>ผู้จัดจำหน่าย: <b>{item.supplier}</b></span>}
                  </div>
                </div>
              </div>

              {/* Transactions in timeline */}
              {lifecycle.timelineEvents.map((t, idx) => {
                const isReceive = t.type === "in";
                return (
                  <div key={t.id} style={{ position: "relative" }}>
                    {/* Node icon */}
                    <div
                      style={{
                        position: "absolute",
                        left: -24,
                        top: 2,
                        width: 20,
                        height: 20,
                        borderRadius: "50%",
                        background: isReceive ? "#3C5A45" : "#A83B32",
                        color: "#FFFFFF",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontSize: 11,
                        fontWeight: 700,
                      }}
                    >
                      {isReceive ? <ArrowDownLeft size={12} /> : <ArrowUpRight size={12} />}
                    </div>

                    <div
                      style={{
                        background: isReceive ? "#F5F8F6" : "#FCFAF8",
                        border: isReceive ? "1px solid #D5E2D8" : "1px solid #EFE4E2",
                        borderRadius: 6,
                        padding: "10px 14px",
                      }}
                    >
                      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 6 }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                          <span style={{ fontWeight: 700, fontSize: 13, color: isReceive ? "#2D4834" : "#A83B32" }}>
                            {isReceive ? "รับเข้าเพิ่มในล็อต" : `การเบิกจ่ายครั้งที่ ${idx + 1}`}
                          </span>
                          <span
                            style={{
                              background: isReceive ? "#3C5A45" : "#A83B32",
                              color: "#FFFFFF",
                              fontSize: 11,
                              fontWeight: 700,
                              padding: "1px 7px",
                              borderRadius: 4,
                            }}
                          >
                            {isReceive ? `+${t.qty}` : `-${t.qty}`} {item?.unit}
                          </span>
                          <span style={{ fontSize: 11.5, color: "#6A7B6E" }}>
                            (คงเหลือในล็อตหลังรายการ: <b>{t.balanceAfter} {item?.unit}</b>)
                          </span>
                        </div>

                        <span style={{ fontSize: 11.5, color: "#8A8874" }}>
                          {fmtDate(t.date)}
                        </span>
                      </div>

                      <div style={{ fontSize: 12, color: "#556358", marginTop: 5, display: "flex", gap: 14, flexWrap: "wrap" }}>
                        <span>ผู้ทำรายการ: <b>{t.user}</b></span>
                        {t.note && <span>วัตถุประสงค์ / หมายเหตุ: <em>"{t.note}"</em></span>}
                      </div>
                    </div>
                  </div>
                );
              })}

              {/* Final Milestone: Final Depletion OR Current State */}
              <div style={{ position: "relative" }}>
                <div
                  style={{
                    position: "absolute",
                    left: -24,
                    top: 2,
                    width: 20,
                    height: 20,
                    borderRadius: "50%",
                    background: lifecycle.isDepleted ? "#6B5B95" : "#2E5739",
                    color: "#FFFFFF",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  {lifecycle.isDepleted ? <Flag size={12} /> : <CheckCircle2 size={12} />}
                </div>

                <div
                  style={{
                    background: lifecycle.isDepleted ? "#F6F4FA" : "#EEF3EF",
                    border: lifecycle.isDepleted ? "1.5px solid #C4BDD9" : "1.5px solid #B8CEBC",
                    borderRadius: 6,
                    padding: "12px 14px",
                  }}
                >
                  <div style={{ fontWeight: 700, fontSize: 13.5, color: lifecycle.isDepleted ? "#4E3E73" : "#1F3D26" }}>
                    {lifecycle.isDepleted
                      ? "ปลายทางของล็อต: ปิดยอดเบิกจ่ายสมบูรณ์ (100% Depleted)"
                      : `สถานะปัจจุบัน: ยังคงมีสต็อกพร้อมใช้ (${lifecycle.currentBalance} ${item?.unit})`}
                  </div>
                  <div style={{ fontSize: 12, color: "#5F6C62", marginTop: 3 }}>
                    {lifecycle.isDepleted
                      ? `ล็อตนี้ถูกเบิกจ่ายจนครบถ้วนตามหลักการเข้าก่อนออกก่อน (FEFO) สิ้นสุดวงจรชีวิตเวชภัณฑ์อย่างปลอดภัย`
                      : `แนะนำติดตามการเบิกจ่ายตามวันหมดอายุ ${fmtDate(lot?.expiryDate)} เพื่อป้องกันการหมดอายุค้างสต็อก`}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div
          style={{
            padding: "12px 20px",
            borderTop: "1px solid #E5E0D2",
            background: "#F9F8F3",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 10,
          }}
        >
          <div style={{ fontSize: 11.5, color: "#8A8874" }}>
            รหัสประจำล็อต: <code style={{ color: "#3C5A45" }}>{lot?.id}</code> · ข้อมูลถูกตรวจสอบตามบันทึกการเคลื่อนไหวจริง
          </div>

          <button
            id="btn-close-lifecycle-modal"
            onClick={onClose}
            style={{
              background: "#3C5A45",
              color: "#FFFFFF",
              border: "none",
              borderRadius: 6,
              padding: "6px 18px",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
              fontFamily: "Sarabun, sans-serif",
            }}
          >
            ปิด
          </button>
        </div>
      </div>
    </div>
  );
}

// Tooltip for batch depletion line chart
interface DepletionTooltipProps {
  active?: boolean;
  payload?: any[];
  label?: string;
  unit?: string;
}

function DepletionTooltip({ active, payload, unit = "หน่วย" }: DepletionTooltipProps) {
  if (!active || !payload || !payload.length) return null;
  const data = payload[0]?.payload;
  if (!data) return null;

  const isEntry = data.event === "รับเข้าคลัง" || data.event === "รับเข้าเพิ่ม";

  return (
    <div
      style={{
        background: "#1F2D24",
        color: "#EFEDE3",
        padding: "10px 14px",
        borderRadius: 8,
        fontSize: 12,
        fontFamily: "Sarabun, sans-serif",
        boxShadow: "0 6px 18px rgba(0,0,0,0.3)",
        border: "1px solid #3C5A45",
        minWidth: 190,
      }}
    >
      <div style={{ fontWeight: 700, color: "#9CB68C", borderBottom: "1px solid #3A4E3F", paddingBottom: 4, marginBottom: 6 }}>
        {data.displayDate} {data.fullDate !== data.displayDate ? `(${data.fullDate})` : ""}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
          <span style={{ color: "#B5C9BC" }}>เหตุการณ์:</span>
          <b style={{ color: isEntry ? "#9CB68C" : "#E4B7B0" }}>{data.event}</b>
        </div>
        {data.changeText && (
          <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
            <span style={{ color: "#B5C9BC" }}>การเปลี่ยนแปลง:</span>
            <b style={{ color: isEntry ? "#9CB68C" : "#E4B7B0" }}>{data.changeText}</b>
          </div>
        )}
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, borderTop: "1px dashed #3A4E3F", paddingTop: 4, marginTop: 2 }}>
          <span style={{ color: "#F0D78C" }}>คงเหลือในล็อต:</span>
          <b style={{ color: "#FFFFFF", fontSize: 13 }}>
            {data.qty} {unit} <span style={{ fontSize: 11, color: "#9CB68C", fontWeight: 500 }}>({data.pct}%)</span>
          </b>
        </div>
        {data.user && (
          <div style={{ fontSize: 11, color: "#9CB68C", marginTop: 2 }}>
            ผู้บันทึก: {data.user}
          </div>
        )}
        {data.note && (
          <div style={{ fontSize: 11, color: "#D1DDD5", marginTop: 2, fontStyle: "italic" }}>
            "{data.note}"
          </div>
        )}
      </div>
    </div>
  );
}

