import React, { useState, useEffect, useMemo } from "react";
import {
  Mail,
  Send,
  CheckCircle2,
  Clock,
  AlertTriangle,
  Settings,
  History,
  X,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  Building,
  Calendar,
  Layers,
  Sparkles,
  RefreshCw,
  Eye,
  Trash2,
  Inbox,
  ArrowRight,
  BellRing,
} from "lucide-react";
import type { InventoryState, HerbalItem, HerbalLot, MockEmailNotification, EmailAlertSettings } from "../types";
import {
  lotQtyForItem,
  fmtDate,
  daysUntil,
  today,
  uid,
  loadEmailSettings,
  saveEmailSettings,
  loadEmailLogs,
  saveEmailLogs,
} from "../utils/storage";

interface MockEmailNotificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  inv: InventoryState;
  lowStockItems: HerbalItem[];
  nearExpiryLots: HerbalLot[];
  showToast: (msg: string) => void;
  initialTab?: "preview" | "settings" | "history";
  initialType?: "combined" | "low_stock" | "near_expiry" | "digest";
  onNavigateToMove?: (itemId?: string) => void;
}

export function MockEmailNotificationModal({
  isOpen,
  onClose,
  inv,
  lowStockItems,
  nearExpiryLots,
  showToast,
  initialTab = "preview",
  initialType = "combined",
  onNavigateToMove,
}: MockEmailNotificationModalProps) {
  const [activeTab, setActiveTab] = useState<"preview" | "settings" | "history">(initialTab);
  const [alertType, setAlertType] = useState<"combined" | "low_stock" | "near_expiry" | "digest">(initialType);

  // Settings state
  const [settings, setSettings] = useState<EmailAlertSettings>({
    enabled: true,
    recipientEmail: "titee2409@gmail.com",
    notifyLowStock: true,
    notifyNearExpiry: true,
    nearExpiryDaysThreshold: 90,
    frequency: "instant",
    autoSimulateOnStockChange: true,
  });

  // Logs state
  const [emailLogs, setEmailLogs] = useState<MockEmailNotification[]>([]);
  const [selectedLogToView, setSelectedLogToView] = useState<MockEmailNotification | null>(null);

  // Send simulation state
  const [sending, setSending] = useState(false);
  const [justSentId, setJustSentId] = useState<string | null>(null);
  const [copiedText, setCopiedText] = useState(false);

  // Load settings and logs on mount
  useEffect(() => {
    if (isOpen) {
      (async () => {
        const s = await loadEmailSettings();
        const l = await loadEmailLogs();
        setSettings(s);
        setEmailLogs(l);
        setActiveTab(initialTab);
        setAlertType(initialType);
        setSelectedLogToView(null);
      })();
    }
  }, [isOpen, initialTab, initialType]);

  // Compute items details for email
  const emailLowStockItems = useMemo(() => {
    return lowStockItems.map((item) => {
      const current = lotQtyForItem(inv.lots, item.id);
      const deficit = Math.max(0, item.minStock - current);
      const qtyToOrder = item.reorderQty && item.reorderQty > 0 ? item.reorderQty : deficit;
      const estimatedCost = qtyToOrder * (Number(item.price) || 0);
      return {
        id: item.id,
        name: item.name,
        category: item.category,
        unit: item.unit,
        current,
        minStock: item.minStock,
        reorderQty: qtyToOrder,
        supplier: item.supplier,
        estimatedCost,
      };
    });
  }, [lowStockItems, inv.lots]);

  const emailNearExpiryLots = useMemo(() => {
    return nearExpiryLots.map((lot) => {
      const item = inv.items.find((i) => i.id === lot.itemId);
      const d = daysUntil(lot.expiryDate);
      return {
        lotId: lot.id,
        itemName: item?.name || "ไม่ระบุชื่อยา",
        lotNo: lot.lotNo || "-",
        qty: lot.qty,
        unit: item?.unit || "หน่วย",
        expiryDate: lot.expiryDate,
        daysLeft: d,
      };
    });
  }, [nearExpiryLots, inv.items]);

  const totalEstimatedCost = emailLowStockItems.reduce((s, it) => s + it.estimatedCost, 0);

  // Dynamic Subject line
  const generatedSubject = useMemo(() => {
    const todayTh = new Date().toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric" });
    if (alertType === "low_stock") {
      return `[แจ้งเตือนคลังยาสมุนไพร] สต็อกต่ำกว่าเกณฑ์ ${emailLowStockItems.length} รายการ (ต้องสั่งซื้อด่วน) - ${todayTh}`;
    }
    if (alertType === "near_expiry") {
      return `[แจ้งเตือนคลังยาสมุนไพร] มียาสมุนไพรใกล้หมดอายุ ${emailNearExpiryLots.length} ล็อต (≤90 วัน) - ${todayTh}`;
    }
    if (alertType === "digest") {
      return `[รายงานสรุปคลังยาสมุนไพร] ภาพรวมสถานะสต็อกยาประจำวัน - ${todayTh}`;
    }
    return `[แจ้งเตือนคลังยาสมุนไพร] ต่ำกว่าเกณฑ์ ${emailLowStockItems.length} รายการ และใกล้หมดอายุ ${emailNearExpiryLots.length} ล็อต - ${todayTh}`;
  }, [alertType, emailLowStockItems.length, emailNearExpiryLots.length]);

  // Handle Mock Send
  async function handleSendMockEmail() {
    setSending(true);

    // Simulate network delay for realistic experience
    await new Promise((res) => setTimeout(res, 800));

    const newNotification: MockEmailNotification = {
      id: uid(),
      sentAt: new Date().toISOString(),
      recipientEmail: settings.recipientEmail,
      subject: generatedSubject,
      type: alertType,
      itemCount:
        alertType === "low_stock"
          ? emailLowStockItems.length
          : alertType === "near_expiry"
          ? emailNearExpiryLots.length
          : emailLowStockItems.length + emailNearExpiryLots.length,
      lowStockItemsCount: emailLowStockItems.length,
      nearExpiryLotsCount: emailNearExpiryLots.length,
      estimatedReorderCost: totalEstimatedCost,
      status: "delivered",
      lowStockDetails: emailLowStockItems,
      nearExpiryDetails: emailNearExpiryLots,
    };

    const updatedLogs = [newNotification, ...emailLogs];
    setEmailLogs(updatedLogs);
    await saveEmailLogs(updatedLogs);

    setSending(false);
    setJustSentId(newNotification.id);
    showToast(`จำลองการส่งอีเมลแจ้งเตือนไปยัง ${settings.recipientEmail} สำเร็จแล้ว`);

    setTimeout(() => {
      setJustSentId(null);
    }, 4000);
  }

  // Handle Save Settings
  async function handleSaveSettings() {
    await saveEmailSettings(settings);
    showToast("บันทึกการตั้งค่าการแจ้งเตือนอีเมลเรียบร้อยแล้ว");
  }

  // Handle Clear Logs
  async function handleClearLogs() {
    if (confirm("ต้องการลบประวัติการส่งอีเมลจำลองทั้งหมดใช่หรือไม่?")) {
      setEmailLogs([]);
      await saveEmailLogs([]);
      setSelectedLogToView(null);
      showToast("ล้างประวัติการส่งอีเมลแล้ว");
    }
  }

  // Copy Plain Text Email Summary
  function handleCopyEmailText() {
    const textLines = [
      `หัวข้อ: ${generatedSubject}`,
      `ถึง: ${settings.recipientEmail}`,
      `ระบบ: คลังยาสมุนไพร (Herbal Medicine Inventory)`,
      `วันที่: ${new Date().toLocaleDateString("th-TH", { dateStyle: "full" })}`,
      "----------------------------------------",
    ];

    if (alertType !== "near_expiry") {
      textLines.push(`⚠️ รายการยาต่ำกว่าเกณฑ์ขั้นต่ำ (${emailLowStockItems.length} รายการ):`);
      emailLowStockItems.forEach((it, idx) => {
        textLines.push(
          `${idx + 1}. ${it.name} (${it.category}) - คงเหลือ ${it.current} / เกณฑ์ ${it.minStock} ${it.unit} (แนะนำสั่งซื้อ ${it.reorderQty} ${it.unit}, ผู้จัดจำหน่าย: ${it.supplier || "-"})`
        );
      });
      textLines.push(`ประมาณการงบประมาณสั่งซื้อ: ฿${totalEstimatedCost.toLocaleString()}`);
      textLines.push("");
    }

    if (alertType !== "low_stock") {
      textLines.push(`⏳ รายการยาสมุนไพรใกล้หมดอายุ (${emailNearExpiryLots.length} ล็อต):`);
      emailNearExpiryLots.forEach((l, idx) => {
        textLines.push(
          `${idx + 1}. ${l.itemName} ล็อต ${l.lotNo} - คงเหลือ ${l.qty} ${l.unit}, หมดอายุ ${fmtDate(l.expiryDate)} (เหลือ ${l.daysLeft} วัน)`
        );
      });
      textLines.push("");
    }

    textLines.push("----------------------------------------");
    textLines.push("อีเมลนี้ถูกส่งจำลองโดยระบบจัดการคลังยาสมุนไพร");

    navigator.clipboard.writeText(textLines.join("\n"));
    setCopiedText(true);
    showToast("คัดลอกข้อความอีเมลแจ้งเตือนแล้ว");
    setTimeout(() => setCopiedText(false), 2000);
  }

  if (!isOpen) return null;

  return (
    <div
      id="mock-email-modal-overlay"
      style={{
        position: "fixed",
        inset: 0,
        backgroundColor: "rgba(31, 45, 36, 0.65)",
        backdropFilter: "blur(4px)",
        zIndex: 9999,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        padding: 16,
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        id="mock-email-modal-container"
        style={{
          background: "#FFFFFF",
          borderRadius: 14,
          maxWidth: 900,
          width: "100%",
          maxHeight: "90vh",
          display: "flex",
          flexDirection: "column",
          boxShadow: "0 20px 50px rgba(0, 0, 0, 0.22)",
          overflow: "hidden",
          border: "1px solid #D5E2D8",
          fontFamily: "Sarabun, sans-serif",
        }}
      >
        {/* Modal Top Header */}
        <div
          style={{
            padding: "16px 22px",
            background: "linear-gradient(135deg, #2D4834 0%, #1F3224 100%)",
            color: "#FFFFFF",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            borderBottom: "1px solid #3F5E48",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div
              style={{
                background: "rgba(255, 255, 255, 0.15)",
                borderRadius: 8,
                padding: "6px 8px",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <Mail size={20} color="#9CE6B4" />
            </div>
            <div>
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <h3
                  style={{
                    margin: 0,
                    fontSize: 18,
                    fontWeight: 700,
                    fontFamily: "'Noto Serif Thai', serif",
                    color: "#FFFFFF",
                  }}
                >
                  ระบบจำลองการแจ้งเตือนอีเมล (Mock Email Notification)
                </h3>
                <span
                  style={{
                    fontSize: 11,
                    background: "rgba(156, 230, 180, 0.22)",
                    color: "#9CE6B4",
                    padding: "2px 8px",
                    borderRadius: 12,
                    fontWeight: 600,
                    border: "1px solid rgba(156, 230, 180, 0.35)",
                  }}
                >
                  โหมดจำลอง (Simulated)
                </span>
              </div>
              <div style={{ fontSize: 12.5, color: "#C5D8C9", marginTop: 2 }}>
                แจ้งเตือนสต็อกต่ำกว่าเกณฑ์ขั้นต่ำ & แจ้งเตือนยาใกล้หมดอายุไปยังอีเมลผู้รับผิดชอบโดยตรง
              </div>
            </div>
          </div>

          <button
            id="btn-close-email-modal"
            onClick={onClose}
            style={{
              background: "rgba(255, 255, 255, 0.12)",
              border: "none",
              borderRadius: "50%",
              width: 32,
              height: 32,
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              color: "#FFFFFF",
              cursor: "pointer",
            }}
          >
            <X size={18} />
          </button>
        </div>

        {/* Modal Navigation Tabs */}
        <div
          style={{
            display: "flex",
            borderBottom: "1px solid #DFE7E1",
            background: "#F7FAF8",
            padding: "0 18px",
          }}
        >
          <button
            id="tab-email-preview"
            onClick={() => setActiveTab("preview")}
            style={{
              padding: "12px 18px",
              border: "none",
              background: "none",
              fontSize: 13.5,
              fontWeight: activeTab === "preview" ? 700 : 500,
              color: activeTab === "preview" ? "#2D4834" : "#6E7B72",
              borderBottom: activeTab === "preview" ? "2.5px solid #2D4834" : "2.5px solid transparent",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            <Eye size={15} />
            <span>จำลองส่ง & พรีวิวอีเมล (Live Preview)</span>
          </button>

          <button
            id="tab-email-settings"
            onClick={() => setActiveTab("settings")}
            style={{
              padding: "12px 18px",
              border: "none",
              background: "none",
              fontSize: 13.5,
              fontWeight: activeTab === "settings" ? 700 : 500,
              color: activeTab === "settings" ? "#2D4834" : "#6E7B72",
              borderBottom: activeTab === "settings" ? "2.5px solid #2D4834" : "2.5px solid transparent",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            <Settings size={15} />
            <span>ตั้งค่าผู้รับ & กฎการแจ้งเตือน (Settings)</span>
          </button>

          <button
            id="tab-email-history"
            onClick={() => setActiveTab("history")}
            style={{
              padding: "12px 18px",
              border: "none",
              background: "none",
              fontSize: 13.5,
              fontWeight: activeTab === "history" ? 700 : 500,
              color: activeTab === "history" ? "#2D4834" : "#6E7B72",
              borderBottom: activeTab === "history" ? "2.5px solid #2D4834" : "2.5px solid transparent",
              cursor: "pointer",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            <History size={15} />
            <span>ประวัติการส่งจำลอง (Logs)</span>
            <span
              style={{
                fontSize: 11,
                padding: "1px 6px",
                borderRadius: 10,
                background: "#E2EBE4",
                color: "#2D4834",
                fontWeight: 700,
              }}
            >
              {emailLogs.length}
            </span>
          </button>
        </div>

        {/* Modal Main Content Area */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px", background: "#FDFDFD" }}>
          {/* TAB 1: PREVIEW & SIMULATE SEND */}
          {activeTab === "preview" && (
            <div>
              {/* Alert Type Selector & Send Action Bar */}
              <div
                style={{
                  background: "#FFFFFF",
                  border: "1px solid #DCE5DE",
                  borderRadius: 10,
                  padding: "14px 16px",
                  marginBottom: 18,
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  flexWrap: "wrap",
                  gap: 12,
                  boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                  <span style={{ fontSize: 13, fontWeight: 700, color: "#3B4A3F" }}>ประเภทการแจ้งเตือน:</span>
                  <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }}>
                    <button
                      onClick={() => setAlertType("combined")}
                      style={{
                        padding: "5px 12px",
                        borderRadius: 6,
                        fontSize: 12.5,
                        fontWeight: alertType === "combined" ? 700 : 500,
                        border: alertType === "combined" ? "1px solid #2D4834" : "1px solid #D5DFD7",
                        background: alertType === "combined" ? "#2D4834" : "#FFFFFF",
                        color: alertType === "combined" ? "#FFFFFF" : "#4A564D",
                        cursor: "pointer",
                      }}
                    >
                      รวมทุกรายการ (ต่ำกว่าเกณฑ์ + ใกล้หมดอายุ)
                    </button>
                    <button
                      onClick={() => setAlertType("low_stock")}
                      style={{
                        padding: "5px 12px",
                        borderRadius: 6,
                        fontSize: 12.5,
                        fontWeight: alertType === "low_stock" ? 700 : 500,
                        border: alertType === "low_stock" ? "1px solid #A83B32" : "1px solid #F2D5D3",
                        background: alertType === "low_stock" ? "#A83B32" : "#FFFFFF",
                        color: alertType === "low_stock" ? "#FFFFFF" : "#A83B32",
                        cursor: "pointer",
                      }}
                    >
                      เฉพาะสต็อกต่ำกว่าเกณฑ์ ({emailLowStockItems.length})
                    </button>
                    <button
                      onClick={() => setAlertType("near_expiry")}
                      style={{
                        padding: "5px 12px",
                        borderRadius: 6,
                        fontSize: 12.5,
                        fontWeight: alertType === "near_expiry" ? 700 : 500,
                        border: alertType === "near_expiry" ? "1px solid #C08A2E" : "1px solid #F3E6CE",
                        background: alertType === "near_expiry" ? "#C08A2E" : "#FFFFFF",
                        color: alertType === "near_expiry" ? "#FFFFFF" : "#996B1E",
                        cursor: "pointer",
                      }}
                    >
                      เฉพาะยาใกล้หมดอายุ ({emailNearExpiryLots.length})
                    </button>
                    <button
                      onClick={() => setAlertType("digest")}
                      style={{
                        padding: "5px 12px",
                        borderRadius: 6,
                        fontSize: 12.5,
                        fontWeight: alertType === "digest" ? 700 : 500,
                        border: alertType === "digest" ? "1px solid #4A6E55" : "1px solid #D5DFD7",
                        background: alertType === "digest" ? "#4A6E55" : "#FFFFFF",
                        color: alertType === "digest" ? "#FFFFFF" : "#4A564D",
                        cursor: "pointer",
                      }}
                    >
                      สรุปภาพรวมรายวัน (Daily Digest)
                    </button>
                  </div>
                </div>

                <div style={{ display: "flex", gap: 8 }}>
                  <button
                    onClick={handleCopyEmailText}
                    style={{
                      padding: "8px 14px",
                      borderRadius: 6,
                      border: "1px solid #D5DFD7",
                      background: "#FFFFFF",
                      color: "#4A564D",
                      fontSize: 12.5,
                      fontWeight: 600,
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: 6,
                    }}
                  >
                    {copiedText ? <Check size={14} color="#2D4834" /> : <Copy size={14} />}
                    <span>{copiedText ? "คัดลอกแล้ว" : "คัดลอกข้อความ"}</span>
                  </button>

                  <button
                    id="btn-simulate-send-email"
                    onClick={handleSendMockEmail}
                    disabled={sending}
                    style={{
                      padding: "8px 18px",
                      borderRadius: 6,
                      border: "none",
                      background: justSentId ? "#2E693D" : "#2D4834",
                      color: "#FFFFFF",
                      fontSize: 13,
                      fontWeight: 700,
                      cursor: sending ? "wait" : "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: 6,
                      boxShadow: "0 2px 8px rgba(45, 72, 52, 0.25)",
                      transition: "all 0.2s ease",
                    }}
                  >
                    {sending ? (
                      <>
                        <RefreshCw size={14} className="animate-spin" />
                        <span>กำลังจำลองการส่ง...</span>
                      </>
                    ) : justSentId ? (
                      <>
                        <CheckCircle2 size={14} />
                        <span>จำลองส่งสำเร็จ!</span>
                      </>
                    ) : (
                      <>
                        <Send size={14} />
                        <span>จำลองส่งอีเมลแจ้งเตือนทันที</span>
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Just Sent Alert Banner */}
              {justSentId && (
                <div
                  style={{
                    background: "#EEF8F1",
                    border: "1.5px solid #A2D6B0",
                    borderRadius: 8,
                    padding: "12px 16px",
                    marginBottom: 16,
                    display: "flex",
                    alignItems: "center",
                    gap: 10,
                    color: "#1F4E2B",
                    fontSize: 13,
                    fontWeight: 600,
                  }}
                >
                  <CheckCircle2 size={18} color="#2E693D" />
                  <span>
                    ระบบได้จำลองส่งอีเมลไปยัง <strong>{settings.recipientEmail}</strong> เรียบร้อยแล้ว
                    สามารถตรวจสอบประวัติการส่งได้ในแท็บ "ประวัติการส่งจำลอง"
                  </span>
                </div>
              )}

              {/* MOCK EMAIL CLIENT SHELL */}
              <div
                style={{
                  border: "1px solid #D5E0D8",
                  borderRadius: 10,
                  background: "#F4F7F5",
                  boxShadow: "0 4px 20px rgba(0, 0, 0, 0.04)",
                  overflow: "hidden",
                }}
              >
                {/* Email Client Header Bar */}
                <div
                  style={{
                    background: "#E8EFEA",
                    padding: "10px 16px",
                    borderBottom: "1px solid #D2DFD6",
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    fontSize: 12.5,
                  }}
                >
                  <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                    <div style={{ display: "flex", gap: 5 }}>
                      <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#FF5F56", display: "inline-block" }} />
                      <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#FFBD2E", display: "inline-block" }} />
                      <span style={{ width: 10, height: 10, borderRadius: "50%", background: "#27C93F", display: "inline-block" }} />
                    </div>
                    <span style={{ color: "#5F6E63", fontWeight: 600, marginLeft: 8 }}>
                      มุมมองตัวอย่างอีเมล (Email Message Preview)
                    </span>
                  </div>
                  <span style={{ color: "#7B8B7F", fontSize: 11.5 }}>
                    เวลาประมวลผล: {new Date().toLocaleTimeString("th-TH")}
                  </span>
                </div>

                {/* Email Metadata Details */}
                <div
                  style={{
                    background: "#FFFFFF",
                    padding: "14px 20px",
                    borderBottom: "1px solid #E5ECE7",
                    fontSize: 13,
                    color: "#3B4A3F",
                  }}
                >
                  <div style={{ display: "flex", marginBottom: 6 }}>
                    <span style={{ width: 90, color: "#8A978E", fontWeight: 600 }}>จาก (From):</span>
                    <span style={{ fontWeight: 600, color: "#1F2D24" }}>
                      ระบบคลังยาสมุนไพรอัตโนมัติ &lt;notifications@herbal-inventory.system&gt;
                    </span>
                  </div>
                  <div style={{ display: "flex", marginBottom: 6 }}>
                    <span style={{ width: 90, color: "#8A978E", fontWeight: 600 }}>ถึง (To):</span>
                    <span
                      style={{
                        background: "#EDF5F0",
                        color: "#2D4834",
                        padding: "1px 8px",
                        borderRadius: 4,
                        fontWeight: 700,
                      }}
                    >
                      {settings.recipientEmail}
                    </span>
                  </div>
                  <div style={{ display: "flex" }}>
                    <span style={{ width: 90, color: "#8A978E", fontWeight: 600 }}>หัวข้อ (Subject):</span>
                    <span style={{ fontWeight: 700, color: "#1F2D24" }}>{generatedSubject}</span>
                  </div>
                </div>

                {/* RENDERED EMAIL BODY TEMPLATE */}
                <div style={{ padding: "24px 28px", background: "#FFFFFF", color: "#1F2D24" }}>
                  {/* Email Banner Header */}
                  <div
                    style={{
                      borderBottom: "2px solid #2D4834",
                      paddingBottom: 16,
                      marginBottom: 20,
                      display: "flex",
                      justifyContent: "space-between",
                      alignItems: "flex-start",
                    }}
                  >
                    <div>
                      <div
                        style={{
                          fontSize: 12,
                          color: "#5B7A63",
                          fontWeight: 700,
                          textTransform: "uppercase",
                          letterSpacing: 0.8,
                        }}
                      >
                        ระบบแจ้งเตือนอัตโนมัติ · แผนกคลังยาสมุนไพร
                      </div>
                      <h2
                        style={{
                          fontFamily: "'Noto Serif Thai', serif",
                          fontSize: 22,
                          fontWeight: 700,
                          color: "#1F2D24",
                          margin: "4px 0 0",
                        }}
                      >
                        รายงานแจ้งเตือนสต็อกยาสมุนไพร
                      </h2>
                    </div>
                    <div style={{ textAlign: "right", fontSize: 12, color: "#77857A" }}>
                      <div>วันที่ออกรายงาน:</div>
                      <strong style={{ color: "#1F2D24" }}>
                        {new Date().toLocaleDateString("th-TH", { dateStyle: "long" })}
                      </strong>
                    </div>
                  </div>

                  {/* Summary Callout Banner */}
                  <div
                    style={{
                      background:
                        emailLowStockItems.length > 0 ? "linear-gradient(135deg, #FFF8F7 0%, #FFF3F2 100%)" : "#F4F8F5",
                      border: emailLowStockItems.length > 0 ? "1px solid #F5C6C2" : "1px solid #D2E2D6",
                      borderRadius: 8,
                      padding: "14px 18px",
                      marginBottom: 20,
                    }}
                  >
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      {emailLowStockItems.length > 0 ? (
                        <AlertTriangle size={20} color="#A83B32" />
                      ) : (
                        <CheckCircle2 size={20} color="#2E693D" />
                      )}
                      <div>
                        <div
                          style={{
                            fontWeight: 700,
                            fontSize: 14.5,
                            color: emailLowStockItems.length > 0 ? "#A83B32" : "#2E693D",
                          }}
                        >
                          {emailLowStockItems.length > 0
                            ? `พบรายการยาสมุนไพรต่ำกว่าเกณฑ์สต็อกความปลอดภัย ${emailLowStockItems.length} รายการ`
                            : "สถานะสต็อกอยู่ในเกณฑ์ปลอดภัย"}
                        </div>
                        <div style={{ fontSize: 12.5, color: "#5C6A60", marginTop: 2 }}>
                          เรียน ผู้ดูแลคลังยาและแผนกจัดซื้อ กรุณาตรวจสอบรายการสมุนไพรด้านล่างเพื่อดำเนินการจัดซื้อหรือเร่งเบิกจ่าย
                        </div>
                      </div>
                    </div>

                    {/* Quick Metric Tiles in Email */}
                    <div
                      style={{
                        display: "grid",
                        gridTemplateColumns: "repeat(auto-fit, minmax(180px, 1fr))",
                        gap: 12,
                        marginTop: 14,
                        paddingTop: 12,
                        borderTop: "1px dashed rgba(0,0,0,0.1)",
                      }}
                    >
                      <div style={{ background: "#FFFFFF", padding: "8px 12px", borderRadius: 6, border: "1px solid #E8EFEA" }}>
                        <div style={{ fontSize: 11.5, color: "#77857A" }}>ต้องสั่งซื้อด่วน</div>
                        <div style={{ fontSize: 18, fontWeight: 700, color: "#A83B32" }}>
                          {emailLowStockItems.length} <span style={{ fontSize: 12, fontWeight: 500 }}>รายการ</span>
                        </div>
                      </div>

                      <div style={{ background: "#FFFFFF", padding: "8px 12px", borderRadius: 6, border: "1px solid #E8EFEA" }}>
                        <div style={{ fontSize: 11.5, color: "#77857A" }}>ประมาณการงบสั่งซื้อ</div>
                        <div style={{ fontSize: 18, fontWeight: 700, color: "#2D4834" }}>
                          ฿{totalEstimatedCost.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                        </div>
                      </div>

                      <div style={{ background: "#FFFFFF", padding: "8px 12px", borderRadius: 6, border: "1px solid #E8EFEA" }}>
                        <div style={{ fontSize: 11.5, color: "#77857A" }}>ล็อตใกล้หมดอายุ (≤90 วัน)</div>
                        <div style={{ fontSize: 18, fontWeight: 700, color: "#C08A2E" }}>
                          {emailNearExpiryLots.length} <span style={{ fontSize: 12, fontWeight: 500 }}>ล็อต</span>
                        </div>
                      </div>
                    </div>
                  </div>

                  {/* TABLE 1: LOW STOCK REORDER LIST */}
                  {alertType !== "near_expiry" && (
                    <div style={{ marginBottom: 24 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
                        <AlertTriangle size={15} color="#A83B32" />
                        <h4 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: "#A83B32" }}>
                          รายการยาที่สต็อกต่ำกว่าเกณฑ์ (Low Stock Reorder List)
                        </h4>
                      </div>

                      {emailLowStockItems.length === 0 ? (
                        <div
                          style={{
                            padding: "12px",
                            background: "#F9FAF8",
                            border: "1px dashed #D6E0D8",
                            borderRadius: 6,
                            fontSize: 13,
                            color: "#5C6A60",
                            textAlign: "center",
                          }}
                        >
                          ไม่มีรายการยาที่สต็อกต่ำกว่าเกณฑ์ในขณะนี้
                        </div>
                      ) : (
                        <div style={{ overflowX: "auto", border: "1px solid #E1E8E2", borderRadius: 6 }}>
                          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5, textAlign: "left" }}>
                            <thead>
                              <tr style={{ background: "#F6F8F6", borderBottom: "1.5px solid #D5DFD7", color: "#4A564D" }}>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>ลำดับ</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>ชื่อยาสมุนไพร</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>หมวดหมู่</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>สต็อกคงเหลือ</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>เกณฑ์ขั้นต่ำ</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>แนะนำสั่งซื้อ</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>ผู้จัดจำหน่าย</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700, textAlign: "right" }}>ประมาณการ (฿)</th>
                              </tr>
                            </thead>
                            <tbody>
                              {emailLowStockItems.map((item, idx) => (
                                <tr
                                  key={item.id}
                                  style={{
                                    borderBottom: "1px solid #EBF0EB",
                                    background: idx % 2 === 0 ? "#FFFFFF" : "#FCFDFC",
                                  }}
                                >
                                  <td style={{ padding: "8px 10px", color: "#77857A" }}>{idx + 1}</td>
                                  <td style={{ padding: "8px 10px", fontWeight: 700, color: "#1F2D24" }}>{item.name}</td>
                                  <td style={{ padding: "8px 10px", color: "#5C6A60" }}>{item.category}</td>
                                  <td style={{ padding: "8px 10px", color: "#A83B32", fontWeight: 700 }}>
                                    {item.current} {item.unit}
                                  </td>
                                  <td style={{ padding: "8px 10px", color: "#77857A" }}>
                                    {item.minStock} {item.unit}
                                  </td>
                                  <td style={{ padding: "8px 10px", color: "#2D4834", fontWeight: 700 }}>
                                    +{item.reorderQty} {item.unit}
                                  </td>
                                  <td style={{ padding: "8px 10px", color: "#5C6A60" }}>{item.supplier || "-"}</td>
                                  <td style={{ padding: "8px 10px", textAlign: "right", fontWeight: 700, color: "#2D4834" }}>
                                    ฿{item.estimatedCost.toLocaleString()}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}

                  {/* TABLE 2: NEAR EXPIRY LIST */}
                  {alertType !== "low_stock" && (
                    <div style={{ marginBottom: 20 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 8 }}>
                        <Clock size={15} color="#C08A2E" />
                        <h4 style={{ margin: 0, fontSize: 15, fontWeight: 700, color: "#996B1E" }}>
                          รายการล็อตยาที่ใกล้หมดอายุ (Expiring Soon - ≤90 วัน)
                        </h4>
                      </div>

                      {emailNearExpiryLots.length === 0 ? (
                        <div
                          style={{
                            padding: "12px",
                            background: "#F9FAF8",
                            border: "1px dashed #D6E0D8",
                            borderRadius: 6,
                            fontSize: 13,
                            color: "#5C6A60",
                            textAlign: "center",
                          }}
                        >
                          ไม่มียาสมุนไพรที่ใกล้หมดอายุใน 90 วัน
                        </div>
                      ) : (
                        <div style={{ overflowX: "auto", border: "1px solid #E1E8E2", borderRadius: 6 }}>
                          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 12.5, textAlign: "left" }}>
                            <thead>
                              <tr style={{ background: "#FBF9F3", borderBottom: "1.5px solid #EEDFBE", color: "#5C4C2E" }}>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>ลำดับ</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>ชื่อยาสมุนไพร</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>เลขที่ล็อต (Lot No.)</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>จำนวนคงเหลือ</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>วันหมดอายุ (EXP)</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>ระยะเวลาที่เหลือ</th>
                                <th style={{ padding: "8px 10px", fontWeight: 700 }}>คำแนะนำการจัดการ</th>
                              </tr>
                            </thead>
                            <tbody>
                              {emailNearExpiryLots.map((lot, idx) => (
                                <tr
                                  key={lot.lotId}
                                  style={{
                                    borderBottom: "1px solid #F3EDE0",
                                    background: idx % 2 === 0 ? "#FFFFFF" : "#FCFBF8",
                                  }}
                                >
                                  <td style={{ padding: "8px 10px", color: "#77857A" }}>{idx + 1}</td>
                                  <td style={{ padding: "8px 10px", fontWeight: 700, color: "#1F2D24" }}>{lot.itemName}</td>
                                  <td style={{ padding: "8px 10px", color: "#5C6A60" }}>{lot.lotNo}</td>
                                  <td style={{ padding: "8px 10px", fontWeight: 700 }}>
                                    {lot.qty} {lot.unit}
                                  </td>
                                  <td style={{ padding: "8px 10px", color: lot.daysLeft < 0 ? "#A83B32" : "#996B1E", fontWeight: 600 }}>
                                    {fmtDate(lot.expiryDate)}
                                  </td>
                                  <td style={{ padding: "8px 10px" }}>
                                    <span
                                      style={{
                                        background: lot.daysLeft < 0 ? "#FBEDEB" : "#FEF6E5",
                                        color: lot.daysLeft < 0 ? "#A83B32" : "#996B1E",
                                        padding: "2px 6px",
                                        borderRadius: 4,
                                        fontSize: 11.5,
                                        fontWeight: 700,
                                      }}
                                    >
                                      {lot.daysLeft < 0 ? "หมดอายุแล้ว" : `เหลือ ${lot.daysLeft} วัน`}
                                    </span>
                                  </td>
                                  <td style={{ padding: "8px 10px", fontSize: 12, color: "#6C7A70" }}>
                                    {lot.daysLeft < 0 ? "ปลดระวาง/ตัดสต็อก" : "เบิกจ่ายตามลำดับ FEFO"}
                                  </td>
                                </tr>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      )}
                    </div>
                  )}

                  {/* Direct Action Links within Email */}
                  <div
                    style={{
                      background: "#F6F9F7",
                      border: "1px solid #DCE6DF",
                      borderRadius: 8,
                      padding: "16px",
                      textAlign: "center",
                      marginTop: 20,
                    }}
                  >
                    <div style={{ fontSize: 13, color: "#4A564D", marginBottom: 10 }}>
                      คลิกเพื่อเปิดระบบและดำเนินการในคลังยาสมุนไพรทันที:
                    </div>
                    <div style={{ display: "flex", justifyContent: "center", gap: 10, flexWrap: "wrap" }}>
                      <button
                        onClick={() => {
                          onClose();
                          if (onNavigateToMove) onNavigateToMove();
                        }}
                        style={{
                          background: "#2D4834",
                          color: "#FFFFFF",
                          border: "none",
                          padding: "8px 16px",
                          borderRadius: 6,
                          fontSize: 13,
                          fontWeight: 700,
                          cursor: "pointer",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: 6,
                        }}
                      >
                        <span>เปิดหน้าบันทึกรับเข้า-เบิกออก</span>
                        <ArrowRight size={14} />
                      </button>

                      <button
                        onClick={handleCopyEmailText}
                        style={{
                          background: "#FFFFFF",
                          color: "#2D4834",
                          border: "1px solid #2D4834",
                          padding: "8px 16px",
                          borderRadius: 6,
                          fontSize: 13,
                          fontWeight: 600,
                          cursor: "pointer",
                        }}
                      >
                        คัดลอกรายการสั่งซื้อ
                      </button>
                    </div>
                  </div>

                  {/* Email Footer */}
                  <div
                    style={{
                      marginTop: 26,
                      paddingTop: 14,
                      borderTop: "1px solid #EBEFEA",
                      fontSize: 11.5,
                      color: "#8A978E",
                      textAlign: "center",
                      lineHeight: 1.6,
                    }}
                  >
                    <div>
                      อีเมลฉบับนี้ส่งโดยระบบแจ้งเตือนอัตโนมัติ (Mock Notification) ของระบบจัดการคลังยาสมุนไพร
                    </div>
                    <div>
                      หากต้องการปรับเปลี่ยนความถี่หรือที่อยู่อีเมลผู้รับ กรุณาเข้าสู่เมนู "ตั้งค่าการแจ้งเตือน" ในหน้าแดชบอร์ด
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: SETTINGS */}
          {activeTab === "settings" && (
            <div style={{ maxWidth: 680, margin: "0 auto" }}>
              <div
                style={{
                  background: "#FFFFFF",
                  border: "1px solid #DCE5DE",
                  borderRadius: 10,
                  padding: "20px 22px",
                  boxShadow: "0 2px 8px rgba(0,0,0,0.03)",
                }}
              >
                <h4 style={{ margin: "0 0 16px", fontSize: 16, fontWeight: 700, color: "#1F2D24" }}>
                  ตั้งค่าผู้รับ & เงื่อนไขการแจ้งเตือนอีเมลจำลอง (Mock Notification Settings)
                </h4>

                {/* Main Enable Switch */}
                <div
                  style={{
                    display: "flex",
                    justifyContent: "space-between",
                    alignItems: "center",
                    padding: "12px 14px",
                    background: settings.enabled ? "#EEF6F0" : "#F8F8F5",
                    border: settings.enabled ? "1px solid #B8DCBF" : "1px solid #E2E0D5",
                    borderRadius: 8,
                    marginBottom: 18,
                  }}
                >
                  <div>
                    <div style={{ fontWeight: 700, fontSize: 14, color: settings.enabled ? "#245A34" : "#5B5747" }}>
                      เปิดใช้งานระบบจำลองการแจ้งเตือนอีเมล (Mock Alerts)
                    </div>
                    <div style={{ fontSize: 12, color: "#6E7A70" }}>
                      ให้ระบบจำลองส่งอีเมลแจ้งเตือนเมื่อสต็อกสมุนไพรลดลงต่ำกว่าเกณฑ์ หรือมีล็อตใกล้หมดอายุ
                    </div>
                  </div>
                  <label style={{ display: "inline-flex", alignItems: "center", cursor: "pointer" }}>
                    <input
                      id="toggle-email-alerts-enabled"
                      type="checkbox"
                      checked={settings.enabled}
                      onChange={(e) => setSettings({ ...settings, enabled: e.target.checked })}
                      style={{ width: 20, height: 20, accentColor: "#2D4834", cursor: "pointer" }}
                    />
                  </label>
                </div>

                {/* Recipient Email */}
                <div style={{ marginBottom: 16 }}>
                  <label
                    style={{
                      display: "block",
                      fontSize: 13,
                      fontWeight: 700,
                      color: "#3B4A3F",
                      marginBottom: 6,
                    }}
                  >
                    อีเมลผู้รับการแจ้งเตือน (Recipient Email):
                  </label>
                  <input
                    id="input-recipient-email"
                    type="email"
                    value={settings.recipientEmail}
                    onChange={(e) => setSettings({ ...settings, recipientEmail: e.target.value })}
                    placeholder="เช่น titee2409@gmail.com หรือ pharmacist@hospital.go.th"
                    style={{
                      width: "100%",
                      padding: "10px 12px",
                      fontSize: 14,
                      border: "1.5px solid #C4D5C7",
                      borderRadius: 8,
                      outline: "none",
                      boxSizing: "border-box",
                      fontFamily: "Sarabun",
                    }}
                  />
                  <div style={{ fontSize: 12, color: "#77857A", marginTop: 4 }}>
                    ระบบจะจำลองการส่งรายงานการจัดซื้อและแจ้งเตือนวันหมดอายุไปยังที่อยู่นี้
                  </div>
                </div>

                {/* Trigger Rules Checkboxes */}
                <div style={{ marginBottom: 18 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "#3B4A3F", marginBottom: 8 }}>
                    เงื่อนไขในการส่งการแจ้งเตือน (Alert Triggers):
                  </div>

                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    <label
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        padding: "10px 12px",
                        background: "#FAFBF9",
                        border: "1px solid #E6ECE7",
                        borderRadius: 6,
                        cursor: "pointer",
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={settings.notifyLowStock}
                        onChange={(e) => setSettings({ ...settings, notifyLowStock: e.target.checked })}
                        style={{ accentColor: "#2D4834", width: 17, height: 17 }}
                      />
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 13, color: "#1F2D24" }}>
                          แจ้งเตือนเมื่อมียาสมุนไพรสต็อกต่ำกว่าเกณฑ์ขั้นต่ำ (Low Stock Alert)
                        </div>
                        <div style={{ fontSize: 11.5, color: "#77857A" }}>
                          ส่งอีเมลสรุปรายการยาที่ต้องสั่งซื้อเพิ่มทันทีที่สต็อกลดลง
                        </div>
                      </div>
                    </label>

                    <label
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        padding: "10px 12px",
                        background: "#FAFBF9",
                        border: "1px solid #E6ECE7",
                        borderRadius: 6,
                        cursor: "pointer",
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={settings.notifyNearExpiry}
                        onChange={(e) => setSettings({ ...settings, notifyNearExpiry: e.target.checked })}
                        style={{ accentColor: "#2D4834", width: 17, height: 17 }}
                      />
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 13, color: "#1F2D24" }}>
                          แจ้งเตือนเมื่อมียาสมุนไพรใกล้หมดอายุ (Near Expiry Alert)
                        </div>
                        <div style={{ fontSize: 11.5, color: "#77857A" }}>
                          แจ้งเตือนล็อตยาที่หมดอายุภายในจำนวนวันที่กำหนด เพื่อเร่งระบายยาตามหลัก FEFO
                        </div>
                      </div>
                    </label>

                    <label
                      style={{
                        display: "flex",
                        alignItems: "center",
                        gap: 10,
                        padding: "10px 12px",
                        background: "#FAFBF9",
                        border: "1px solid #E6ECE7",
                        borderRadius: 6,
                        cursor: "pointer",
                      }}
                    >
                      <input
                        type="checkbox"
                        checked={settings.autoSimulateOnStockChange}
                        onChange={(e) => setSettings({ ...settings, autoSimulateOnStockChange: e.target.checked })}
                        style={{ accentColor: "#2D4834", width: 17, height: 17 }}
                      />
                      <div>
                        <div style={{ fontWeight: 600, fontSize: 13, color: "#1F2D24" }}>
                          จำลองบันทึกส่งอัตโนมัติเมื่อทำรายการเบิกจ่ายจนสต็อกต่ำ (Auto Simulation)
                        </div>
                        <div style={{ fontSize: 11.5, color: "#77857A" }}>
                          เมื่อเจ้าหน้าที่เบิกจ่ายยาออกแล้วสต็อกต่ำกว่าเกณฑ์ ระบบจะบันทึกประวัติส่งอีเมลจำลองให้ทันที
                        </div>
                      </div>
                    </label>
                  </div>
                </div>

                {/* Expiry Threshold & Frequency */}
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 14, marginBottom: 20 }}>
                  <div>
                    <label style={{ display: "block", fontSize: 12.5, fontWeight: 700, color: "#3B4A3F", marginBottom: 6 }}>
                      เกณฑ์วันใกล้หมดอายุ (วัน):
                    </label>
                    <select
                      value={settings.nearExpiryDaysThreshold}
                      onChange={(e) => setSettings({ ...settings, nearExpiryDaysThreshold: Number(e.target.value) })}
                      style={{
                        width: "100%",
                        padding: "9px 10px",
                        borderRadius: 6,
                        border: "1px solid #C4D5C7",
                        fontSize: 13,
                        fontFamily: "Sarabun",
                        outline: "none",
                      }}
                    >
                      <option value={30}>เตือนล่วงหน้า 30 วัน (1 เดือน)</option>
                      <option value={60}>เตือนล่วงหน้า 60 วัน (2 เดือน)</option>
                      <option value={90}>เตือนล่วงหน้า 90 วัน (3 เดือน - แนะนำ)</option>
                      <option value={180}>เตือนล่วงหน้า 180 วัน (6 เดือน)</option>
                    </select>
                  </div>

                  <div>
                    <label style={{ display: "block", fontSize: 12.5, fontWeight: 700, color: "#3B4A3F", marginBottom: 6 }}>
                      ความถี่ในการส่งจำลอง:
                    </label>
                    <select
                      value={settings.frequency}
                      onChange={(e) => setSettings({ ...settings, frequency: e.target.value as any })}
                      style={{
                        width: "100%",
                        padding: "9px 10px",
                        borderRadius: 6,
                        border: "1px solid #C4D5C7",
                        fontSize: 13,
                        fontFamily: "Sarabun",
                        outline: "none",
                      }}
                    >
                      <option value="instant">ส่งทันทีเมื่อมีการตรวจพบ (Instant Realtime)</option>
                      <option value="daily">สรุปทุกวัน เวลา 08:00 น. (Daily Digest)</option>
                      <option value="weekly">สรุปทุกสัปดาห์ (Weekly Summary)</option>
                    </select>
                  </div>
                </div>

                {/* Save Settings Button */}
                <div style={{ display: "flex", justifyContent: "flex-end", gap: 10 }}>
                  <button
                    id="btn-save-email-settings"
                    onClick={handleSaveSettings}
                    style={{
                      padding: "10px 22px",
                      borderRadius: 6,
                      border: "none",
                      background: "#2D4834",
                      color: "#FFFFFF",
                      fontSize: 13.5,
                      fontWeight: 700,
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: 6,
                    }}
                  >
                    <Check size={16} />
                    <span>บันทึกการตั้งค่า</span>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: SENT LOGS HISTORY */}
          {activeTab === "history" && (
            <div>
              <div
                style={{
                  display: "flex",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginBottom: 14,
                }}
              >
                <div>
                  <h4 style={{ margin: 0, fontSize: 16, fontWeight: 700, color: "#1F2D24" }}>
                    ประวัติการส่งอีเมลจำลอง (Mock Sent Notifications Log)
                  </h4>
                  <div style={{ fontSize: 12.5, color: "#77857A", marginTop: 2 }}>
                    บันทึกรายการแจ้งเตือนที่ระบบได้จำลองส่งออกไปแล้วทั้งหมด ({emailLogs.length} รายการ)
                  </div>
                </div>

                {emailLogs.length > 0 && (
                  <button
                    onClick={handleClearLogs}
                    style={{
                      background: "none",
                      border: "1px solid #E3D8D7",
                      color: "#A83B32",
                      borderRadius: 6,
                      padding: "6px 12px",
                      fontSize: 12,
                      fontWeight: 600,
                      cursor: "pointer",
                      display: "flex",
                      alignItems: "center",
                      gap: 4,
                    }}
                  >
                    <Trash2 size={13} /> ล้างประวัติทั้งหมด
                  </button>
                )}
              </div>

              {emailLogs.length === 0 ? (
                <div
                  style={{
                    padding: "40px 20px",
                    textAlign: "center",
                    background: "#FFFFFF",
                    border: "1px dashed #D5DFD7",
                    borderRadius: 10,
                  }}
                >
                  <Inbox size={36} color="#8A978E" style={{ marginBottom: 8 }} />
                  <div style={{ fontWeight: 700, fontSize: 15, color: "#1F2D24" }}>
                    ยังไม่มีประวัติการส่งอีเมลจำลอง
                  </div>
                  <div style={{ fontSize: 13, color: "#77857A", marginTop: 4 }}>
                    คุณสามารถกดปุ่ม "จำลองส่งอีเมลแจ้งเตือนทันที" ในแท็บพรีวิวเพื่อทดสอบการทำงานได้
                  </div>
                  <button
                    onClick={() => setActiveTab("preview")}
                    style={{
                      marginTop: 14,
                      padding: "8px 18px",
                      background: "#2D4834",
                      color: "#FFFFFF",
                      border: "none",
                      borderRadius: 6,
                      fontSize: 13,
                      fontWeight: 600,
                      cursor: "pointer",
                    }}
                  >
                    ไปที่แท็บจำลองส่งอีเมล
                  </button>
                </div>
              ) : (
                <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {emailLogs.map((log) => {
                    const isViewing = selectedLogToView?.id === log.id;
                    const dateFormatted = new Date(log.sentAt).toLocaleString("th-TH", {
                      dateStyle: "medium",
                      timeStyle: "short",
                    });

                    return (
                      <div
                        key={log.id}
                        style={{
                          background: "#FFFFFF",
                          border: isViewing ? "1.5px solid #2D4834" : "1px solid #E1E8E2",
                          borderRadius: 8,
                          padding: "14px 16px",
                          boxShadow: "0 1px 3px rgba(0,0,0,0.02)",
                          transition: "all 0.15s ease",
                        }}
                      >
                        <div
                          style={{
                            display: "flex",
                            justifyContent: "space-between",
                            alignItems: "flex-start",
                            flexWrap: "wrap",
                            gap: 10,
                          }}
                        >
                          <div style={{ flex: 1, minWidth: 260 }}>
                            <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
                              <span
                                style={{
                                  background: "#E8F5ED",
                                  color: "#245A34",
                                  fontSize: 11,
                                  fontWeight: 700,
                                  padding: "2px 7px",
                                  borderRadius: 4,
                                  display: "inline-flex",
                                  alignItems: "center",
                                  gap: 3,
                                }}
                              >
                                <CheckCircle2 size={11} /> ส่งสำเร็จ (Mock Delivered)
                              </span>
                              <span style={{ fontSize: 12, color: "#8A978E" }}>{dateFormatted}</span>
                              <span
                                style={{
                                  background: "#F5F5F0",
                                  color: "#5B5747",
                                  fontSize: 11,
                                  padding: "2px 6px",
                                  borderRadius: 4,
                                }}
                              >
                                ถึง: {log.recipientEmail}
                              </span>
                            </div>

                            <div style={{ fontWeight: 700, fontSize: 14.5, color: "#1F2D24", marginTop: 6 }}>
                              {log.subject}
                            </div>

                            <div style={{ fontSize: 12.5, color: "#6C7A70", marginTop: 4, display: "flex", gap: 14 }}>
                              <span>ต่ำกว่าเกณฑ์: <strong>{log.lowStockItemsCount}</strong> รายการ</span>
                              <span>ใกล้หมดอายุ: <strong>{log.nearExpiryLotsCount}</strong> ล็อต</span>
                              {log.estimatedReorderCost !== undefined && (
                                <span>
                                  งบประมาณสั่งซื้อ: <strong>฿{log.estimatedReorderCost.toLocaleString()}</strong>
                                </span>
                              )}
                            </div>
                          </div>

                          <div style={{ display: "flex", gap: 6 }}>
                            <button
                              onClick={() => setSelectedLogToView(isViewing ? null : log)}
                              style={{
                                padding: "6px 12px",
                                borderRadius: 6,
                                border: "1px solid #D5DFD7",
                                background: isViewing ? "#2D4834" : "#FFFFFF",
                                color: isViewing ? "#FFFFFF" : "#2D4834",
                                fontSize: 12,
                                fontWeight: 600,
                                cursor: "pointer",
                                display: "flex",
                                alignItems: "center",
                                gap: 4,
                              }}
                            >
                              <Eye size={13} />
                              <span>{isViewing ? "ปิดเนื้อหา" : "ดูเนื้อหาอีเมล"}</span>
                            </button>
                          </div>
                        </div>

                        {/* Expanded Detail View of the Selected Log */}
                        {isViewing && (
                          <div
                            style={{
                              marginTop: 12,
                              padding: "12px 14px",
                              background: "#FAFBF9",
                              border: "1px dashed #D2DDD5",
                              borderRadius: 6,
                              fontSize: 12.5,
                            }}
                          >
                            <div style={{ fontWeight: 700, color: "#2D4834", marginBottom: 6 }}>
                              รายละเอียดข้อมูลในอีเมลฉบับนี้:
                            </div>

                            {log.lowStockDetails && log.lowStockDetails.length > 0 && (
                              <div style={{ marginBottom: 8 }}>
                                <strong style={{ color: "#A83B32" }}>• รายการยาต่ำกว่าเกณฑ์:</strong>
                                <ul style={{ margin: "4px 0 0 16px", padding: 0 }}>
                                  {log.lowStockDetails.map((it) => (
                                    <li key={it.id}>
                                      {it.name} - คงเหลือ {it.current} / ขั้นต่ำ {it.minStock} {it.unit} (สั่งซื้อเพิ่ม {it.reorderQty} {it.unit}, ผู้จัดจำหน่าย: {it.supplier || "-"})
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}

                            {log.nearExpiryDetails && log.nearExpiryDetails.length > 0 && (
                              <div>
                                <strong style={{ color: "#996B1E" }}>• รายการล็อตใกล้หมดอายุ:</strong>
                                <ul style={{ margin: "4px 0 0 16px", padding: 0 }}>
                                  {log.nearExpiryDetails.map((l) => (
                                    <li key={l.lotId}>
                                      {l.itemName} ล็อต {l.lotNo} - คงเหลือ {l.qty} {l.unit}, หมดอายุ {fmtDate(l.expiryDate)} ({l.daysLeft < 0 ? "หมดอายุแล้ว" : `เหลือ ${l.daysLeft} วัน`})
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          )}
        </div>

        {/* Modal Footer */}
        <div
          style={{
            padding: "12px 22px",
            background: "#F5F8F6",
            borderTop: "1px solid #DFE7E1",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <div style={{ fontSize: 12, color: "#77857A", display: "flex", alignItems: "center", gap: 6 }}>
            <ShieldCheck size={14} color="#3C5A45" />
            <span>ระบบจำลองการส่งการแจ้งเตือน (Mock Email Engine) โดยไม่จำเป็นต้องต่อ SMTP Server จริง</span>
          </div>

          <button
            onClick={onClose}
            style={{
              padding: "7px 18px",
              borderRadius: 6,
              border: "1px solid #C4D5C7",
              background: "#FFFFFF",
              color: "#3B4A3F",
              fontSize: 13,
              fontWeight: 600,
              cursor: "pointer",
            }}
          >
            ปิดหน้าต่าง
          </button>
        </div>
      </div>
    </div>
  );
}
