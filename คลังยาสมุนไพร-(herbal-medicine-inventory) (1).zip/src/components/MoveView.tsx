import React, { useState, useEffect } from "react";
import { Plus, ArrowLeftRight, Check } from "lucide-react";
import type { InventoryState, StockTransaction, HerbalLot, MockEmailNotification } from "../types";
import { Panel, Btn, Field, inputStyle } from "./Panel";
import { uid, today, fmtDate, lotQtyForItem, loadEmailSettings, loadEmailLogs, saveEmailLogs } from "../utils/storage";

export function MoveView({
  inv,
  persistInv,
  tx,
  persistTx,
  staffName,
  showToast,
  preselectedItemId,
  preselectedMode,
  onNavigateToItems,
}: {
  inv: InventoryState;
  persistInv: (next: InventoryState) => Promise<void>;
  tx: StockTransaction[];
  persistTx: (next: StockTransaction[]) => Promise<void>;
  staffName: string;
  showToast: (msg: string) => void;
  preselectedItemId?: string;
  preselectedMode?: "in" | "out";
  onNavigateToItems?: () => void;
}) {
  const [mode, setMode] = useState<"in" | "out">(preselectedMode || "in");
  const [itemId, setItemId] = useState(preselectedItemId || "");
  const [lotId, setLotId] = useState("");
  const [lotNo, setLotNo] = useState("");
  const [qty, setQty] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [receivedDate, setReceivedDate] = useState(today());
  const [note, setNote] = useState("");

  const item = inv.items.find((i) => i.id === itemId);
  const availableLots = inv.lots
    .filter((l) => l.itemId === itemId && l.qty > 0)
    .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());

  useEffect(() => {
    if (preselectedItemId) {
      setItemId(preselectedItemId);
      if (preselectedMode) {
        setMode(preselectedMode);
      }
    }
  }, [preselectedItemId, preselectedMode]);

  useEffect(() => {
    setLotId("");
    setLotNo("");
    setExpiryDate("");
    setQty("");
  }, [itemId, mode]);

  async function submitIn() {
    if (!itemId) {
      showToast("กรุณาเลือกรายการยา");
      return;
    }
    const numQty = Number(qty);
    if (!numQty || numQty <= 0) {
      showToast("กรุณากรอกจำนวนที่ถูกต้อง (มากกว่า 0)");
      return;
    }
    if (!expiryDate) {
      showToast("กรุณาระบุวันหมดอายุของล็อต");
      return;
    }
    const newLot: HerbalLot = {
      id: uid(),
      itemId,
      lotNo: lotNo.trim() || `L-${today().replace(/-/g, "")}`,
      qty: numQty,
      expiryDate,
      receivedDate: receivedDate || today(),
    };
    const newInv: InventoryState = { ...inv, lots: [...inv.lots, newLot] };
    const record: StockTransaction = {
      id: uid(),
      itemId,
      lotId: newLot.id,
      type: "in",
      qty: numQty,
      date: receivedDate || today(),
      timestamp: new Date().toISOString(),
      user: staffName || "เจ้าหน้าที่",
      note: note.trim(),
    };
    await persistInv(newInv);
    await persistTx([...tx, record]);
    showToast(`บันทึกรับเข้า ${item?.name || "ยา"} จำนวน ${numQty} ${item?.unit} สำเร็จ`);
    setItemId("");
    setQty("");
    setLotNo("");
    setExpiryDate("");
    setNote("");
  }

  async function submitOut() {
    if (!itemId) {
      showToast("กรุณาเลือกรายการยา");
      return;
    }
    if (!lotId) {
      showToast("กรุณาเลือกล็อตยาที่ต้องการเบิก");
      return;
    }
    const numQty = Number(qty);
    if (!numQty || numQty <= 0) {
      showToast("กรุณากรอกจำนวนที่ต้องการเบิก");
      return;
    }
    const lot = inv.lots.find((l) => l.id === lotId);
    if (!lot) {
      showToast("ไม่พบล็อตยาที่เลือก");
      return;
    }
    if (numQty > lot.qty) {
      showToast(`จำนวนเบิก (${numQty}) มากกว่ายอดคงเหลือในล็อตนี้ (${lot.qty})`);
      return;
    }
    const newLots = inv.lots.map((l) => (l.id === lotId ? { ...l, qty: l.qty - numQty } : l));
    const record: StockTransaction = {
      id: uid(),
      itemId,
      lotId,
      type: "out",
      qty: numQty,
      date: today(),
      timestamp: new Date().toISOString(),
      user: staffName || "เจ้าหน้าที่",
      note: note.trim(),
    };
    await persistInv({ ...inv, lots: newLots });
    await persistTx([...tx, record]);

    // Check if new stock falls below minStock and trigger auto mock email simulation
    const remainingAfter = newLots
      .filter((l) => l.itemId === itemId && l.qty > 0)
      .reduce((sum, l) => sum + l.qty, 0);

    let emailSentNote = "";
    if (item && remainingAfter < item.minStock) {
      try {
        const settings = await loadEmailSettings();
        if (settings.enabled && settings.notifyLowStock && settings.autoSimulateOnStockChange) {
          const logs = await loadEmailLogs();
          const deficit = Math.max(0, item.minStock - remainingAfter);
          const reorderQty = item.reorderQty && item.reorderQty > 0 ? item.reorderQty : deficit;
          const estimatedCost = reorderQty * (Number(item.price) || 0);

          const autoNotification: MockEmailNotification = {
            id: uid(),
            sentAt: new Date().toISOString(),
            recipientEmail: settings.recipientEmail,
            subject: `[แจ้งเตือนอัตโนมัติ] ${item.name} สต็อกลดเหลือ ${remainingAfter} ${item.unit} (ต่ำกว่าเกณฑ์ ${item.minStock})`,
            type: "low_stock",
            itemCount: 1,
            lowStockItemsCount: 1,
            nearExpiryLotsCount: 0,
            estimatedReorderCost: estimatedCost,
            status: "delivered",
            lowStockDetails: [
              {
                id: item.id,
                name: item.name,
                category: item.category,
                unit: item.unit,
                current: remainingAfter,
                minStock: item.minStock,
                reorderQty,
                supplier: item.supplier,
                estimatedCost,
              },
            ],
          };
          await saveEmailLogs([autoNotification, ...logs]);
          emailSentNote = ` · 📧 จำลองส่งอีเมลแจ้งเตือนไปยัง ${settings.recipientEmail} แล้ว`;
        }
      } catch (err) {
        console.error("Auto email notification simulation failed", err);
      }
    }

    showToast(`บันทึกเบิกออก ${item?.name || "ยา"} จำนวน ${numQty} ${item?.unit} สำเร็จ${emailSentNote}`);
    setItemId("");
    setQty("");
    setLotId("");
    setNote("");
  }

  return (
    <div>
      <h1 style={{ fontFamily: "'Noto Serif Thai', serif", fontSize: 24, margin: "2px 0 16px", fontWeight: 700 }}>
        บันทึกรับเข้า / เบิกออกสต็อก
      </h1>

      <div style={{ display: "flex", gap: 10, marginBottom: 18 }}>
        <button
          id="btn-mode-in"
          onClick={() => setMode("in")}
          style={{
            flex: 1,
            padding: "12px",
            borderRadius: 8,
            border: mode === "in" ? "2px solid #3C5A45" : "1px solid #D8D3C2",
            background: mode === "in" ? "#EEF1E8" : "#fff",
            fontWeight: 700,
            color: "#3C5A45",
            cursor: "pointer",
            fontSize: 15,
            fontFamily: "Sarabun, sans-serif",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <Plus size={16} /> รับเข้าสต็อก
        </button>
        <button
          id="btn-mode-out"
          onClick={() => setMode("out")}
          style={{
            flex: 1,
            padding: "12px",
            borderRadius: 8,
            border: mode === "out" ? "2px solid #A83B32" : "1px solid #D8D3C2",
            background: mode === "out" ? "#FBEDEB" : "#fff",
            fontWeight: 700,
            color: "#A83B32",
            cursor: "pointer",
            fontSize: 15,
            fontFamily: "Sarabun, sans-serif",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <ArrowLeftRight size={16} /> เบิกออกสต็อก
        </button>
      </div>

      {inv.items.length === 0 && (
        <div
          id="move-empty-items-alert"
          style={{
            background: "#FFFBEB",
            border: "1px solid #FCD34D",
            borderRadius: 8,
            padding: "12px 16px",
            marginBottom: 16,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 10,
          }}
        >
          <div style={{ fontSize: 13.5, color: "#92400E", fontWeight: 500 }}>
            ⚠️ ยังไม่มีรายการยาในคลัง (ข้อมูลตัวอย่างถูกล้างแล้ว) กรุณาเพิ่มรายการยาก่อนบันทึกรับเข้าหรือเบิกออก
          </div>
          {onNavigateToItems && (
            <button
              onClick={onNavigateToItems}
              style={{
                background: "#B45309",
                color: "#FFFFFF",
                border: "none",
                borderRadius: 6,
                padding: "6px 14px",
                fontSize: 12.5,
                fontWeight: 600,
                cursor: "pointer",
                fontFamily: "Sarabun, sans-serif",
              }}
            >
              + ไปเพิ่มรายการยา
            </button>
          )}
        </div>
      )}

      <Panel accent={mode === "in" ? "#3C5A45" : "#A83B32"}>
        <div style={{ fontWeight: 700, fontSize: 16, marginBottom: 14, color: mode === "in" ? "#3C5A45" : "#A83B32" }}>
          {mode === "in" ? "แบบฟอร์มรับเข้ายาและบันทึกล็อตใหม่" : "แบบฟอร์มเบิกจ่ายยา (ตัดยอดตามล็อต FEFO)"}
        </div>

        <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(220px,1fr))", gap: 14 }}>
          <Field label="รายการยา">
            <select
              id="move-item-select"
              style={inputStyle}
              value={itemId}
              onChange={(e) => setItemId(e.target.value)}
            >
              <option value="">-- เลือกรายการยา --</option>
              {inv.items.map((i) => {
                const lotsOfItem = inv.lots.filter((l) => l.itemId === i.id && l.qty > 0);
                const stock = lotsOfItem.reduce((s, l) => s + l.qty, 0);
                return (
                  <option key={i.id} value={i.id}>
                    {i.name} (คงเหลือ: {stock} {i.unit})
                  </option>
                );
              })}
            </select>
          </Field>

          {mode === "in" && (
            <>
              <Field label="เลขที่ล็อต / รุ่นผลิต">
                <input
                  id="move-lot-no"
                  style={inputStyle}
                  value={lotNo}
                  onChange={(e) => setLotNo(e.target.value)}
                  placeholder="เช่น L-2026-014"
                />
              </Field>
              <Field label="วันหมดอายุ (Expiry Date)">
                <input
                  id="move-expiry-date"
                  type="date"
                  style={inputStyle}
                  value={expiryDate}
                  onChange={(e) => setExpiryDate(e.target.value)}
                />
              </Field>
              <Field label="วันที่รับเข้า">
                <input
                  id="move-received-date"
                  type="date"
                  style={inputStyle}
                  value={receivedDate}
                  onChange={(e) => setReceivedDate(e.target.value)}
                />
              </Field>
              <Field label={`จำนวนรับเข้า${item ? ` (${item.unit})` : ""}`}>
                <input
                  id="move-qty-in"
                  type="number"
                  min="1"
                  style={inputStyle}
                  value={qty}
                  onChange={(e) => setQty(e.target.value)}
                  placeholder="0"
                />
              </Field>
            </>
          )}

          {mode === "out" && (
            <>
              <Field label="เลือกล็อตยา (เรียงตามวันหมดอายุใกล้สุดก่อน)">
                <select
                  id="move-lot-select"
                  style={inputStyle}
                  value={lotId}
                  onChange={(e) => setLotId(e.target.value)}
                  disabled={!itemId}
                >
                  <option value="">
                    {!itemId ? "-- กรุณาเลือกยาก่อน --" : availableLots.length === 0 ? "-- ไม่มียอดคงเหลือในสต็อก --" : "-- เลือกล็อตที่ต้องการเบิก --"}
                  </option>
                  {availableLots.map((l) => (
                    <option key={l.id} value={l.id}>
                      ล็อต {l.lotNo || "ไม่ระบุ"} · คงเหลือ {l.qty} {item?.unit} · หมดอายุ {fmtDate(l.expiryDate)}
                    </option>
                  ))}
                </select>
              </Field>
              <Field label={`จำนวนที่ต้องการเบิก${item ? ` (${item.unit})` : ""}`}>
                <input
                  id="move-qty-out"
                  type="number"
                  min="1"
                  style={inputStyle}
                  value={qty}
                  onChange={(e) => setQty(e.target.value)}
                  placeholder="0"
                />
              </Field>
            </>
          )}

          <Field label="หมายเหตุ / หน่วยงานที่เบิกใช้">
            <input
              id="move-note"
              style={inputStyle}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="เช่น คลินิกการแพทย์แผนไทย, ใบสั่งยาเลขที่ 104"
            />
          </Field>
        </div>

        <div style={{ marginTop: 20 }}>
          <Btn
            id="btn-submit-movement"
            onClick={mode === "in" ? submitIn : submitOut}
            style={mode === "out" ? { background: "#A83B32", border: "1px solid #A83B32" } : {}}
          >
            <Check size={15} /> {mode === "in" ? "ยืนยันการรับเข้าสต็อก" : "ยืนยันการเบิกออกสต็อก"}
          </Btn>
        </div>
      </Panel>
    </div>
  );
}
