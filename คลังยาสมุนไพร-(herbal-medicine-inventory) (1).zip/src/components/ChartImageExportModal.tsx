import React, { useState, useMemo } from "react";
import {
  ResponsiveContainer,
  ComposedChart,
  BarChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  Image as ImageIcon,
  Download,
  X,
  TrendingUp,
  ArrowDownLeft,
  ArrowUpRight,
  Building,
  Calendar,
  Layers,
  Filter,
  Check,
  FileCheck,
} from "lucide-react";
import type { InventoryState, StockTransaction } from "../types";
import { lotQtyForItem, fmtDate } from "../utils/storage";
import { exportElementToPng } from "../utils/imageExport";

interface ChartImageExportModalProps {
  isOpen: boolean;
  onClose: () => void;
  inv: InventoryState;
  tx: StockTransaction[];
  showToast?: (msg: string) => void;
  initialTimeRange?: "30d" | "90d" | "6m" | "1y" | "all";
  initialItemId?: string;
}

const CATEGORY_COLORS: Record<string, string> = {
  "ยาแคปซูล": "#3C5A45",
  "ยาเม็ด": "#5B7A63",
  "ยาน้ำ/ยาดอง": "#C08A2E",
  "ยาดม/ยาหม่อง": "#8A6D3B",
  "วัตถุดิบสมุนไพรดิบ": "#6B8E23",
  "ยาผง": "#A83B32",
  "อื่นๆ": "#8A8874",
};

const DEFAULT_PALETTE = ["#3C5A45", "#5B7A63", "#C08A2E", "#A83B32", "#8A6D3B", "#4A7055", "#9CB68C"];

export function ChartImageExportModal({
  isOpen,
  onClose,
  inv,
  tx,
  showToast = () => {},
  initialTimeRange = "6m",
  initialItemId = "all",
}: ChartImageExportModalProps) {
  const [timeRange, setTimeRange] = useState<"30d" | "90d" | "6m" | "1y" | "all">(initialTimeRange);
  const [selectedItemId, setSelectedItemId] = useState<string>(initialItemId);
  const [isExporting, setIsExporting] = useState(false);
  const [exportTarget, setExportTarget] = useState<"full" | "trends" | "top" | "category">("full");
  const [exportStatus, setExportStatus] = useState("");

  if (!isOpen) return null;

  // Filter transactions
  const filteredTx = useMemo(() => {
    const now = new Date();
    let cutoff = new Date(0);

    if (timeRange === "30d") {
      cutoff = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    } else if (timeRange === "90d") {
      cutoff = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
    } else if (timeRange === "6m") {
      cutoff = new Date(now.getTime() - 180 * 24 * 60 * 60 * 1000);
    } else if (timeRange === "1y") {
      cutoff = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
    }

    return tx.filter((t) => {
      if (selectedItemId !== "all" && t.itemId !== selectedItemId) return false;
      const tDate = new Date(t.date + "T00:00:00");
      return tDate >= cutoff;
    });
  }, [tx, timeRange, selectedItemId]);

  // Item Map
  const itemMap = useMemo(() => {
    const map = new Map<string, { name: string; category: string; unit: string; price: number }>();
    inv.items.forEach((it) => {
      map.set(it.id, {
        name: it.name,
        category: it.category,
        unit: it.unit,
        price: Number(it.price) || 0,
      });
    });
    return map;
  }, [inv.items]);

  // Aggregate monthly trends
  const monthlyData = useMemo(() => {
    const map = new Map<
      string,
      {
        monthKey: string;
        label: string;
        inQty: number;
        inValue: number;
        outQty: number;
        outValue: number;
        netQty: number;
      }
    >();

    const sorted = [...filteredTx].sort(
      (a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    sorted.forEach((t) => {
      const d = new Date(t.date + "T00:00:00");
      if (isNaN(d.getTime())) return;

      const y = d.getFullYear();
      const m = d.getMonth();
      const monthKey = `${y}-${String(m + 1).padStart(2, "0")}`;

      const thaiMonths = ["ม.ค.", "ก.พ.", "มี.ค.", "เม.ย.", "พ.ค.", "มิ.ย.", "ก.ค.", "ส.ค.", "ก.ย.", "ต.ค.", "พ.ย.", "ธ.ค."];
      const thaiYear = (y + 543).toString().slice(-2);
      const label = `${thaiMonths[m]} ${thaiYear}`;

      let entry = map.get(monthKey);
      if (!entry) {
        entry = {
          monthKey,
          label,
          inQty: 0,
          inValue: 0,
          outQty: 0,
          outValue: 0,
          netQty: 0,
        };
        map.set(monthKey, entry);
      }

      const item = itemMap.get(t.itemId);
      const price = item?.price || 0;

      if (t.type === "in") {
        entry.inQty += t.qty;
        entry.inValue += t.qty * price;
        entry.netQty += t.qty;
      } else {
        entry.outQty += t.qty;
        entry.outValue += t.qty * price;
        entry.netQty -= t.qty;
      }
    });

    return Array.from(map.values()).slice(-8);
  }, [filteredTx, itemMap]);

  // Top dispensed medicines
  const topDispensed = useMemo(() => {
    const map = new Map<string, { id: string; name: string; unit: string; qty: number; value: number }>();

    filteredTx
      .filter((t) => t.type === "out")
      .forEach((t) => {
        const item = itemMap.get(t.itemId);
        if (!item) return;

        let entry = map.get(t.itemId);
        if (!entry) {
          entry = {
            id: t.itemId,
            name: item.name,
            unit: item.unit,
            qty: 0,
            value: 0,
          };
          map.set(t.itemId, entry);
        }
        entry.qty += t.qty;
        entry.value += t.qty * item.price;
      });

    return Array.from(map.values())
      .sort((a, b) => b.qty - a.qty)
      .slice(0, 5);
  }, [filteredTx, itemMap]);

  // Category valuation
  const categoryValuation = useMemo(() => {
    const map = new Map<string, { name: string; value: number; totalUnits: number }>();

    inv.items.forEach((it) => {
      const q = lotQtyForItem(inv.lots, it.id);
      const val = q * (Number(it.price) || 0);
      const cat = it.category || "อื่นๆ";

      let entry = map.get(cat);
      if (!entry) {
        entry = { name: cat, value: 0, totalUnits: 0 };
        map.set(cat, entry);
      }
      entry.value += val;
      entry.totalUnits += q;
    });

    return Array.from(map.values()).filter((c) => c.value > 0);
  }, [inv]);

  // Summary KPIs
  const kpi = useMemo(() => {
    let inQty = 0;
    let inVal = 0;
    let outQty = 0;
    let outVal = 0;

    filteredTx.forEach((t) => {
      const item = itemMap.get(t.itemId);
      const price = item?.price || 0;
      if (t.type === "in") {
        inQty += t.qty;
        inVal += t.qty * price;
      } else {
        outQty += t.qty;
        outVal += t.qty * price;
      }
    });

    return { inQty, inVal, outQty, outVal, netQty: inQty - outQty };
  }, [filteredTx, itemMap]);

  const selectedItemName = useMemo(() => {
    if (selectedItemId === "all") return "ยาสมุนไพรทั้งหมด";
    return inv.items.find((i) => i.id === selectedItemId)?.name || "ยาสมุนไพรที่เลือก";
  }, [selectedItemId, inv.items]);

  const timeRangeLabel = useMemo(() => {
    switch (timeRange) {
      case "30d": return "30 วันย้อนหลัง";
      case "90d": return "90 วันย้อนหลัง";
      case "6m": return "6 เดือนย้อนหลัง";
      case "1y": return "1 ปีย้อนหลัง";
      case "all": return "ข้อมูลประวัติทั้งหมด";
    }
  }, [timeRange]);

  async function handleExportPng(target: "full" | "trends" | "top" | "category" = "full") {
    setIsExporting(true);
    setExportTarget(target);
    setExportStatus("กำลังสร้างภาพกราฟความละเอียดสูง (300 DPI)...");

    try {
      const todayStr = new Date().toISOString().slice(0, 10);
      let elementId = "export-formal-report-card";
      let filename = `รายงานภาพกราฟการเคลื่อนไหวคลังยา_${todayStr}.png`;

      if (target === "trends") {
        elementId = "export-card-monthly-trends";
        filename = `กราฟแนวโน้มรับเข้าเบิกออกรายเดือน_${todayStr}.png`;
      } else if (target === "top") {
        elementId = "export-card-top-dispensed";
        filename = `กราฟ5อันดับยาเบิกจ่ายสูงสุด_${todayStr}.png`;
      } else if (target === "category") {
        elementId = "export-card-category-valuation";
        filename = `แผนภูมิสัดส่วนมูลค่าหมวดหมู่ยา_${todayStr}.png`;
      }

      await exportElementToPng(elementId, {
        filename,
        scale: 2.5,
        backgroundColor: "#FFFFFF",
        onProgress: (status) => setExportStatus(status),
      });

      showToast(`ส่งออกรูปภาพ PNG สำเร็จ (${filename}) พร้อมแนบในรายงานทางการ`);
    } catch (err) {
      console.error("Export PNG failed", err);
      showToast("เกิดข้อผิดพลาดในการส่งออกรูปภาพ PNG");
    } finally {
      setIsExporting(false);
      setExportStatus("");
    }
  }

  return (
    <div
      id="modal-chart-png-export-overlay"
      style={{
        position: "fixed",
        top: 0,
        left: 0,
        right: 0,
        bottom: 0,
        background: "rgba(0, 0, 0, 0.65)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        zIndex: 1100,
        padding: "16px",
      }}
      onClick={(e) => {
        if (e.target === e.currentTarget && !isExporting) onClose();
      }}
    >
      <div
        style={{
          background: "#FFFFFF",
          borderRadius: 12,
          width: "100%",
          maxWidth: 960,
          maxHeight: "92vh",
          display: "flex",
          flexDirection: "column",
          boxShadow: "0 20px 50px rgba(0, 0, 0, 0.35)",
          overflow: "hidden",
        }}
      >
        {/* Top Control Header */}
        <div
          style={{
            padding: "16px 20px",
            background: "#2D4834",
            color: "#FFFFFF",
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 12,
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div
              style={{
                background: "rgba(255, 255, 255, 0.15)",
                padding: "8px",
                borderRadius: 8,
                display: "flex",
              }}
            >
              <ImageIcon size={22} color="#FFFFFF" />
            </div>
            <div>
              <h2 style={{ margin: 0, fontSize: 18, fontWeight: 700, fontFamily: "'Noto Serif Thai', serif" }}>
                ส่งออกภาพกราฟวิเคราะห์ข้อมูลธุรกรรม (PNG Image Export)
              </h2>
              <div style={{ fontSize: 12, opacity: 0.85 }}>
                รูปภาพความละเอียดสูง (High Resolution) สำหรับแนบในรายงานคลังยาทางการหรือเอกสารนำเสนอ
              </div>
            </div>
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <button
              id="btn-download-all-charts-png"
              onClick={() => handleExportPng("full")}
              disabled={isExporting}
              style={{
                background: "#E8F0EA",
                color: "#1F3826",
                border: "none",
                borderRadius: 6,
                padding: "8px 18px",
                fontSize: 13.5,
                fontWeight: 700,
                cursor: isExporting ? "wait" : "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 8,
                boxShadow: "0 2px 6px rgba(0, 0, 0, 0.2)",
                fontFamily: "Sarabun, sans-serif",
              }}
            >
              <Download size={16} />
              <span>{isExporting && exportTarget === "full" ? exportStatus || "กำลังส่งออก..." : "ดาวน์โหลดภาพรวมรายงาน (PNG)"}</span>
            </button>

            <button
              id="btn-close-chart-export-modal"
              onClick={onClose}
              disabled={isExporting}
              style={{
                background: "transparent",
                border: "none",
                color: "#FFFFFF",
                cursor: "pointer",
                padding: "4px",
                opacity: 0.8,
              }}
            >
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Filter and Download Specific Option Bar */}
        <div
          style={{
            padding: "10px 20px",
            background: "#F7F5EE",
            borderBottom: "1px solid #E5E0D2",
            display: "flex",
            alignItems: "center",
            justifyContent: "space-between",
            flexWrap: "wrap",
            gap: 10,
            fontSize: 12.5,
          }}
        >
          {/* Filters */}
          <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontWeight: 700, color: "#2D4834" }}>ช่วงเวลา:</span>
              <div
                style={{
                  display: "inline-flex",
                  background: "#FFFFFF",
                  border: "1px solid #D8D3C2",
                  borderRadius: 6,
                  padding: "2px",
                  gap: 2,
                }}
              >
                {[
                  { id: "30d", label: "30 วัน" },
                  { id: "90d", label: "90 วัน" },
                  { id: "6m", label: "6 เดือน" },
                  { id: "1y", label: "1 ปี" },
                  { id: "all", label: "ทั้งหมด" },
                ].map((btn) => (
                  <button
                    key={btn.id}
                    onClick={() => setTimeRange(btn.id as any)}
                    style={{
                      border: "none",
                      background: timeRange === btn.id ? "#3C5A45" : "transparent",
                      color: timeRange === btn.id ? "#FFFFFF" : "#5B5747",
                      fontSize: 11.5,
                      fontWeight: 600,
                      padding: "3px 8px",
                      borderRadius: 4,
                      cursor: "pointer",
                      fontFamily: "Sarabun, sans-serif",
                    }}
                  >
                    {btn.label}
                  </button>
                ))}
              </div>
            </div>

            <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
              <span style={{ fontWeight: 700, color: "#2D4834" }}>รายการยา:</span>
              <select
                value={selectedItemId}
                onChange={(e) => setSelectedItemId(e.target.value)}
                style={{
                  border: "1px solid #D8D3C2",
                  borderRadius: 6,
                  padding: "3px 8px",
                  fontSize: 12,
                  background: "#FFFFFF",
                  color: "#1F2D24",
                  fontFamily: "Sarabun, sans-serif",
                  fontWeight: 600,
                }}
              >
                <option value="all">ยาสมุนไพรทั้งหมด ({inv.items.length} รายการ)</option>
                {inv.items.map((it) => (
                  <option key={it.id} value={it.id}>
                    {it.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          {/* Quick Individual Chart Downloads */}
          <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
            <span style={{ fontSize: 11.5, color: "#746E5D" }}>ดาวน์โหลดเฉพาะกราฟ:</span>
            <button
              id="btn-download-trend-chart-png"
              onClick={() => handleExportPng("trends")}
              disabled={isExporting}
              style={{
                background: "#FFFFFF",
                border: "1px solid #C8D8CB",
                color: "#2D4834",
                borderRadius: 5,
                padding: "3px 8px",
                fontSize: 11.5,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              📥 กราฟแนวโน้มรายเดือน
            </button>
            <button
              id="btn-download-top-chart-png"
              onClick={() => handleExportPng("top")}
              disabled={isExporting}
              style={{
                background: "#FFFFFF",
                border: "1px solid #C8D8CB",
                color: "#2D4834",
                borderRadius: 5,
                padding: "3px 8px",
                fontSize: 11.5,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              📥 กราฟ 5 อันดับเบิกจ่าย
            </button>
            <button
              id="btn-download-category-chart-png"
              onClick={() => handleExportPng("category")}
              disabled={isExporting}
              style={{
                background: "#FFFFFF",
                border: "1px solid #C8D8CB",
                color: "#2D4834",
                borderRadius: 5,
                padding: "3px 8px",
                fontSize: 11.5,
                fontWeight: 600,
                cursor: "pointer",
              }}
            >
              📥 กราฟหมวดหมู่ยา
            </button>
          </div>
        </div>

        {/* Printable/Exportable Canvas Container */}
        <div
          style={{
            flex: 1,
            overflowY: "auto",
            padding: "20px",
            background: "#EBE8DF",
            display: "flex",
            justifyContent: "center",
          }}
        >
          {/* Main Formal Report Card Container (This is captured by html2canvas) */}
          <div
            id="export-formal-report-card"
            style={{
              background: "#FFFFFF",
              width: "100%",
              maxWidth: 860,
              padding: "32px 36px",
              boxShadow: "0 4px 16px rgba(0, 0, 0, 0.08)",
              borderRadius: 6,
              color: "#1F2D24",
              fontFamily: "'Sarabun', 'Noto Serif Thai', sans-serif",
              boxSizing: "border-box",
            }}
          >
            {/* Formal Report Header */}
            <div
              style={{
                borderBottom: "2px solid #2D4834",
                paddingBottom: 14,
                marginBottom: 18,
                display: "flex",
                justifyContent: "space-between",
                alignItems: "flex-start",
              }}
            >
              <div>
                <div style={{ display: "flex", alignItems: "center", gap: 8, color: "#2D4834", marginBottom: 3 }}>
                  <Building size={18} />
                  <span style={{ fontWeight: 700, fontSize: 13, textTransform: "uppercase", letterSpacing: "0.5px" }}>
                    โรงพยาบาลการแพทย์แผนไทยและระบบคลังเวชภัณฑ์สมุนไพร
                  </span>
                </div>
                <h1
                  style={{
                    margin: "2px 0 4px",
                    fontSize: 20,
                    fontWeight: 800,
                    color: "#1A2E20",
                    fontFamily: "'Noto Serif Thai', serif",
                  }}
                >
                  รายงานภาพกราฟวิเคราะห์ประวัติธุรกรรมคลังยาสมุนไพร
                </h1>
                <div style={{ fontSize: 12, color: "#6A7B6E" }}>
                  Historical Transaction Data Visualisations · Inventory Movements & Valuation
                </div>
              </div>

              <div style={{ textAlign: "right", fontSize: 11.5, color: "#5F6C62" }}>
                <div>
                  วันที่พิมพ์: <b>{new Date().toLocaleDateString("th-TH", { day: "numeric", month: "short", year: "numeric" })}</b>
                </div>
                <div>
                  ช่วงเวลาวิเคราะห์: <b>{timeRangeLabel}</b>
                </div>
                <div>
                  ขอบเขตข้อมูล: <b>{selectedItemName}</b>
                </div>
              </div>
            </div>

            {/* KPI Summary Strip */}
            <div
              style={{
                display: "grid",
                gridTemplateColumns: "repeat(4, 1fr)",
                gap: 12,
                marginBottom: 22,
              }}
            >
              <div
                style={{
                  background: "#F2F6F3",
                  border: "1px solid #D5E2D8",
                  borderRadius: 6,
                  padding: "10px 14px",
                }}
              >
                <div style={{ fontSize: 11, color: "#3C5A45", fontWeight: 700 }}>ยอดรับเข้ารวม</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: "#1F2D24", marginTop: 2 }}>
                  +{kpi.inQty.toLocaleString()} <span style={{ fontSize: 12, fontWeight: 500 }}>หน่วย</span>
                </div>
                <div style={{ fontSize: 11, color: "#3C5A45", marginTop: 2 }}>
                  มูลค่า ฿{kpi.inVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
              </div>

              <div
                style={{
                  background: "#FBF5F4",
                  border: "1px solid #F1D4D1",
                  borderRadius: 6,
                  padding: "10px 14px",
                }}
              >
                <div style={{ fontSize: 11, color: "#A83B32", fontWeight: 700 }}>ยอดเบิกจ่ายรวม</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: "#1F2D24", marginTop: 2 }}>
                  -{kpi.outQty.toLocaleString()} <span style={{ fontSize: 12, fontWeight: 500 }}>หน่วย</span>
                </div>
                <div style={{ fontSize: 11, color: "#A83B32", marginTop: 2 }}>
                  มูลค่า ฿{kpi.outVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
              </div>

              <div
                style={{
                  background: kpi.netQty >= 0 ? "#EEF3EF" : "#FBEDEB",
                  border: kpi.netQty >= 0 ? "1px solid #CCDDCF" : "1px solid #F1C3BF",
                  borderRadius: 6,
                  padding: "10px 14px",
                }}
              >
                <div style={{ fontSize: 11, color: kpi.netQty >= 0 ? "#2D683D" : "#A83B32", fontWeight: 700 }}>
                  การเคลื่อนไหวสุทธิ
                </div>
                <div
                  style={{
                    fontSize: 18,
                    fontWeight: 800,
                    color: kpi.netQty >= 0 ? "#2D683D" : "#A83B32",
                    marginTop: 2,
                  }}
                >
                  {kpi.netQty >= 0 ? `+${kpi.netQty.toLocaleString()}` : kpi.netQty.toLocaleString()}{" "}
                  <span style={{ fontSize: 12, fontWeight: 500 }}>หน่วย</span>
                </div>
                <div style={{ fontSize: 11, color: "#6A7B6E", marginTop: 2 }}>
                  {kpi.netQty >= 0 ? "สต็อกเพิ่มขึ้นสุทธิ" : "สต็อกลดลงสุทธิ"}
                </div>
              </div>

              <div
                style={{
                  background: "#FBF8EE",
                  border: "1px solid #EDE2C0",
                  borderRadius: 6,
                  padding: "10px 14px",
                }}
              >
                <div style={{ fontSize: 11, color: "#8E691A", fontWeight: 700 }}>มูลค่าหมุนเวียนรวม</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: "#1F2D24", marginTop: 2 }}>
                  ฿{(kpi.inVal + kpi.outVal).toLocaleString(undefined, { maximumFractionDigits: 0 })}
                </div>
                <div style={{ fontSize: 11, color: "#8E691A", marginTop: 2 }}>
                  ธุรกรรม {filteredTx.length} ครั้ง
                </div>
              </div>
            </div>

            {/* Chart 1: Monthly Trends Chart */}
            <div
              id="export-card-monthly-trends"
              style={{
                border: "1px solid #E5DFD1",
                borderRadius: 8,
                padding: "16px 18px",
                background: "#FFFFFF",
                marginBottom: 20,
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
                <div style={{ fontWeight: 700, fontSize: 14, color: "#1F2D24", display: "flex", alignItems: "center", gap: 6 }}>
                  <TrendingUp size={16} color="#3C5A45" />
                  <span>แนวโน้มการรับเข้า - เบิกจ่ายยาสมุนไพรรายเดือน (Monthly Transactions In/Out)</span>
                </div>
                <span style={{ fontSize: 11, color: "#8A8874" }}>หน่วย: จำนวนชิ้น/ขวด</span>
              </div>

              {monthlyData.length === 0 ? (
                <div style={{ textAlign: "center", padding: "40px 0", color: "#8A8874", fontSize: 13 }}>
                  ไม่มีข้อมูลธุรกรรมในช่วงเวลาที่เลือก
                </div>
              ) : (
                <div style={{ width: "100%", height: 260 }}>
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={monthlyData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#EBE8DC" />
                      <XAxis dataKey="label" stroke="#8A8874" fontSize={11} tickLine={false} />
                      <YAxis stroke="#8A8874" fontSize={11} tickLine={false} axisLine={false} />
                      <Tooltip
                        contentStyle={{
                          backgroundColor: "#FFFFFF",
                          border: "1px solid #DCD7C8",
                          borderRadius: "6px",
                          fontSize: "12px",
                        }}
                      />
                      <Legend verticalAlign="top" height={32} iconType="circle" wrapperStyle={{ fontSize: "12px" }} />
                      <Bar dataKey="inQty" name="รับเข้า (Inflow)" fill="#3C5A45" radius={[4, 4, 0, 0]} maxBarSize={38} />
                      <Bar dataKey="outQty" name="เบิกออก (Outflow)" fill="#A83B32" radius={[4, 4, 0, 0]} maxBarSize={38} />
                      <Line
                        type="monotone"
                        dataKey="netQty"
                        name="สุทธิ (Net Change)"
                        stroke="#C08A2E"
                        strokeWidth={2.5}
                        dot={{ r: 4, fill: "#C08A2E" }}
                      />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              )}
            </div>

            {/* Grid of Chart 2 & Chart 3 */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 16, marginBottom: 20 }}>
              {/* Chart 2: Top 5 Dispensed Herbs */}
              <div
                id="export-card-top-dispensed"
                style={{
                  border: "1px solid #E5DFD1",
                  borderRadius: 8,
                  padding: "16px 18px",
                  background: "#FFFFFF",
                }}
              >
                <div style={{ fontWeight: 700, fontSize: 13.5, color: "#1F2D24", marginBottom: 12 }}>
                  5 อันดับยาสมุนไพรที่มีการเบิกจ่ายสูงสุด (Top Dispensed)
                </div>

                {topDispensed.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "40px 0", color: "#8A8874", fontSize: 12.5 }}>
                    ยังไม่มีข้อมูลการเบิกจ่ายในช่วงเวลานี้
                  </div>
                ) : (
                  <div style={{ width: "100%", height: 210 }}>
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={topDispensed} layout="vertical" margin={{ top: 5, right: 20, left: 30, bottom: 5 }}>
                        <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#EBE8DC" />
                        <XAxis type="number" stroke="#8A8874" fontSize={10.5} tickLine={false} />
                        <YAxis
                          type="category"
                          dataKey="name"
                          stroke="#1F2D24"
                          fontSize={11}
                          tickLine={false}
                          axisLine={false}
                          width={85}
                        />
                        <Tooltip
                          formatter={(val: any, name: any, props: any) => [
                            `${val} ${props.payload.unit} (฿${props.payload.value.toLocaleString()})`,
                            "ยอดเบิกจ่าย",
                          ]}
                          contentStyle={{ fontSize: "11.5px", borderRadius: "6px" }}
                        />
                        <Bar dataKey="qty" fill="#A83B32" radius={[0, 4, 4, 0]} maxBarSize={20} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                )}
              </div>

              {/* Chart 3: Category Valuation Share */}
              <div
                id="export-card-category-valuation"
                style={{
                  border: "1px solid #E5DFD1",
                  borderRadius: 8,
                  padding: "16px 18px",
                  background: "#FFFFFF",
                }}
              >
                <div style={{ fontWeight: 700, fontSize: 13.5, color: "#1F2D24", marginBottom: 8 }}>
                  สัดส่วนมูลค่าสต็อกตามหมวดหมู่ยา (Category Valuation)
                </div>

                {categoryValuation.length === 0 ? (
                  <div style={{ textAlign: "center", padding: "40px 0", color: "#8A8874", fontSize: 12.5 }}>
                    ไม่มีข้อมูลมูลค่าสต็อก
                  </div>
                ) : (
                  <div style={{ display: "flex", alignItems: "center", height: 210 }}>
                    <div style={{ width: "55%", height: "100%" }}>
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={categoryValuation}
                            dataKey="value"
                            nameKey="name"
                            cx="50%"
                            cy="50%"
                            innerRadius={36}
                            outerRadius={68}
                            paddingAngle={2}
                          >
                            {categoryValuation.map((entry, index) => (
                              <Cell
                                key={`cell-${index}`}
                                fill={CATEGORY_COLORS[entry.name] || DEFAULT_PALETTE[index % DEFAULT_PALETTE.length]}
                              />
                            ))}
                          </Pie>
                          <Tooltip
                            formatter={(val: any) => [`฿${Number(val).toLocaleString()}`, "มูลค่า"]}
                            contentStyle={{ fontSize: "11px", borderRadius: "6px" }}
                          />
                        </PieChart>
                      </ResponsiveContainer>
                    </div>

                    <div style={{ width: "45%", fontSize: 11, display: "flex", flexDirection: "column", gap: 5 }}>
                      {categoryValuation.slice(0, 5).map((entry, idx) => (
                        <div key={entry.name} style={{ display: "flex", alignItems: "center", gap: 5 }}>
                          <span
                            style={{
                              width: 8,
                              height: 8,
                              borderRadius: "50%",
                              background: CATEGORY_COLORS[entry.name] || DEFAULT_PALETTE[idx % DEFAULT_PALETTE.length],
                              flexShrink: 0,
                            }}
                          />
                          <span style={{ color: "#3C483F", flex: 1, whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                            {entry.name}
                          </span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Formal Report Sign-off Footer */}
            <div
              style={{
                marginTop: 24,
                paddingTop: 16,
                borderTop: "1px dashed #D6D1C1",
                display: "grid",
                gridTemplateColumns: "1fr 1fr",
                gap: 36,
                fontSize: 11.5,
              }}
            >
              <div style={{ textAlign: "center" }}>
                <div style={{ marginBottom: 36 }}>ผู้จัดทำรายงาน:</div>
                <div style={{ borderBottom: "1px solid #8A8874", width: 170, margin: "0 auto 4px" }}></div>
                <div style={{ fontWeight: 600 }}>(เภสัชกร ประจำการ)</div>
                <div style={{ color: "#746E5D", fontSize: 10.5 }}>ผู้รับผิดชอบงานคลังยาสมุนไพร</div>
              </div>

              <div style={{ textAlign: "center" }}>
                <div style={{ marginBottom: 36 }}>ผู้รับรองรายงาน:</div>
                <div style={{ borderBottom: "1px solid #8A8874", width: 170, margin: "0 auto 4px" }}></div>
                <div style={{ fontWeight: 600 }}>(........................................................)</div>
                <div style={{ color: "#746E5D", fontSize: 10.5 }}>หัวหน้ากลุ่มงานเภสัชกรรมแผนไทย</div>
              </div>
            </div>

            {/* Watermark / Citation */}
            <div
              style={{
                marginTop: 20,
                textAlign: "center",
                fontSize: 10,
                color: "#9C9788",
                borderTop: "1px solid #F0EEE3",
                paddingTop: 6,
              }}
            >
              เอกสารส่งออกรูปภาพสำหรับรายงานทางการ · ระบบบริหารจัดการคลังยาสมุนไพรและเภสัชกรรมแผนไทย
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
