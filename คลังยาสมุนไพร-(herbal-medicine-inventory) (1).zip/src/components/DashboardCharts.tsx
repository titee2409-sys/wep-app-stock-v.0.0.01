import React, { useState, useMemo } from "react";
import {
  ResponsiveContainer,
  ComposedChart,
  BarChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import {
  TrendingUp,
  ArrowDownLeft,
  ArrowUpRight,
  Filter,
  DollarSign,
  Package,
  Layers,
  Award,
  Image as ImageIcon,
} from "lucide-react";
import type { InventoryState, StockTransaction } from "../types";
import { Panel } from "./Panel";
import { lotQtyForItem } from "../utils/storage";
import { ChartImageExportModal } from "./ChartImageExportModal";

interface DashboardChartsProps {
  inv: InventoryState;
  tx: StockTransaction[];
}

type TimeRange = "30d" | "90d" | "6m" | "1y" | "all";
type ViewMode = "combined" | "qty" | "value";

const CATEGORY_COLORS: Record<string, string> = {
  "ยาแคปซูล": "#3C5A45",
  "ยาเม็ด": "#5B7A63",
  "ยาน้ำ/ยาดอง": "#C08A2E",
  "ยาดม/ยาหม่อง": "#8A6D3B",
  "วัตถุดิบสมุนไพรดิบ": "#6B8E23",
  "ยาผง": "#A83B32",
  "อื่นๆ": "#8A8874",
};

const DEFAULT_PALETTE = ["#3C5A45", "#5B7A63", "#C08A2E", "#A83B32", "#8A6D3B", "#4A7055", "#9CB68C"];

export function DashboardCharts({ inv, tx }: DashboardChartsProps) {
  const [timeRange, setTimeRange] = useState<TimeRange>("6m");
  const [viewMode, setViewMode] = useState<ViewMode>("combined");
  const [selectedItemId, setSelectedItemId] = useState<string>("all");
  const [breakdownTab, setBreakdownTab] = useState<"top_dispensed" | "category_value">("top_dispensed");
  const [showImageExportModal, setShowImageExportModal] = useState(false);

  // Map itemId to item quick lookup
  const itemMap = useMemo(() => {
    const map = new Map<string, { name: string; category: string; unit: string; price: number }>();
    inv.items.forEach((it) => {
      map.set(it.id, {
        name: it.name,
        category: it.category,
        unit: it.unit,
        price: Number(it.price) || 0,
      });
    });
    return map;
  }, [inv.items]);

  // Filter transactions by timeRange and selectedItem
  const filteredTx = useMemo(() => {
    const now = new Date();
    let cutoff = new Date(0);

    if (timeRange === "30d") {
      cutoff = new Date(now.getTime() - 30 * 24 * 60 * 60 * 1000);
    } else if (timeRange === "90d") {
      cutoff = new Date(now.getTime() - 90 * 24 * 60 * 60 * 1000);
    } else if (timeRange === "6m") {
      cutoff = new Date(now.getTime() - 180 * 24 * 60 * 60 * 1000);
    } else if (timeRange === "1y") {
      cutoff = new Date(now.getTime() - 365 * 24 * 60 * 60 * 1000);
    }

    return tx.filter((t) => {
      if (selectedItemId !== "all" && t.itemId !== selectedItemId) return false;
      const tDate = new Date(t.date + "T00:00:00");
      return tDate >= cutoff;
    });
  }, [tx, timeRange, selectedItemId]);

  // Aggregate KPI summary for the selected period
  const kpi = useMemo(() => {
    let inQty = 0;
    let inVal = 0;
    let outQty = 0;
    let outVal = 0;

    filteredTx.forEach((t) => {
      const item = itemMap.get(t.itemId);
      const price = item?.price || 0;
      const val = t.qty * price;

      if (t.type === "in") {
        inQty += t.qty;
        inVal += val;
      } else {
        outQty += t.qty;
        outVal += val;
      }
    });

    const netQty = inQty - outQty;
    const netVal = inVal - outVal;
    const dispenseRatio = inQty > 0 ? ((outQty / inQty) * 100).toFixed(1) : "0.0";

    return { inQty, inVal, outQty, outVal, netQty, netVal, dispenseRatio };
  }, [filteredTx, itemMap]);

  // Aggregate time series data for the main chart
  const timeSeriesData = useMemo(() => {
    if (filteredTx.length === 0) return [];

    // Grouping strategy based on timeRange
    // If <= 30d, group by Day (YYYY-MM-DD)
    // If > 30d, group by Month (YYYY-MM)
    const isDaily = timeRange === "30d";
    const groupMap = new Map<
      string,
      {
        key: string;
        label: string;
        inQty: number;
        outQty: number;
        inValue: number;
        outValue: number;
        netValue: number;
        sortDate: number;
      }
    >();

    filteredTx.forEach((t) => {
      const dateObj = new Date(t.date + "T00:00:00");
      const key = isDaily
        ? t.date
        : `${dateObj.getFullYear()}-${String(dateObj.getMonth() + 1).padStart(2, "0")}`;

      const item = itemMap.get(t.itemId);
      const price = item?.price || 0;
      const val = t.qty * price;

      let entry = groupMap.get(key);
      if (!entry) {
        let label = "";
        if (isDaily) {
          label = dateObj.toLocaleDateString("th-TH", { day: "numeric", month: "short" });
        } else {
          label = dateObj.toLocaleDateString("th-TH", { month: "short", year: "2-digit" });
        }
        entry = {
          key,
          label,
          inQty: 0,
          outQty: 0,
          inValue: 0,
          outValue: 0,
          netValue: 0,
          sortDate: dateObj.getTime(),
        };
        groupMap.set(key, entry);
      }

      if (t.type === "in") {
        entry.inQty += t.qty;
        entry.inValue += val;
      } else {
        entry.outQty += t.qty;
        entry.outValue += val;
      }
      entry.netValue = entry.inValue - entry.outValue;
    });

    return Array.from(groupMap.values()).sort((a, b) => a.sortDate - b.sortDate);
  }, [filteredTx, timeRange, itemMap]);

  // Top dispensed items by quantity and value
  const topDispensed = useMemo(() => {
    const map = new Map<string, { id: string; name: string; unit: string; price: number; qty: number; value: number }>();

    filteredTx
      .filter((t) => t.type === "out")
      .forEach((t) => {
        const item = itemMap.get(t.itemId);
        if (!item) return;
        let entry = map.get(t.itemId);
        if (!entry) {
          entry = {
            id: t.itemId,
            name: item.name,
            unit: item.unit,
            price: item.price,
            qty: 0,
            value: 0,
          };
          map.set(t.itemId, entry);
        }
        entry.qty += t.qty;
        entry.value += t.qty * item.price;
      });

    return Array.from(map.values())
      .sort((a, b) => b.qty - a.qty)
      .slice(0, 5);
  }, [filteredTx, itemMap]);

  // Category Inventory Valuation breakdown
  const categoryValuation = useMemo(() => {
    const map = new Map<string, { name: string; value: number; totalUnits: number; itemsCount: number }>();

    inv.items.forEach((it) => {
      const q = lotQtyForItem(inv.lots, it.id);
      const val = q * (Number(it.price) || 0);
      const cat = it.category || "อื่นๆ";

      let entry = map.get(cat);
      if (!entry) {
        entry = { name: cat, value: 0, totalUnits: 0, itemsCount: 0 };
        map.set(cat, entry);
      }
      entry.value += val;
      entry.totalUnits += q;
      entry.itemsCount += 1;
    });

    return Array.from(map.values()).filter((c) => c.value > 0);
  }, [inv]);

  const totalCatValuation = useMemo(() => {
    return categoryValuation.reduce((sum, c) => sum + c.value, 0);
  }, [categoryValuation]);

  return (
    <div id="dashboard-charts-container" style={{ marginTop: 20 }}>
      {/* Section Header & Controls */}
      <Panel
        id="panel-stock-analytics"
        accent="#3C5A45"
        style={{ padding: "18px 22px", marginBottom: 16 }}
      >
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 12,
            marginBottom: 16,
          }}
        >
          <div>
            <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
              <TrendingUp size={19} color="#3C5A45" />
              <h2
                style={{
                  fontFamily: "'Noto Serif Thai', serif",
                  fontSize: 18,
                  fontWeight: 700,
                  margin: 0,
                  color: "#1F2D24",
                }}
              >
                กราฟวิเคราะห์การรับเข้า - เบิกออก และมูลค่ายาสมุนไพร
              </h2>
            </div>
            <p style={{ margin: "3px 0 0", fontSize: 13, color: "#8A8874" }}>
              วิเคราะห์แนวโน้มปริมาณเวชภัณฑ์และการเคลื่อนไหวทางการเงินย้อนหลัง
            </p>
          </div>

          {/* Filters Bar */}
          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            {/* Item Filter Dropdown */}
            <div style={{ display: "flex", alignItems: "center", gap: 5, background: "#F6F3EA", padding: "4px 8px", borderRadius: 7, border: "1px solid #D8D3C2" }}>
              <Filter size={13} color="#5B5747" />
              <select
                id="chart-item-filter"
                value={selectedItemId}
                onChange={(e) => setSelectedItemId(e.target.value)}
                style={{
                  background: "transparent",
                  border: "none",
                  fontSize: 12.5,
                  fontFamily: "Sarabun, sans-serif",
                  fontWeight: 600,
                  color: "#1F2D24",
                  outline: "none",
                  cursor: "pointer",
                }}
              >
                <option value="all">ยาสมุนไพรทั้งหมด ({inv.items.length} รายการ)</option>
                {inv.items.map((it) => (
                  <option key={it.id} value={it.id}>
                    {it.name} (฿{it.price}/{it.unit})
                  </option>
                ))}
              </select>
            </div>

            {/* Time Range Selector Buttons */}
            <div
              style={{
                display: "inline-flex",
                background: "#F6F3EA",
                padding: "3px",
                borderRadius: 7,
                border: "1px solid #D8D3C2",
                gap: 2,
              }}
            >
              {[
                { id: "30d", label: "30 วัน" },
                { id: "90d", label: "90 วัน" },
                { id: "6m", label: "6 เดือน" },
                { id: "1y", label: "1 ปี" },
                { id: "all", label: "ทั้งหมด" },
              ].map((btn) => (
                <button
                  key={btn.id}
                  id={`btn-timerange-${btn.id}`}
                  onClick={() => setTimeRange(btn.id as TimeRange)}
                  style={{
                    border: "none",
                    background: timeRange === btn.id ? "#3C5A45" : "transparent",
                    color: timeRange === btn.id ? "#fff" : "#5B5747",
                    fontSize: 12,
                    fontWeight: 600,
                    padding: "4px 10px",
                    borderRadius: 5,
                    cursor: "pointer",
                    fontFamily: "Sarabun, sans-serif",
                    transition: "all 0.15s ease",
                  }}
                >
                  {btn.label}
                </button>
              ))}
            </div>

            {/* View Mode Toggle */}
            <div
              style={{
                display: "inline-flex",
                background: "#F6F3EA",
                padding: "3px",
                borderRadius: 7,
                border: "1px solid #D8D3C2",
                gap: 2,
              }}
            >
              {[
                { id: "combined", label: "ปริมาณ + มูลค่า ฿" },
                { id: "qty", label: "จำนวนหน่วย" },
                { id: "value", label: "มูลค่าราคา (฿)" },
              ].map((btn) => (
                <button
                  key={btn.id}
                  id={`btn-viewmode-${btn.id}`}
                  onClick={() => setViewMode(btn.id as ViewMode)}
                  style={{
                    border: "none",
                    background: viewMode === btn.id ? "#1F2D24" : "transparent",
                    color: viewMode === btn.id ? "#fff" : "#5B5747",
                    fontSize: 12,
                    fontWeight: 600,
                    padding: "4px 10px",
                    borderRadius: 5,
                    cursor: "pointer",
                    fontFamily: "Sarabun, sans-serif",
                    transition: "all 0.15s ease",
                  }}
                >
                  {btn.label}
                </button>
              ))}
            </div>

            {/* Export PNG Image Button */}
            <button
              id="btn-export-charts-png"
              onClick={() => setShowImageExportModal(true)}
              style={{
                background: "#FFFFFF",
                border: "1px solid #C4D5C7",
                color: "#2D4834",
                borderRadius: 7,
                padding: "4px 12px",
                fontSize: 12,
                fontWeight: 700,
                cursor: "pointer",
                display: "inline-flex",
                alignItems: "center",
                gap: 5,
                boxShadow: "0 1px 3px rgba(0,0,0,0.03)",
                fontFamily: "Sarabun, sans-serif",
                transition: "all 0.15s ease",
              }}
              title="ส่งออกภาพกราฟวิเคราะห์ประวัติความเคลื่อนไหว (PNG) สำหรับแนบในรายงานคลังยาทางการ"
            >
              <ImageIcon size={14} color="#2D4834" />
              <span>ส่งออกกราฟ PNG</span>
            </button>
          </div>
        </div>

        {/* Selected Period KPI Mini-Cards */}
        <div
          style={{
            display: "grid",
            gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))",
            gap: 10,
            marginBottom: 20,
          }}
        >
          <div
            id="kpi-inflow"
            style={{
              background: "#F2F6F3",
              padding: "10px 14px",
              borderRadius: 8,
              border: "1px solid #D9E4DC",
              display: "flex",
              alignItems: "center",
              gap: 12,
            }}
          >
            <div style={{ background: "#3C5A45", color: "#fff", padding: 8, borderRadius: 8 }}>
              <ArrowDownLeft size={16} />
            </div>
            <div>
              <div style={{ fontSize: 11.5, color: "#5B7A63", fontWeight: 700 }}>ยอดรับเข้ารวม</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#1F2D24" }}>
                {kpi.inQty.toLocaleString()} <span style={{ fontSize: 12, fontWeight: 500 }}>หน่วย</span>
              </div>
              <div style={{ fontSize: 11.5, color: "#3C5A45", fontWeight: 600 }}>
                มูลค่า ฿{kpi.inVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </div>
            </div>
          </div>

          <div
            id="kpi-outflow"
            style={{
              background: "#FBF5F4",
              padding: "10px 14px",
              borderRadius: 8,
              border: "1px solid #EEDCD9",
              display: "flex",
              alignItems: "center",
              gap: 12,
            }}
          >
            <div style={{ background: "#A83B32", color: "#fff", padding: 8, borderRadius: 8 }}>
              <ArrowUpRight size={16} />
            </div>
            <div>
              <div style={{ fontSize: 11.5, color: "#A83B32", fontWeight: 700 }}>ยอดเบิกจ่ายรวม</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#1F2D24" }}>
                {kpi.outQty.toLocaleString()} <span style={{ fontSize: 12, fontWeight: 500 }}>หน่วย</span>
              </div>
              <div style={{ fontSize: 11.5, color: "#A83B32", fontWeight: 600 }}>
                มูลค่า ฿{kpi.outVal.toLocaleString(undefined, { maximumFractionDigits: 0 })}
              </div>
            </div>
          </div>

          <div
            id="kpi-net-movement"
            style={{
              background: "#FAF8F1",
              padding: "10px 14px",
              borderRadius: 8,
              border: "1px solid #ECE4CE",
              display: "flex",
              alignItems: "center",
              gap: 12,
            }}
          >
            <div style={{ background: "#C08A2E", color: "#fff", padding: 8, borderRadius: 8 }}>
              <DollarSign size={16} />
            </div>
            <div>
              <div style={{ fontSize: 11.5, color: "#946A1F", fontWeight: 700 }}>ผลต่างสต็อกสุทธิ</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: kpi.netQty >= 0 ? "#3C5A45" : "#A83B32" }}>
                {kpi.netQty > 0 ? `+${kpi.netQty}` : kpi.netQty} <span style={{ fontSize: 12, fontWeight: 500 }}>หน่วย</span>
              </div>
              <div style={{ fontSize: 11.5, color: "#5B5747", fontWeight: 600 }}>
                มูลค่าสุทธิ {kpi.netVal >= 0 ? `+฿${kpi.netVal.toLocaleString()}` : `-฿${Math.abs(kpi.netVal).toLocaleString()}`}
              </div>
            </div>
          </div>

          <div
            id="kpi-turnover-rate"
            style={{
              background: "#F5F5F0",
              padding: "10px 14px",
              borderRadius: 8,
              border: "1px solid #E2E0D4",
              display: "flex",
              alignItems: "center",
              gap: 12,
            }}
          >
            <div style={{ background: "#5B5747", color: "#fff", padding: 8, borderRadius: 8 }}>
              <Layers size={16} />
            </div>
            <div>
              <div style={{ fontSize: 11.5, color: "#5B5747", fontWeight: 700 }}>อัตราการเบิกจ่าย</div>
              <div style={{ fontSize: 16, fontWeight: 700, color: "#1F2D24" }}>
                {kpi.dispenseRatio}% <span style={{ fontSize: 12, fontWeight: 500 }}>ของรับเข้า</span>
              </div>
              <div style={{ fontSize: 11.5, color: "#8A8874" }}>
                บันทึก {filteredTx.length} ธุรกรรม
              </div>
            </div>
          </div>
        </div>

        {/* Main Historical Chart */}
        <div style={{ background: "#FCFAF6", border: "1px solid #EBE7DA", borderRadius: 8, padding: "16px 14px 10px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12, paddingLeft: 6, paddingRight: 6 }}>
            <span style={{ fontSize: 13, fontWeight: 700, color: "#3C5A45" }}>
              {viewMode === "combined" && "📊 แนวโน้มปริมาณรับเข้า/เบิกออก และมูลค่าการเงินสุทธิ"}
              {viewMode === "qty" && "📦 เปรียบเทียบปริมาณรับเข้า (Inflow) vs เบิกออก (Outflow)"}
              {viewMode === "value" && "💰 เปรียบเทียบมูลค่าทางบัญชี (บาท) รับเข้า vs เบิกออก"}
            </span>
            <span style={{ fontSize: 11.5, color: "#8A8874" }}>
              {timeSeriesData.length > 0
                ? `${timeSeriesData.length} ช่วงเวลาบันทึก`
                : "ไม่มีข้อมูลในช่วงเวลาที่เลือก"}
            </span>
          </div>

          {timeSeriesData.length === 0 ? (
            <div style={{ textAlign: "center", padding: "48px 16px", color: "#8A8874", fontSize: 13 }}>
              ไม่พบรายการเคลื่อนไหวตามตัวกรองที่กำหนด โปรดลองเลือกช่วงเวลาอื่น
            </div>
          ) : (
            <div style={{ width: "100%", height: 310 }}>
              <ResponsiveContainer width="100%" height="100%">
                {viewMode === "combined" ? (
                  <ComposedChart data={timeSeriesData} margin={{ top: 10, right: 20, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EAE6DA" vertical={false} />
                    <XAxis
                      dataKey="label"
                      tick={{ fill: "#5B5747", fontSize: 12, fontFamily: "Sarabun" }}
                      axisLine={{ stroke: "#D8D3C2" }}
                      tickLine={false}
                    />
                    <YAxis
                      yAxisId="left"
                      tick={{ fill: "#5B5747", fontSize: 11, fontFamily: "Sarabun" }}
                      axisLine={{ stroke: "#D8D3C2" }}
                      tickLine={false}
                      label={{ value: "จำนวน (หน่วย)", angle: -90, position: "insideLeft", fill: "#8A8874", fontSize: 11, offset: 15 }}
                    />
                    <YAxis
                      yAxisId="right"
                      orientation="right"
                      tick={{ fill: "#C08A2E", fontSize: 11, fontFamily: "Sarabun" }}
                      axisLine={{ stroke: "#EAE6DA" }}
                      tickLine={false}
                      tickFormatter={(v) => `฿${v >= 1000 ? `${(v / 1000).toFixed(0)}k` : v}`}
                      label={{ value: "มูลค่าสุทธิ (฿)", angle: 90, position: "insideRight", fill: "#C08A2E", fontSize: 11, offset: 15 }}
                    />
                    <Tooltip content={<CustomTooltip />} />
                    <Legend
                      verticalAlign="top"
                      align="right"
                      wrapperStyle={{ paddingBottom: 8, fontSize: 12, fontFamily: "Sarabun" }}
                    />
                    <Bar yAxisId="left" dataKey="inQty" name="รับเข้า (หน่วย)" fill="#3C5A45" radius={[4, 4, 0, 0]} maxBarSize={36} />
                    <Bar yAxisId="left" dataKey="outQty" name="เบิกออก (หน่วย)" fill="#A83B32" radius={[4, 4, 0, 0]} maxBarSize={36} />
                    <Line
                      yAxisId="right"
                      type="monotone"
                      dataKey="netValue"
                      name="มูลค่าสุทธิ (฿)"
                      stroke="#C08A2E"
                      strokeWidth={2.5}
                      dot={{ fill: "#C08A2E", r: 4 }}
                      activeDot={{ r: 6 }}
                    />
                  </ComposedChart>
                ) : viewMode === "qty" ? (
                  <BarChart data={timeSeriesData} margin={{ top: 10, right: 15, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EAE6DA" vertical={false} />
                    <XAxis
                      dataKey="label"
                      tick={{ fill: "#5B5747", fontSize: 12, fontFamily: "Sarabun" }}
                      axisLine={{ stroke: "#D8D3C2" }}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fill: "#5B5747", fontSize: 11, fontFamily: "Sarabun" }}
                      axisLine={{ stroke: "#D8D3C2" }}
                      tickLine={false}
                      label={{ value: "จำนวน (หน่วย)", angle: -90, position: "insideLeft", fill: "#8A8874", fontSize: 11, offset: 15 }}
                    />
                    <Tooltip content={<CustomTooltip showPrices />} />
                    <Legend
                      verticalAlign="top"
                      align="right"
                      wrapperStyle={{ paddingBottom: 8, fontSize: 12, fontFamily: "Sarabun" }}
                    />
                    <Bar dataKey="inQty" name="รับเข้า (หน่วย)" fill="#3C5A45" radius={[4, 4, 0, 0]} maxBarSize={42} />
                    <Bar dataKey="outQty" name="เบิกออก (หน่วย)" fill="#A83B32" radius={[4, 4, 0, 0]} maxBarSize={42} />
                  </BarChart>
                ) : (
                  <BarChart data={timeSeriesData} margin={{ top: 10, right: 15, left: 10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#EAE6DA" vertical={false} />
                    <XAxis
                      dataKey="label"
                      tick={{ fill: "#5B5747", fontSize: 12, fontFamily: "Sarabun" }}
                      axisLine={{ stroke: "#D8D3C2" }}
                      tickLine={false}
                    />
                    <YAxis
                      tick={{ fill: "#5B5747", fontSize: 11, fontFamily: "Sarabun" }}
                      axisLine={{ stroke: "#D8D3C2" }}
                      tickLine={false}
                      tickFormatter={(v) => `฿${v.toLocaleString()}`}
                    />
                    <Tooltip content={<CustomTooltip showPrices />} />
                    <Legend
                      verticalAlign="top"
                      align="right"
                      wrapperStyle={{ paddingBottom: 8, fontSize: 12, fontFamily: "Sarabun" }}
                    />
                    <Bar dataKey="inValue" name="มูลค่ารับเข้า (฿)" fill="#5B7A63" radius={[4, 4, 0, 0]} maxBarSize={42} />
                    <Bar dataKey="outValue" name="มูลค่าเบิกออก (฿)" fill="#C08A2E" radius={[4, 4, 0, 0]} maxBarSize={42} />
                  </BarChart>
                )}
              </ResponsiveContainer>
            </div>
          )}
        </div>
      </Panel>

      {/* Breakdown Insights Grid: Top Dispensed Herbs & Category Valuation */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(340px, 1fr))", gap: 16 }}>
        {/* Top Dispensed Herbs by Volume & Value */}
        <Panel id="panel-top-dispensed" accent="#A83B32" style={{ padding: "16px 18px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 7, fontWeight: 700, fontSize: 14.5, color: "#1F2D24" }}>
              <Award size={17} color="#A83B32" />
              <span>5 อันดับยาที่เบิกจ่ายสูงสุด (ตามช่วงเวลา)</span>
            </div>
            <span style={{ fontSize: 12, color: "#8A8874" }}>ปริมาณ & มูลค่า</span>
          </div>

          {topDispensed.length === 0 ? (
            <div style={{ fontSize: 13, color: "#8A8874", padding: "24px 0", textAlign: "center" }}>
              ไม่มีการเบิกจ่ายยาในช่วงเวลาที่เลือก
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
              {topDispensed.map((item, idx) => {
                const maxQty = topDispensed[0]?.qty || 1;
                const pct = Math.round((item.qty / maxQty) * 100);
                return (
                  <div
                    key={item.id}
                    id={`top-dispensed-${item.id}`}
                    style={{
                      background: "#FCFAF6",
                      border: "1px solid #EAE6DA",
                      borderRadius: 8,
                      padding: "8px 12px",
                    }}
                  >
                    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 5 }}>
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span
                          style={{
                            width: 18,
                            height: 18,
                            borderRadius: "50%",
                            background: idx === 0 ? "#A83B32" : idx === 1 ? "#C08A2E" : "#5B7A63",
                            color: "#fff",
                            fontSize: 10.5,
                            fontWeight: 700,
                            display: "inline-flex",
                            alignItems: "center",
                            justifyContent: "center",
                          }}
                        >
                          {idx + 1}
                        </span>
                        <span style={{ fontWeight: 600, fontSize: 13, color: "#1F2D24" }}>{item.name}</span>
                      </div>
                      <div style={{ textAlign: "right" }}>
                        <span style={{ fontWeight: 700, fontSize: 13, color: "#A83B32" }}>
                          {item.qty} {item.unit}
                        </span>
                        <span style={{ fontSize: 11.5, color: "#8A8874", marginLeft: 6 }}>
                          (฿{item.value.toLocaleString()})
                        </span>
                      </div>
                    </div>
                    {/* Progress Bar */}
                    <div style={{ width: "100%", height: 6, background: "#EAE6DA", borderRadius: 3, overflow: "hidden" }}>
                      <div
                        style={{
                          width: `${pct}%`,
                          height: "100%",
                          background: idx === 0 ? "#A83B32" : idx === 1 ? "#C08A2E" : "#5B7A63",
                          borderRadius: 3,
                          transition: "width 0.4s ease",
                        }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Panel>

        {/* Category Inventory Valuation (Donut / Pie Chart) */}
        <Panel id="panel-category-valuation" accent="#C08A2E" style={{ padding: "16px 18px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div style={{ display: "flex", alignItems: "center", gap: 7, fontWeight: 700, fontSize: 14.5, color: "#1F2D24" }}>
              <Package size={17} color="#C08A2E" />
              <span>สัดส่วนมูลค่าสต็อกตามหมวดหมู่</span>
            </div>
            <span style={{ fontSize: 12, fontWeight: 700, color: "#5B7A63" }}>
              รวม ฿{totalCatValuation.toLocaleString(undefined, { maximumFractionDigits: 0 })}
            </span>
          </div>

          {categoryValuation.length === 0 ? (
            <div style={{ fontSize: 13, color: "#8A8874", padding: "24px 0", textAlign: "center" }}>
              ไม่มีข้อมูลสต็อกคงคลังในหมวดหมู่
            </div>
          ) : (
            <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
              {/* Donut Chart */}
              <div style={{ width: 140, height: 140, position: "relative", flexShrink: 0 }}>
                <ResponsiveContainer width="100%" height="100%">
                  <PieChart>
                    <Pie
                      data={categoryValuation}
                      dataKey="value"
                      nameKey="name"
                      innerRadius={36}
                      outerRadius={62}
                      paddingAngle={3}
                    >
                      {categoryValuation.map((entry, index) => {
                        const col = CATEGORY_COLORS[entry.name] || DEFAULT_PALETTE[index % DEFAULT_PALETTE.length];
                        return <Cell key={`cell-${index}`} fill={col} />;
                      })}
                    </Pie>
                    <Tooltip
                      formatter={(val: number | string | undefined) => [
                        `฿${Number(val || 0).toLocaleString()}`,
                        "มูลค่าสต็อก",
                      ]}
                      contentStyle={{
                        background: "#1F2D24",
                        color: "#fff",
                        borderRadius: 6,
                        border: "none",
                        fontSize: 12,
                        fontFamily: "Sarabun",
                      }}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </div>

              {/* Category Breakdown List */}
              <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 6, minWidth: 160 }}>
                {categoryValuation.map((cat, idx) => {
                  const col = CATEGORY_COLORS[cat.name] || DEFAULT_PALETTE[idx % DEFAULT_PALETTE.length];
                  const share = totalCatValuation > 0 ? ((cat.value / totalCatValuation) * 100).toFixed(1) : "0";
                  return (
                    <div
                      key={cat.name}
                      style={{
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "space-between",
                        fontSize: 12,
                        padding: "3px 0",
                        borderBottom: "1px dashed #EAE6DA",
                      }}
                    >
                      <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
                        <span style={{ width: 9, height: 9, borderRadius: "50%", background: col, display: "inline-block" }} />
                        <span style={{ fontWeight: 600, color: "#1F2D24" }}>{cat.name}</span>
                        <span style={{ color: "#8A8874", fontSize: 11 }}>({cat.totalUnits} หน่วย)</span>
                      </div>
                      <div style={{ fontWeight: 700, color: "#3C5A45" }}>
                        ฿{cat.value.toLocaleString()}{" "}
                        <span style={{ color: "#8A8874", fontSize: 11, fontWeight: 500 }}>({share}%)</span>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}
        </Panel>
      </div>

      {/* High-Resolution PNG Image Export Modal */}
      <ChartImageExportModal
        isOpen={showImageExportModal}
        onClose={() => setShowImageExportModal(false)}
        inv={inv}
        tx={tx}
        initialTimeRange={timeRange}
        initialItemId={selectedItemId}
      />
    </div>
  );
}

// Custom Tooltip component for Thai-styled metrics
interface TooltipPayloadItem {
  dataKey: string;
  name: string;
  value: number;
  color: string;
  payload: {
    label: string;
    inQty: number;
    outQty: number;
    inValue: number;
    outValue: number;
    netValue: number;
  };
}

interface CustomTooltipProps {
  active?: boolean;
  payload?: TooltipPayloadItem[];
  label?: string;
  showPrices?: boolean;
}

function CustomTooltip({ active, payload }: CustomTooltipProps) {
  if (!active || !payload || !payload.length) return null;

  const data = payload[0]?.payload;
  if (!data) return null;

  return (
    <div
      style={{
        background: "#1F2D24",
        color: "#EFEDE3",
        padding: "10px 14px",
        borderRadius: 8,
        fontSize: 12,
        fontFamily: "Sarabun, sans-serif",
        boxShadow: "0 4px 16px rgba(0,0,0,0.2)",
        border: "1px solid #3C5A45",
        minWidth: 170,
      }}
    >
      <div style={{ fontWeight: 700, fontSize: 13, borderBottom: "1px solid #3A4E3F", paddingBottom: 4, marginBottom: 6, color: "#9CB68C" }}>
        ช่วงเวลา: {data.label}
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 3 }}>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
          <span style={{ color: "#9CB68C" }}>📥 รับเข้า:</span>
          <b>{data.inQty.toLocaleString()} หน่วย (฿{data.inValue.toLocaleString()})</b>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12 }}>
          <span style={{ color: "#E4B7B0" }}>📤 เบิกออก:</span>
          <b>{data.outQty.toLocaleString()} หน่วย (฿{data.outValue.toLocaleString()})</b>
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", gap: 12, borderTop: "1px dashed #3A4E3F", paddingTop: 4, marginTop: 2 }}>
          <span style={{ color: "#F0D78C" }}>💰 มูลค่าสุทธิ:</span>
          <b style={{ color: data.netValue >= 0 ? "#9CB68C" : "#E4B7B0" }}>
            {data.netValue >= 0 ? `+฿${data.netValue.toLocaleString()}` : `-฿${Math.abs(data.netValue).toLocaleString()}`}
          </b>
        </div>
      </div>
    </div>
  );
}
