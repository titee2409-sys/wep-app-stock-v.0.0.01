import React, { useState, useMemo, useRef } from "react";
import { Printer, Download, CloudUpload, Upload, Search, Trash2, RotateCcw, Image as ImageIcon, Eye } from "lucide-react";
import type { InventoryState, StockTransaction } from "../types";
import { Panel, Btn, inputStyle } from "./Panel";
import { today, fmtDate, lotQtyForItem } from "../utils/storage";
import { ChartImageExportModal } from "./ChartImageExportModal";

export function HistoryView({
  inv,
  tx,
  persistInv,
  persistTx,
  showToast,
  onClearSampleData,
  onLoadSampleData,
  onOpenLotLifecycle,
}: {
  inv: InventoryState;
  tx: StockTransaction[];
  persistInv: (next: InventoryState) => Promise<void>;
  persistTx: (next: StockTransaction[]) => Promise<void>;
  showToast: (msg: string) => void;
  onClearSampleData?: () => Promise<void>;
  onLoadSampleData?: () => Promise<void>;
  onOpenLotLifecycle?: (lotId: string) => void;
}) {
  const [type, setType] = useState("all");
  const [q, setQ] = useState("");
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [showChartModal, setShowChartModal] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const rows = useMemo(() => {
    return [...tx]
      .map((t) => ({
        ...t,
        item: inv.items.find((i) => i.id === t.itemId),
        lot: inv.lots.find((l) => l.id === t.lotId),
      }))
      .filter((t) => (type === "all" ? true : t.type === type))
      .filter((t) => (q ? (t.item?.name || "").toLowerCase().includes(q.toLowerCase()) : true))
      .filter((t) => (from ? t.date >= from : true))
      .filter((t) => (to ? t.date <= to : true))
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }, [tx, inv, type, q, from, to]);

  async function exportExcel() {
    try {
      const XLSX = await import("xlsx");
      const stockSheet = inv.items.map((it) => {
        const qty = lotQtyForItem(inv.lots, it.id);
        return {
          "ชื่อยา": it.name,
          "ประเภท": it.category,
          "หน่วย": it.unit,
          "คงเหลือ": qty,
          "สต็อกขั้นต่ำ": it.minStock,
          "ราคาต่อหน่วย (บาท)": Number(it.price || 0),
          "มูลค่ารวม (บาท)": Number(((it.price || 0) * qty).toFixed(2)),
          "สถานะ": qty < it.minStock ? "ต่ำกว่าเกณฑ์" : "ปกติ",
        };
      });

      const totalVal = stockSheet.reduce((s, r) => s + (Number(r["มูลค่ารวม (บาท)"]) || 0), 0);
      stockSheet.push({
        "ชื่อยา": "รวมมูลค่าทั้งหมด",
        "ประเภท": "",
        "หน่วย": "",
        "คงเหลือ": 0,
        "สต็อกขั้นต่ำ": 0,
        "ราคาต่อหน่วย (บาท)": 0,
        "มูลค่ารวม (บาท)": Number(totalVal.toFixed(2)),
        "สถานะ": "",
      });

      const lotSheet = inv.lots
        .filter((l) => l.qty > 0)
        .map((l) => {
          const it = inv.items.find((i) => i.id === l.itemId);
          return {
            "ชื่อยา": it?.name || "-",
            "เลขที่ล็อต": l.lotNo || "-",
            "คงเหลือ": l.qty,
            "หน่วยนับ": it?.unit || "-",
            "วันหมดอายุ": l.expiryDate,
            "วันที่รับเข้า": l.receivedDate,
          };
        });

      const historySheet = rows.map((t) => {
        const unitPrice = Number(t.item?.price) || 0;
        return {
          "วันที่": t.date,
          "ประเภท": t.type === "in" ? "รับเข้า" : "เบิกออก",
          "ชื่อยา": t.item?.name || "-",
          "เลขที่ล็อต": t.lot?.lotNo || "-",
          "จำนวน": t.qty,
          "หน่วยนับ": t.item?.unit || "-",
          "ราคาต่อหน่วย (บาท)": unitPrice,
          "มูลค่า (บาท)": Number((unitPrice * t.qty).toFixed(2)),
          "ผู้บันทึก": t.user,
          "หมายเหตุ": t.note || "",
        };
      });

      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(stockSheet), "สต็อกปัจจุบัน");
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(lotSheet), "รายละเอียดล็อต");
      XLSX.utils.book_append_sheet(wb, XLSX.utils.json_to_sheet(historySheet), "ประวัติการเคลื่อนไหว");
      XLSX.writeFile(wb, `รายงานคลังยาสมุนไพร_${today()}.xlsx`);
      showToast("ส่งออกไฟล์ Excel สำเร็จ");
    } catch (e) {
      console.error("export excel error", e);
      showToast("ส่งออกไฟล์ Excel ไม่สำเร็จ");
    }
  }

  function printReport() {
    window.print();
  }

  function backupJson() {
    const payload = { exportedAt: new Date().toISOString(), inventory: inv, transactions: tx };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `สำรองข้อมูลคลังยาสมุนไพร_${today()}.json`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
    showToast("ดาวน์โหลดไฟล์สำรองเรียบร้อยแล้ว");
  }

  function restoreJson(e: React.ChangeEvent<HTMLInputElement>) {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = async () => {
      try {
        const text = reader.result as string;
        const data = JSON.parse(text);
        if (!data.inventory || !data.transactions) throw new Error("invalid file format");
        const ok = window.confirm("การกู้คืนจะเขียนทับข้อมูลปัจจุบันทั้งหมดด้วยข้อมูลในไฟล์สำรอง ต้องการดำเนินการต่อหรือไม่?");
        if (!ok) return;
        await persistInv(data.inventory);
        await persistTx(data.transactions);
        showToast("กู้คืนข้อมูลจากไฟล์สำรองสำเร็จแล้ว");
      } catch (err) {
        console.error("restore error", err);
        showToast("ไฟล์สำรองไม่ถูกต้อง ไม่สามารถกู้คืนข้อมูลได้");
      }
    };
    reader.readAsText(file);
    e.target.value = "";
  }

  return (
    <div>
      <div className="no-print" style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12, marginBottom: 16 }}>
        <div>
          <h1 style={{ fontFamily: "'Noto Serif Thai', serif", fontSize: 24, margin: "2px 0 4px", fontWeight: 700 }}>
            ประวัติการเคลื่อนไหว & รายงาน
          </h1>
          <div style={{ color: "#8A8874", fontSize: 13 }}>
            พบประวัติ {rows.length} รายการ (จากทั้งหมด {tx.length} รายการ)
          </div>
        </div>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <Btn id="btn-history-export-chart-png" variant="subtle" onClick={() => setShowChartModal(true)}>
            <ImageIcon size={14} /> ส่งออกกราฟ (PNG)
          </Btn>
          <Btn id="btn-print-report" variant="ghost" onClick={printReport}>
            <Printer size={14} /> พิมพ์ / ส่งออก PDF
          </Btn>
          <Btn id="btn-export-excel" onClick={exportExcel}>
            <Download size={14} /> ส่งออก Excel (.xlsx)
          </Btn>
        </div>
      </div>

      <Panel accent="#8FA888" className="no-print" style={{ marginBottom: 16 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", flexWrap: "wrap", gap: 12 }}>
          <div>
            <div style={{ fontWeight: 700, fontSize: 14.5, display: "flex", alignItems: "center", gap: 6, color: "#1F2D24" }}>
              <CloudUpload size={17} color="#3C5A45" /> สำรอง & กู้คืนข้อมูลระบบ
            </div>
            <div style={{ fontSize: 12.5, color: "#5B5747", marginTop: 3 }}>
              ดาวน์โหลดไฟล์สำรองข้อมูล (.json) เก็บไว้ภายนอก หรือนำเข้าเพื่อกู้คืนข้อมูลสต็อกและประวัติการเคลื่อนไหว
            </div>
          </div>
          <div style={{ display: "flex", gap: 8, flexShrink: 0, flexWrap: "wrap" }}>
            <Btn id="btn-backup-json" variant="subtle" onClick={backupJson}>
              <Download size={14} /> ดาวน์โหลดไฟล์สำรอง
            </Btn>
            <Btn id="btn-restore-json" variant="ghost" onClick={() => fileInputRef.current?.click()}>
              <Upload size={14} /> กู้คืนจากไฟล์
            </Btn>
            {onLoadSampleData && (
              <Btn
                id="btn-load-sample-data"
                variant="ghost"
                onClick={onLoadSampleData}
                style={{ borderColor: "#D5DFD7", color: "#3C5A45" }}
              >
                <RotateCcw size={14} /> โหลดข้อมูลตัวอย่าง
              </Btn>
            )}
            {onClearSampleData && (
              <button
                id="btn-clear-sample-data"
                onClick={onClearSampleData}
                style={{
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  padding: "7px 12px",
                  borderRadius: 6,
                  border: "1px solid #F1C3BF",
                  background: "#FFF5F4",
                  color: "#A83B32",
                  fontSize: 13,
                  fontWeight: 600,
                  cursor: "pointer",
                  fontFamily: "Sarabun, sans-serif",
                  transition: "all 0.15s ease",
                }}
                title="ล้างข้อมูลตัวอย่างทั้งหมดและเริ่มใช้งานคลังยาเปล่า"
              >
                <Trash2 size={14} color="#A83B32" />
                <span>ล้างข้อมูลทั้งหมด / ตัวอย่าง</span>
              </button>
            )}
            <input ref={fileInputRef} type="file" accept="application/json" onChange={restoreJson} style={{ display: "none" }} />
          </div>
        </div>
      </Panel>

      <style>{`
        @media print {
          .no-print { display: none !important; }
          .print-only { display: block !important; }
          body { background: #fff; }
        }
        .print-only { display: none; }
      `}</style>

      {/* Printable Report Header */}
      <div className="print-only" style={{ marginBottom: 18 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, marginBottom: 2 }}>
          <div style={{ fontFamily: "'Noto Serif Thai', serif", fontWeight: 700, fontSize: 20 }}>
            รายงานสรุปคลังยาสมุนไพร
          </div>
        </div>
        <div style={{ fontSize: 12, color: "#5B5747", marginBottom: 14 }}>
          พิมพ์รายงานเมื่อ: {new Date().toLocaleDateString("th-TH", { day: "2-digit", month: "long", year: "numeric", hour: "2-digit", minute: "2-digit" })} น.
        </div>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 6 }}>1. สรุปสต็อกคงคลังปัจจุบัน</div>
        <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 11.5, marginBottom: 18 }}>
          <thead>
            <tr style={{ background: "#EEF1E8", textAlign: "left" }}>
              {["ชื่อยา", "ประเภท", "คงเหลือ", "ขั้นต่ำ", "ราคา/หน่วย", "มูลค่ารวม", "สถานะ"].map((h) => (
                <th key={h} style={{ padding: "6px 8px", border: "1px solid #D8D3C2", fontWeight: 700 }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {inv.items.map((it) => {
              const qty = lotQtyForItem(inv.lots, it.id);
              const low = qty < it.minStock;
              const val = qty * (Number(it.price) || 0);
              return (
                <tr key={it.id}>
                  <td style={{ padding: "5px 8px", border: "1px solid #E4E0D2" }}>{it.name}</td>
                  <td style={{ padding: "5px 8px", border: "1px solid #E4E0D2" }}>{it.category}</td>
                  <td style={{ padding: "5px 8px", border: "1px solid #E4E0D2" }}>{qty} {it.unit}</td>
                  <td style={{ padding: "5px 8px", border: "1px solid #E4E0D2" }}>{it.minStock} {it.unit}</td>
                  <td style={{ padding: "5px 8px", border: "1px solid #E4E0D2" }}>฿{Number(it.price || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                  <td style={{ padding: "5px 8px", border: "1px solid #E4E0D2" }}>฿{val.toLocaleString(undefined, { minimumFractionDigits: 2 })}</td>
                  <td style={{ padding: "5px 8px", border: "1px solid #E4E0D2", color: low ? "#A83B32" : "#3C5A45", fontWeight: 700 }}>
                    {low ? "ต่ำกว่าเกณฑ์" : "ปกติ"}
                  </td>
                </tr>
              );
            })}
            <tr style={{ background: "#F6F3EA" }}>
              <td colSpan={5} style={{ padding: "6px 8px", border: "1px solid #D8D3C2", textAlign: "right", fontWeight: 700 }}>
                มูลค่าสต็อกคงคลังรวมทั้งหมด
              </td>
              <td colSpan={2} style={{ padding: "6px 8px", border: "1px solid #D8D3C2", fontWeight: 700, color: "#3C5A45" }}>
                ฿{inv.items.reduce((s, it) => s + lotQtyForItem(inv.lots, it.id) * (Number(it.price) || 0), 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
              </td>
            </tr>
          </tbody>
        </table>
        <div style={{ fontWeight: 700, fontSize: 14, marginBottom: 6 }}>
          2. ประวัติการเคลื่อนไหวรับเข้า-เบิกออก {(type !== "all" || q || from || to) ? "(ตามตัวกรอง)" : ""}
        </div>
      </div>

      {/* Filter Controls (Web View) */}
      <div className="no-print" style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }}>
        <select
          id="filter-history-type"
          style={{ ...inputStyle, width: "auto", flex: "0 0 140px", background: "#fff" }}
          value={type}
          onChange={(e) => setType(e.target.value)}
        >
          <option value="all">ทุกประเภท</option>
          <option value="in">รับเข้า</option>
          <option value="out">เบิกออก</option>
        </select>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#fff", border: "1px solid #D8D3C2", borderRadius: 8, padding: "8px 12px", minWidth: 200, flex: "1 1 200px" }}>
          <Search size={15} color="#8A8874" />
          <input
            id="filter-history-q"
            placeholder="ค้นหาชื่อยา..."
            value={q}
            onChange={(e) => setQ(e.target.value)}
            style={{ border: "none", outline: "none", fontSize: 13, flex: 1, fontFamily: "Sarabun, sans-serif", background: "transparent" }}
          />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, flex: "0 0 auto" }}>
          <span style={{ fontSize: 13, color: "#8A8874" }}>ตั้งแต่:</span>
          <input
            id="filter-history-from"
            type="date"
            style={{ ...inputStyle, width: "auto", background: "#fff" }}
            value={from}
            onChange={(e) => setFrom(e.target.value)}
          />
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: 6, flex: "0 0 auto" }}>
          <span style={{ fontSize: 13, color: "#8A8874" }}>ถึง:</span>
          <input
            id="filter-history-to"
            type="date"
            style={{ ...inputStyle, width: "auto", background: "#fff" }}
            value={to}
            onChange={(e) => setTo(e.target.value)}
          />
        </div>
      </div>

      <Panel id="panel-history-table" accent="#3C5A45" style={{ padding: 0, overflow: "hidden" }}>
        <div style={{ overflowX: "auto" }}>
          <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
            <thead>
              <tr style={{ background: "#EEF1E8", textAlign: "left" }}>
                {["วันที่", "ประเภท", "ชื่อยา", "ล็อต", "จำนวน", "ราคา/หน่วย", "มูลค่า", "ผู้บันทึก", "หมายเหตุ"].map((h) => (
                  <th key={h} style={{ padding: "10px 12px", fontWeight: 700, color: "#3C5A45", whiteSpace: "nowrap" }}>
                    {h}
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {rows.length === 0 && (
                <tr>
                  <td colSpan={9} style={{ padding: 28, textAlign: "center", color: "#8A8874" }}>
                    ไม่พบข้อมูลการเคลื่อนไหวตามเงื่อนไขที่เลือก
                  </td>
                </tr>
              )}
              {rows.map((t) => {
                const unitPrice = Number(t.item?.price) || 0;
                const value = unitPrice * t.qty;
                return (
                  <tr key={t.id} style={{ borderTop: "1px solid #F0EEE3" }}>
                    <td style={{ padding: "9px 12px", whiteSpace: "nowrap" }}>{fmtDate(t.date)}</td>
                    <td style={{ padding: "9px 12px", whiteSpace: "nowrap" }}>
                      <span
                        style={{
                          padding: "2px 7px",
                          borderRadius: 4,
                          fontSize: 12,
                          fontWeight: 700,
                          background: t.type === "in" ? "#EEF1E8" : "#FBEDEB",
                          color: t.type === "in" ? "#3C5A45" : "#A83B32",
                        }}
                      >
                        {t.type === "in" ? "รับเข้า" : "เบิกออก"}
                      </span>
                    </td>
                    <td style={{ padding: "9px 12px", fontWeight: 600 }}>{t.item?.name || "-"}</td>
                    <td style={{ padding: "9px 12px", whiteSpace: "nowrap" }}>
                      {t.lot?.lotNo || t.lotId ? (
                        <button
                          onClick={() => onOpenLotLifecycle?.(t.lotId || t.lot?.id || "")}
                          style={{
                            background: "#EEF3EF",
                            border: "1px solid #C8D8CB",
                            borderRadius: 4,
                            padding: "2px 7px",
                            cursor: "pointer",
                            color: "#2D4834",
                            fontSize: 11.5,
                            fontWeight: 600,
                            fontFamily: "Sarabun, sans-serif",
                            display: "inline-flex",
                            alignItems: "center",
                            gap: 4,
                          }}
                          title="คลิกเพื่อดูวงจรชีวิตล็อตยานี้ตั้งแต่รับเข้าจนหมดสต็อก"
                        >
                          <span>ล็อต {t.lot?.lotNo || "ดูข้อมูล"}</span>
                          <Eye size={11} color="#3C5A45" />
                        </button>
                      ) : (
                        <span style={{ color: "#8A8874" }}>-</span>
                      )}
                    </td>
                    <td style={{ padding: "9px 12px", whiteSpace: "nowrap" }}>
                      <b>{t.qty}</b> <span style={{ fontSize: 12, color: "#8A8874" }}>{t.item?.unit}</span>
                    </td>
                    <td style={{ padding: "9px 12px", whiteSpace: "nowrap" }}>
                      ฿{unitPrice.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td style={{ padding: "9px 12px", fontWeight: 700, color: "#5B7A63", whiteSpace: "nowrap" }}>
                      ฿{value.toLocaleString(undefined, { minimumFractionDigits: 2 })}
                    </td>
                    <td style={{ padding: "9px 12px", color: "#5B5747", whiteSpace: "nowrap" }}>{t.user}</td>
                    <td style={{ padding: "9px 12px", color: "#8A8874" }}>{t.note || "-"}</td>
                  </tr>
                );
              })}
            </tbody>
            {rows.length > 0 && (
              <tfoot>
                <tr style={{ borderTop: "2px solid #D8D3C2", background: "#FBFAF6" }}>
                  <td colSpan={6} style={{ padding: "10px 12px", textAlign: "right", fontWeight: 700 }}>
                    มูลค่ารวมของรายการที่แสดง:
                  </td>
                  <td colSpan={3} style={{ padding: "10px 12px", fontWeight: 700, color: "#5B7A63", fontSize: 14 }}>
                    ฿{rows.reduce((s, t) => s + (Number(t.item?.price) || 0) * t.qty, 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </td>
                </tr>
              </tfoot>
            )}
          </table>
        </div>
      </Panel>

      <div style={{ fontSize: 12, color: "#8A8874", marginTop: 10 }}>
        * มูลค่าคำนวณจากราคาต่อหน่วยปัจจุบันของยาแต่ละรายการ
      </div>

      {/* Historical Transactions Visualisation PNG Export Modal */}
      <ChartImageExportModal
        isOpen={showChartModal}
        onClose={() => setShowChartModal(false)}
        inv={inv}
        tx={tx}
        showToast={showToast}
      />
    </div>
  );
}
