import React, { useState, useMemo } from "react";
import { Plus, Search, X, Pencil, Trash2, Check, RotateCcw, Package, Sliders, CheckSquare, Layers, AlertCircle, Eye, History } from "lucide-react";
import type { HerbalItem, InventoryState, StockTransaction } from "../types";
import { Panel, Btn, Field, inputStyle } from "./Panel";
import { uid, lotQtyForItem, daysUntil, fmtDate, CATEGORIES } from "../utils/storage";

export function ItemsView({
  inv,
  tx,
  persistInv,
  showToast,
  onLoadSampleData,
  onOpenLotLifecycle,
  onNavigateToMove,
}: {
  inv: InventoryState;
  tx?: StockTransaction[];
  persistInv: (next: InventoryState) => Promise<void>;
  showToast: (msg: string) => void;
  onLoadSampleData?: () => Promise<void>;
  onOpenLotLifecycle?: (lotId: string) => void;
  onNavigateToMove?: (itemId: string, lotId?: string) => void;
}) {
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  const [q, setQ] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [expandedDepletedItemIds, setExpandedDepletedItemIds] = useState<string[]>([]);

  // Bulk update states
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [showBulkModal, setShowBulkModal] = useState(false);
  const [bulkUpdateCategory, setBulkUpdateCategory] = useState(false);
  const [bulkCategory, setBulkCategory] = useState<string>(CATEGORIES[0]);
  const [bulkUpdateMinStock, setBulkUpdateMinStock] = useState(true);
  const [bulkMinStock, setBulkMinStock] = useState<number | string>(15);
  const [isSavingBulk, setIsSavingBulk] = useState(false);
  const [form, setForm] = useState<{
    name: string;
    category: string;
    unit: string;
    minStock: number | string;
    price: number | string;
    supplier?: string;
    reorderQty?: number | string;
    leadTimeDays?: number | string;
    orderNotes?: string;
  }>({
    name: "",
    category: CATEGORIES[0],
    unit: "",
    minStock: 10,
    price: 0,
    supplier: "",
    reorderQty: 20,
    leadTimeDays: 3,
    orderNotes: "",
  });

  const filtered = useMemo(() => {
    return inv.items.filter((i) => {
      const matchQ =
        i.name.toLowerCase().includes(q.toLowerCase()) ||
        i.category.toLowerCase().includes(q.toLowerCase()) ||
        (i.supplier && i.supplier.toLowerCase().includes(q.toLowerCase()));
      const matchCat = selectedCategory === "all" || i.category === selectedCategory;
      return matchQ && matchCat;
    });
  }, [inv.items, q, selectedCategory]);

  function openNew() {
    setEditing(null);
    setForm({
      name: "",
      category: CATEGORIES[0],
      unit: "",
      minStock: 10,
      price: 0,
      supplier: "",
      reorderQty: 20,
      leadTimeDays: 3,
      orderNotes: "",
    });
    setShowForm(true);
  }

  function openEdit(it: HerbalItem) {
    setEditing(it.id);
    setForm({
      name: it.name,
      category: it.category,
      unit: it.unit,
      minStock: it.minStock,
      price: it.price || 0,
      supplier: it.supplier || "",
      reorderQty: it.reorderQty || 20,
      leadTimeDays: it.leadTimeDays || 3,
      orderNotes: it.orderNotes || "",
    });
    setShowForm(true);
  }

  async function submit() {
    if (!form.name.trim() || !form.unit.trim()) {
      showToast("กรุณาระบุชื่อยาและหน่วยนับ");
      return;
    }
    let items: HerbalItem[];
    if (editing) {
      items = inv.items.map((i) =>
        i.id === editing
          ? {
              ...i,
              name: form.name.trim(),
              category: form.category,
              unit: form.unit.trim(),
              minStock: Math.max(0, Number(form.minStock) || 0),
              price: Math.max(0, Number(form.price) || 0),
              supplier: form.supplier?.trim(),
              reorderQty: Math.max(0, Number(form.reorderQty) || 0),
              leadTimeDays: Math.max(0, Number(form.leadTimeDays) || 0),
              orderNotes: form.orderNotes?.trim(),
            }
          : i
      );
    } else {
      const newItem: HerbalItem = {
        id: uid(),
        name: form.name.trim(),
        category: form.category,
        unit: form.unit.trim(),
        minStock: Math.max(0, Number(form.minStock) || 0),
        price: Math.max(0, Number(form.price) || 0),
        supplier: form.supplier?.trim(),
        reorderQty: Math.max(0, Number(form.reorderQty) || 0),
        leadTimeDays: Math.max(0, Number(form.leadTimeDays) || 0),
        orderNotes: form.orderNotes?.trim(),
      };
      items = [...inv.items, newItem];
    }
    await persistInv({ ...inv, items });
    setShowForm(false);
    showToast(editing ? "บันทึกแก้ไขรายการยาแล้ว" : "เพิ่มรายการยาใหม่สำเร็จ");
  }

  async function removeItem(id: string) {
    const hasLots = inv.lots.some((l) => l.itemId === id && l.qty > 0);
    if (hasLots) {
      showToast("ไม่สามารถลบได้ เนื่องจากยังมียอดคงเหลือในสต็อก");
      return;
    }
    if (!window.confirm("ยืนยันการลบรายการยานี้?")) return;
    await persistInv({
      ...inv,
      items: inv.items.filter((i) => i.id !== id),
      lots: inv.lots.filter((l) => l.itemId !== id),
    });
    setSelectedIds((prev) => prev.filter((itemId) => itemId !== id));
    showToast("ลบรายการยาเรียบร้อย");
  }

  // Bulk Selection Handlers
  const isAllFilteredSelected = filtered.length > 0 && filtered.every((it) => selectedIds.includes(it.id));

  function handleToggleSelectAll() {
    if (isAllFilteredSelected) {
      const filteredIdSet = new Set(filtered.map((it) => it.id));
      setSelectedIds((prev) => prev.filter((id) => !filteredIdSet.has(id)));
    } else {
      const nextSet = new Set(selectedIds);
      filtered.forEach((it) => nextSet.add(it.id));
      setSelectedIds(Array.from(nextSet));
    }
  }

  function handleToggleItem(id: string) {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((itemId) => itemId !== id) : [...prev, id]
    );
  }

  function handleClearSelection() {
    setSelectedIds([]);
  }

  function openBulkModal() {
    if (selectedIds.length === 0) {
      showToast("กรุณาเลือกรายการยาอย่างน้อย 1 รายการเพื่ออัปเดตพร้อมกัน");
      return;
    }
    setBulkUpdateCategory(false);
    setBulkCategory(CATEGORIES[0]);
    setBulkUpdateMinStock(true);
    setBulkMinStock(15);
    setShowBulkModal(true);
  }

  async function handleApplyBulkUpdate() {
    if (!bulkUpdateCategory && !bulkUpdateMinStock) {
      showToast("กรุณาเลือกข้อมูลที่ต้องการอัปเดตอย่างน้อย 1 รายการ (หมวดหมู่ หรือ เกณฑ์สต็อกขั้นต่ำ)");
      return;
    }

    const numMinStock = Number(bulkMinStock);
    if (bulkUpdateMinStock && (isNaN(numMinStock) || numMinStock < 0)) {
      showToast("กรุณาระบุเกณฑ์สต็อกขั้นต่ำเป็นตัวเลขที่ถูกต้อง (ตั้งแต่ 0 ขึ้นไป)");
      return;
    }

    setIsSavingBulk(true);
    try {
      const count = selectedIds.length;
      const selectedSet = new Set(selectedIds);

      const nextItems = inv.items.map((item) => {
        if (!selectedSet.has(item.id)) return item;
        return {
          ...item,
          category: bulkUpdateCategory ? bulkCategory : item.category,
          minStock: bulkUpdateMinStock ? numMinStock : item.minStock,
        };
      });

      await persistInv({
        ...inv,
        items: nextItems,
      });

      const details = [];
      if (bulkUpdateCategory) details.push(`หมวดหมู่: "${bulkCategory}"`);
      if (bulkUpdateMinStock) details.push(`สต็อกขั้นต่ำ: ${numMinStock}`);

      showToast(`อัปเดตข้อมูลยา ${count} รายการพร้อมกันสำเร็จ (${details.join(", ")})`);
      setSelectedIds([]);
      setShowBulkModal(false);
    } catch (err) {
      console.error("Bulk update failed", err);
      showToast("เกิดข้อผิดพลาดในการอัปเดตข้อมูลพร้อมกัน");
    } finally {
      setIsSavingBulk(false);
    }
  }

  return (
    <div>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 12, marginBottom: 16 }}>
        <div>
          <h1 style={{ fontFamily: "'Noto Serif Thai', serif", fontSize: 24, margin: "2px 0 4px", fontWeight: 700 }}>
            รายการยาสมุนไพร
          </h1>
          <div style={{ color: "#8A8874", fontSize: 13 }}>ทั้งหมด {inv.items.length} รายการ</div>
        </div>
        <Btn id="btn-add-item" onClick={openNew}>
          <Plus size={15} /> เพิ่มรายการยาใหม่
        </Btn>
      </div>

      <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginBottom: 14 }}>
        <div style={{ display: "flex", alignItems: "center", gap: 8, background: "#fff", border: "1px solid #D8D3C2", borderRadius: 8, padding: "8px 12px", minWidth: 260, flex: "1 1 260px" }}>
          <Search size={15} color="#8A8874" />
          <input
            id="search-items-input"
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="ค้นหาชื่อยา หรือหมวดหมู่..."
            style={{ border: "none", outline: "none", fontSize: 13, flex: 1, fontFamily: "Sarabun, sans-serif", background: "transparent" }}
          />
          {q && (
            <button onClick={() => setQ("")} style={{ border: "none", background: "transparent", cursor: "pointer", padding: 0 }}>
              <X size={14} color="#8A8874" />
            </button>
          )}
        </div>
        <select
          id="select-category-filter"
          style={{ ...inputStyle, width: "auto", flex: "0 0 160px", background: "#fff" }}
          value={selectedCategory}
          onChange={(e) => setSelectedCategory(e.target.value)}
        >
          <option value="all">ทุกหมวดหมู่</option>
          {CATEGORIES.map((c) => (
            <option key={c} value={c}>{c}</option>
          ))}
        </select>
      </div>

      {/* Bulk Selection and Action Toolbar */}
      {inv.items.length > 0 && (
        <div
          id="bulk-selection-toolbar"
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            flexWrap: "wrap",
            gap: 10,
            padding: "9px 14px",
            background: selectedIds.length > 0 ? "#EEF3EF" : "#FFFFFF",
            border: selectedIds.length > 0 ? "1.5px solid #3C5A45" : "1px solid #D8D3C2",
            borderRadius: 8,
            marginBottom: 14,
            boxShadow: selectedIds.length > 0 ? "0 2px 8px rgba(60, 90, 69, 0.12)" : "none",
            transition: "all 0.15s ease",
          }}
        >
          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <label
              htmlFor="checkbox-select-all"
              style={{
                display: "inline-flex",
                alignItems: "center",
                gap: 7,
                cursor: "pointer",
                fontSize: 13,
                fontWeight: 600,
                color: "#1F2D24",
                userSelect: "none",
              }}
            >
              <input
                id="checkbox-select-all"
                type="checkbox"
                checked={isAllFilteredSelected}
                onChange={handleToggleSelectAll}
                style={{
                  width: 17,
                  height: 17,
                  cursor: "pointer",
                  accentColor: "#3C5A45",
                }}
              />
              <span>
                {isAllFilteredSelected ? "ยกเลิกเลือกทั้งหมด" : "เลือกทั้งหมด"}
                {filtered.length > 0 ? ` (${filtered.length} รายการ)` : ""}
              </span>
            </label>

            {selectedIds.length > 0 && (
              <span
                id="badge-selected-count"
                style={{
                  background: "#3C5A45",
                  color: "#FFFFFF",
                  fontSize: 12,
                  fontWeight: 700,
                  padding: "2px 9px",
                  borderRadius: 12,
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <CheckSquare size={12} />
                <span>เลือกอยู่ {selectedIds.length} รายการ</span>
              </span>
            )}
          </div>

          <div style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
            {selectedIds.length > 0 ? (
              <>
                <button
                  id="btn-open-bulk-modal"
                  onClick={openBulkModal}
                  style={{
                    background: "#3C5A45",
                    color: "#FFFFFF",
                    border: "none",
                    borderRadius: 6,
                    padding: "7px 14px",
                    fontSize: 13,
                    fontWeight: 700,
                    cursor: "pointer",
                    display: "inline-flex",
                    alignItems: "center",
                    gap: 6,
                    boxShadow: "0 2px 6px rgba(60, 90, 69, 0.25)",
                    fontFamily: "Sarabun, sans-serif",
                    transition: "all 0.15s ease",
                  }}
                  title="แก้ไขสต็อกขั้นต่ำหรือหมวดหมู่พร้อมกันสำหรับยาที่เลือก"
                >
                  <Sliders size={14} />
                  <span>แก้ไขข้อมูลพร้อมกัน ({selectedIds.length} รายการ)</span>
                </button>

                <button
                  id="btn-clear-selection"
                  onClick={handleClearSelection}
                  style={{
                    background: "#FFFFFF",
                    color: "#A83B32",
                    border: "1px solid #F1C3BF",
                    borderRadius: 6,
                    padding: "6px 12px",
                    fontSize: 12.5,
                    fontWeight: 600,
                    cursor: "pointer",
                    fontFamily: "Sarabun, sans-serif",
                  }}
                >
                  ยกเลิกการเลือก
                </button>
              </>
            ) : (
              <span style={{ fontSize: 12, color: "#8A8874" }}>
                💡 ติ๊กเลือกรายการยาเพื่อเปิดใช้งานโหมดแก้ไขข้อมูลพร้อมกัน (Bulk Update)
              </span>
            )}
          </div>
        </div>
      )}

      {/* Bulk Update Modal Dialog */}
      {showBulkModal && (
        <div
          id="modal-bulk-update"
          style={{
            position: "fixed",
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            background: "rgba(0, 0, 0, 0.55)",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            zIndex: 1050,
            padding: 16,
          }}
          onClick={(e) => {
            if (e.target === e.currentTarget) setShowBulkModal(false);
          }}
        >
          <div
            style={{
              background: "#FFFFFF",
              borderRadius: 12,
              width: "100%",
              maxWidth: 580,
              maxHeight: "90vh",
              overflow: "auto",
              boxShadow: "0 16px 40px rgba(0, 0, 0, 0.25)",
              display: "flex",
              flexDirection: "column",
            }}
          >
            {/* Modal Header */}
            <div
              style={{
                padding: "16px 20px",
                borderBottom: "1px solid #E5E0D2",
                display: "flex",
                justifyContent: "space-between",
                alignItems: "center",
                background: "#F9F8F3",
                borderTopLeftRadius: 12,
                borderTopRightRadius: 12,
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
                <div
                  style={{
                    background: "#3C5A45",
                    color: "#FFFFFF",
                    padding: "6px 8px",
                    borderRadius: 6,
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                  }}
                >
                  <Sliders size={18} />
                </div>
                <div>
                  <h3
                    style={{
                      margin: 0,
                      fontFamily: "'Noto Serif Thai', serif",
                      fontSize: 18,
                      fontWeight: 700,
                      color: "#1F2D24",
                    }}
                  >
                    แก้ไขข้อมูลยาพร้อมกัน (Bulk Update)
                  </h3>
                  <div style={{ fontSize: 12, color: "#6A7B6E" }}>
                    อัปเดตสต็อกขั้นต่ำ (Min Stock) หรือหมวดหมู่ (Category) พร้อมกัน {selectedIds.length} รายการ
                  </div>
                </div>
              </div>
              <button
                id="btn-close-bulk-modal"
                onClick={() => setShowBulkModal(false)}
                style={{
                  background: "transparent",
                  border: "none",
                  cursor: "pointer",
                  color: "#8A8874",
                  padding: 4,
                  borderRadius: 4,
                }}
              >
                <X size={20} />
              </button>
            </div>

            {/* Modal Body */}
            <div style={{ padding: "18px 20px", display: "flex", flexDirection: "column", gap: 16 }}>
              {/* Selected Items Pills Container */}
              <div>
                <div style={{ fontSize: 12.5, fontWeight: 700, color: "#2D4834", marginBottom: 6 }}>
                  รายการยาที่เลือกไว้ ({selectedIds.length} รายการ):
                </div>
                <div
                  style={{
                    display: "flex",
                    flexWrap: "wrap",
                    gap: 6,
                    maxHeight: 110,
                    overflowY: "auto",
                    padding: "8px 10px",
                    background: "#F7F5EE",
                    borderRadius: 6,
                    border: "1px solid #E5E0D2",
                  }}
                >
                  {selectedIds.map((id) => {
                    const item = inv.items.find((i) => i.id === id);
                    if (!item) return null;
                    return (
                      <span
                        key={id}
                        style={{
                          background: "#FFFFFF",
                          border: "1px solid #D8D3C2",
                          borderRadius: 14,
                          padding: "3px 8px 3px 10px",
                          fontSize: 12,
                          color: "#1F2D24",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: 5,
                        }}
                      >
                        <span style={{ fontWeight: 600 }}>{item.name}</span>
                        <span style={{ color: "#8A8874", fontSize: 11 }}>({item.category})</span>
                        {selectedIds.length > 1 && (
                          <button
                            type="button"
                            onClick={() => handleToggleItem(id)}
                            style={{
                              border: "none",
                              background: "none",
                              cursor: "pointer",
                              color: "#A83B32",
                              padding: 0,
                              display: "flex",
                              alignItems: "center",
                            }}
                            title="นำออกจากรายการที่เลือก"
                          >
                            <X size={12} />
                          </button>
                        )}
                      </span>
                    );
                  })}
                </div>
              </div>

              {/* Setting 1: Min Stock Level */}
              <div
                style={{
                  border: bulkUpdateMinStock ? "1.5px solid #3C5A45" : "1px solid #D8D3C2",
                  borderRadius: 8,
                  padding: "14px 16px",
                  background: bulkUpdateMinStock ? "#FBFCFA" : "#FAFAFA",
                  transition: "all 0.15s ease",
                }}
              >
                <label
                  htmlFor="checkbox-bulk-minstock"
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    cursor: "pointer",
                    fontSize: 14,
                    fontWeight: 700,
                    color: bulkUpdateMinStock ? "#2D4834" : "#5B5747",
                  }}
                >
                  <input
                    id="checkbox-bulk-minstock"
                    type="checkbox"
                    checked={bulkUpdateMinStock}
                    onChange={(e) => setBulkUpdateMinStock(e.target.checked)}
                    style={{ width: 17, height: 17, accentColor: "#3C5A45", cursor: "pointer" }}
                  />
                  <span>อัปเดตเกณฑ์สต็อกขั้นต่ำ (Min Stock Level)</span>
                </label>

                {bulkUpdateMinStock && (
                  <div style={{ marginTop: 12, paddingLeft: 25 }}>
                    <div style={{ fontSize: 12, color: "#6A7B6E", marginBottom: 6 }}>
                      ระบุระดับสต็อกขั้นต่ำที่ต้องการกำหนดให้กับยาทั้งหมดที่เลือก:
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 10, flexWrap: "wrap" }}>
                      <input
                        id="bulk-minstock-input"
                        type="number"
                        min="0"
                        value={bulkMinStock}
                        onChange={(e) => setBulkMinStock(e.target.value)}
                        placeholder="เช่น 15"
                        style={{
                          ...inputStyle,
                          width: 140,
                          fontSize: 15,
                          fontWeight: 700,
                          color: "#1F2D24",
                        }}
                      />
                      <span style={{ fontSize: 13, color: "#6A7B6E" }}>หน่วย (ตามแต่ละรายการยา)</span>
                    </div>

                    {/* Presets */}
                    <div style={{ display: "flex", alignItems: "center", gap: 6, marginTop: 8, flexWrap: "wrap" }}>
                      <span style={{ fontSize: 11.5, color: "#8A8874" }}>ปุ่มด่วน:</span>
                      {[5, 10, 15, 20, 25, 30, 50, 100].map((preset) => (
                        <button
                          key={preset}
                          type="button"
                          onClick={() => setBulkMinStock(preset)}
                          style={{
                            border: Number(bulkMinStock) === preset ? "1px solid #3C5A45" : "1px solid #D8D3C2",
                            background: Number(bulkMinStock) === preset ? "#3C5A45" : "#FFFFFF",
                            color: Number(bulkMinStock) === preset ? "#FFFFFF" : "#4A564D",
                            fontSize: 11.5,
                            fontWeight: 600,
                            padding: "2px 7px",
                            borderRadius: 4,
                            cursor: "pointer",
                            fontFamily: "Sarabun, sans-serif",
                          }}
                        >
                          {preset}
                        </button>
                      ))}
                    </div>
                  </div>
                )}
              </div>

              {/* Setting 2: Category */}
              <div
                style={{
                  border: bulkUpdateCategory ? "1.5px solid #3C5A45" : "1px solid #D8D3C2",
                  borderRadius: 8,
                  padding: "14px 16px",
                  background: bulkUpdateCategory ? "#FBFCFA" : "#FAFAFA",
                  transition: "all 0.15s ease",
                }}
              >
                <label
                  htmlFor="checkbox-bulk-category"
                  style={{
                    display: "flex",
                    alignItems: "center",
                    gap: 8,
                    cursor: "pointer",
                    fontSize: 14,
                    fontWeight: 700,
                    color: bulkUpdateCategory ? "#2D4834" : "#5B5747",
                  }}
                >
                  <input
                    id="checkbox-bulk-category"
                    type="checkbox"
                    checked={bulkUpdateCategory}
                    onChange={(e) => setBulkUpdateCategory(e.target.checked)}
                    style={{ width: 17, height: 17, accentColor: "#3C5A45", cursor: "pointer" }}
                  />
                  <span>อัปเดตหมวดหมู่ยา (Medicine Category)</span>
                </label>

                {bulkUpdateCategory && (
                  <div style={{ marginTop: 12, paddingLeft: 25 }}>
                    <div style={{ fontSize: 12, color: "#6A7B6E", marginBottom: 6 }}>
                      เลือกหมวดหมู่ที่ต้องการเปลี่ยนให้กับยาทั้งหมดที่เลือก:
                    </div>
                    <select
                      id="bulk-category-select"
                      value={bulkCategory}
                      onChange={(e) => setBulkCategory(e.target.value)}
                      style={{
                        ...inputStyle,
                        maxWidth: 280,
                        fontSize: 14,
                        fontWeight: 600,
                      }}
                    >
                      {CATEGORIES.map((c) => (
                        <option key={c} value={c}>
                          {c}
                        </option>
                      ))}
                    </select>
                  </div>
                )}
              </div>

              {/* Information Summary */}
              <div
                style={{
                  background: "#F6F8F5",
                  border: "1px dashed #C8D8CB",
                  borderRadius: 8,
                  padding: "10px 14px",
                  fontSize: 12.5,
                  color: "#3C5A45",
                  display: "flex",
                  alignItems: "flex-start",
                  gap: 8,
                }}
              >
                <AlertCircle size={16} style={{ flexShrink: 0, marginTop: 1 }} />
                <div>
                  {!bulkUpdateCategory && !bulkUpdateMinStock ? (
                    <span style={{ color: "#A83B32", fontWeight: 600 }}>
                      ⚠️ กรุณาทำเครื่องหมายเลือกอย่างน้อย 1 รายการเพื่ออัปเดต
                    </span>
                  ) : (
                    <span>
                      ระบบจะอัปเดต
                      {bulkUpdateMinStock ? ` [เกณฑ์สต็อกขั้นต่ำเป็น ${bulkMinStock}]` : ""}
                      {bulkUpdateMinStock && bulkUpdateCategory ? " และ" : ""}
                      {bulkUpdateCategory ? ` [หมวดหมู่เป็น "${bulkCategory}"]` : ""} ให้กับยาทั้งหมด{" "}
                      <b>{selectedIds.length} รายการ</b> พร้อมกันทันที
                    </span>
                  )}
                </div>
              </div>
            </div>

            {/* Modal Footer Actions */}
            <div
              style={{
                padding: "14px 20px",
                borderTop: "1px solid #E5E0D2",
                display: "flex",
                justifyContent: "flex-end",
                gap: 10,
                background: "#F9F8F3",
                borderBottomLeftRadius: 12,
                borderBottomRightRadius: 12,
              }}
            >
              <Btn
                id="btn-cancel-bulk-modal"
                variant="subtle"
                onClick={() => setShowBulkModal(false)}
                disabled={isSavingBulk}
              >
                ยกเลิก
              </Btn>

              <button
                id="btn-confirm-bulk-update"
                onClick={handleApplyBulkUpdate}
                disabled={isSavingBulk || (!bulkUpdateCategory && !bulkUpdateMinStock)}
                style={{
                  background: !bulkUpdateCategory && !bulkUpdateMinStock ? "#B2BEB5" : "#3C5A45",
                  color: "#FFFFFF",
                  border: "none",
                  borderRadius: 6,
                  padding: "8px 18px",
                  fontSize: 13.5,
                  fontWeight: 700,
                  cursor: !bulkUpdateCategory && !bulkUpdateMinStock || isSavingBulk ? "not-allowed" : "pointer",
                  display: "inline-flex",
                  alignItems: "center",
                  gap: 6,
                  boxShadow: "0 2px 6px rgba(60, 90, 69, 0.2)",
                  fontFamily: "Sarabun, sans-serif",
                }}
              >
                <Check size={16} />
                <span>
                  {isSavingBulk ? "กำลังบันทึก..." : `ยืนยันอัปเดต (${selectedIds.length} รายการ)`}
                </span>
              </button>
            </div>
          </div>
        </div>
      )}

      {showForm && (
        <Panel id="panel-item-form" accent="#3C5A45" style={{ marginBottom: 16 }}>
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <div style={{ fontWeight: 700, fontSize: 16 }}>{editing ? "แก้ไขรายการยา" : "เพิ่มรายการยาใหม่"}</div>
            <button onClick={() => setShowForm(false)} style={{ border: "none", background: "transparent", cursor: "pointer" }}>
              <X size={18} color="#8A8874" />
            </button>
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 12 }}>
            <Field label="ชื่อยา">
              <input
                id="item-name-input"
                style={inputStyle}
                value={form.name}
                onChange={(e) => setForm({ ...form, name: e.target.value })}
                placeholder="เช่น ฟ้าทะลายโจร แคปซูล"
                autoFocus
              />
            </Field>
            <Field label="ประเภท / หมวดหมู่">
              <select
                id="item-category-input"
                style={inputStyle}
                value={form.category}
                onChange={(e) => setForm({ ...form, category: e.target.value })}
              >
                {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
              </select>
            </Field>
            <Field label="หน่วยนับ">
              <input
                id="item-unit-input"
                style={inputStyle}
                value={form.unit}
                onChange={(e) => setForm({ ...form, unit: e.target.value })}
                placeholder="เช่น กระปุก, กล่อง, ขวด, ซอง"
              />
            </Field>
            <Field label="สต็อกขั้นต่ำ (จุดสั่งซื้อ)">
              <input
                id="item-minstock-input"
                type="number"
                min="0"
                style={inputStyle}
                value={form.minStock}
                onChange={(e) => setForm({ ...form, minStock: e.target.value })}
              />
            </Field>
            <Field label="ราคาต่อหน่วย (บาท)">
              <input
                id="item-price-input"
                type="number"
                min="0"
                step="0.01"
                style={inputStyle}
                value={form.price}
                onChange={(e) => setForm({ ...form, price: e.target.value })}
                placeholder="0.00"
              />
            </Field>
            <Field label="ผู้จัดจำหน่าย / แหล่งผลิต">
              <input
                id="item-supplier-input"
                style={inputStyle}
                value={form.supplier || ""}
                onChange={(e) => setForm({ ...form, supplier: e.target.value })}
                placeholder="เช่น วิสาหกิจชุมชน, องค์การเภสัชกรรม"
              />
            </Field>
            <Field label="ปริมาณแนะนำสั่งซื้อต่อรอบ">
              <input
                id="item-reorder-qty-input"
                type="number"
                min="1"
                style={inputStyle}
                value={form.reorderQty || ""}
                onChange={(e) => setForm({ ...form, reorderQty: e.target.value })}
                placeholder="เช่น 20"
              />
            </Field>
            <Field label="ระยะเวลาจัดส่ง (วัน)">
              <input
                id="item-leadtime-input"
                type="number"
                min="0"
                style={inputStyle}
                value={form.leadTimeDays || ""}
                onChange={(e) => setForm({ ...form, leadTimeDays: e.target.value })}
                placeholder="เช่น 3"
              />
            </Field>
          </div>
          <div style={{ marginTop: 12 }}>
            <Field label="บันทึกการสั่งซื้อ / หมายเหตุจัดซื้อ">
              <input
                id="item-ordernotes-input"
                style={inputStyle}
                value={form.orderNotes || ""}
                onChange={(e) => setForm({ ...form, orderNotes: e.target.value })}
                placeholder="เช่น เงื่อนไขสั่งซื้อขั้นต่ำ, ผู้ประสานงาน, เบอร์ติดต่อ"
              />
            </Field>
          </div>
          <div style={{ marginTop: 16, display: "flex", gap: 8 }}>
            <Btn id="btn-save-item" onClick={submit}>
              <Check size={14} /> บันทึกรายการยา
            </Btn>
            <Btn variant="subtle" onClick={() => setShowForm(false)}>
              ยกเลิก
            </Btn>
          </div>
        </Panel>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {inv.items.length === 0 ? (
          <div style={{ color: "#5B5747", padding: "40px 20px", textAlign: "center", background: "#fff", borderRadius: 10, border: "1.5px dashed #D8D3C2" }}>
            <div style={{ width: 48, height: 48, borderRadius: "50%", background: "#EEF1E8", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px", color: "#3C5A45" }}>
              <Package size={24} />
            </div>
            <div style={{ fontWeight: 700, fontSize: 16, color: "#1F2D24" }}>
              ยังไม่มีรายการยาในคลัง (ข้อมูลตัวอย่างถูกล้างแล้ว)
            </div>
            <div style={{ fontSize: 13, color: "#8A8874", marginTop: 4, maxWidth: 440, margin: "6px auto 16px" }}>
              คุณสามารถกดปุ่ม "+ เพิ่มรายการยาใหม่" ด้านบนเพื่อเริ่มบันทึกข้อมูลจริง หรือโหลดข้อมูลตัวอย่างกลับมาเพื่อทดสอบระบบ
            </div>
            <div style={{ display: "flex", justifyContent: "center", gap: 10, flexWrap: "wrap" }}>
              <Btn id="btn-empty-create-item" onClick={openNew}>
                <Plus size={14} /> + เพิ่มรายการยาใหม่
              </Btn>
              {onLoadSampleData && (
                <Btn id="btn-empty-load-sample-items" variant="ghost" onClick={onLoadSampleData}>
                  <RotateCcw size={14} /> โหลดข้อมูลตัวอย่าง (5 รายการ)
                </Btn>
              )}
            </div>
          </div>
        ) : filtered.length === 0 ? (
          <div style={{ color: "#8A8874", fontSize: 14, padding: "30px 0", textAlign: "center", background: "#fff", borderRadius: 8, border: "1px dashed #D8D3C2" }}>
            ไม่พบรายการยาตามคำค้นหา
          </div>
        ) : null}
        {filtered.map((it) => {
          const stock = lotQtyForItem(inv.lots, it.id);
          const low = stock < it.minStock;
          const isSelected = selectedIds.includes(it.id);
          const lots = inv.lots
            .filter((l) => l.itemId === it.id && l.qty > 0)
            .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime());
          return (
            <div key={it.id}>
              <Panel
                id={`item-card-${it.id}`}
                accent={low ? "#A83B32" : isSelected ? "#2D683D" : "#3C5A45"}
                style={{
                  border: isSelected ? "2px solid #3C5A45" : undefined,
                  background: isSelected ? "#FAFCFA" : "#FFFFFF",
                  boxShadow: isSelected ? "0 4px 12px rgba(60, 90, 69, 0.12)" : undefined,
                  transition: "all 0.15s ease",
                }}
              >
                <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", flexWrap: "wrap", gap: 8 }}>
                  <div style={{ display: "flex", alignItems: "flex-start", gap: 10 }}>
                    <input
                      id={`item-checkbox-${it.id}`}
                      type="checkbox"
                      checked={isSelected}
                      onChange={() => handleToggleItem(it.id)}
                      style={{
                        width: 18,
                        height: 18,
                        marginTop: 3,
                        cursor: "pointer",
                        accentColor: "#3C5A45",
                        flexShrink: 0,
                      }}
                      title={`เลือก ${it.name} เพื่อแก้ไขพร้อมกัน`}
                    />
                    <div>
                      <div style={{ fontWeight: 700, fontSize: 16 }}>{it.name}</div>
                      <div style={{ fontSize: 12.5, color: "#8A8874", marginTop: 2 }}>
                        หมวดหมู่: <span style={{ color: "#3C5A45", fontWeight: 600 }}>{it.category}</span> · หน่วย: {it.unit}
                      </div>
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 6 }}>
                    <button
                      onClick={() => openEdit(it)}
                      title="แก้ไข"
                      style={{ border: "none", background: "#EEF1E8", borderRadius: 6, padding: "6px 8px", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, color: "#3C5A45", fontSize: 12, fontWeight: 600 }}
                    >
                      <Pencil size={13} color="#3C5A45" /> แก้ไข
                    </button>
                    <button
                      onClick={() => removeItem(it.id)}
                      title="ลบ"
                      style={{ border: "none", background: "#FBEDEB", borderRadius: 6, padding: "6px 8px", cursor: "pointer", display: "flex", alignItems: "center", gap: 4, color: "#A83B32", fontSize: 12, fontWeight: 600 }}
                    >
                      <Trash2 size={13} color="#A83B32" /> ลบ
                    </button>
                  </div>
                </div>

                <div style={{ display: "flex", gap: 20, marginTop: 12, fontSize: 13, flexWrap: "wrap", padding: "8px 12px", background: "#FBFAF6", borderRadius: 6, border: "1px solid #F0EEE3" }}>
                  <div>
                    คงเหลือ:{" "}
                    <b style={{ color: low ? "#A83B32" : "#1F2D24", fontSize: 14 }}>
                      {stock} {it.unit}
                    </b>
                    {low && <span style={{ marginLeft: 6, color: "#A83B32", fontSize: 11.5, fontWeight: 700 }}>(ต่ำกว่าเกณฑ์)</span>}
                  </div>
                  <div style={{ color: "#8A8874" }}>ขั้นต่ำ: {it.minStock} {it.unit}</div>
                  <div style={{ color: "#8A8874" }}>จำนวนล็อตที่มี: {lots.length}</div>
                  <div style={{ color: "#8A8874" }}>ราคา/หน่วย: ฿{Number(it.price || 0).toLocaleString(undefined, { minimumFractionDigits: 2 })}</div>
                  <div style={{ color: "#5B7A63", fontWeight: 700 }}>
                    มูลค่ารวม: ฿{(stock * (Number(it.price) || 0)).toLocaleString(undefined, { minimumFractionDigits: 2 })}
                  </div>
                </div>

                {/* Active Lots */}
                {lots.length > 0 && (
                  <div style={{ marginTop: 10 }}>
                    <div style={{ fontSize: 12, color: "#8A8874", marginBottom: 4, fontWeight: 600, display: "flex", alignItems: "center", gap: 6 }}>
                      <span>ล็อตที่มีในคลัง (คลิกที่ล็อตเพื่อดูวงจรชีวิต):</span>
                    </div>
                    <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                      {lots.map((l) => {
                        const d = daysUntil(l.expiryDate);
                        const warn = d <= 90;
                        return (
                          <div
                            key={l.id}
                            id={`lot-pill-${l.id}`}
                            onClick={() => onOpenLotLifecycle?.(l.id)}
                            style={{
                              fontSize: 12,
                              padding: "4px 10px",
                              borderRadius: 20,
                              background: warn ? (d < 0 ? "#FBEDEB" : "#FBF3E2") : "#F0EEE3",
                              color: warn ? (d < 0 ? "#A83B32" : "#946A1F") : "#5B5747",
                              border: warn ? (d < 0 ? "1px solid #F3C3BE" : "1px solid #F0DAA8") : "1px solid #E4E0D2",
                              display: "flex",
                              alignItems: "center",
                              gap: 6,
                              cursor: "pointer",
                              transition: "all 0.15s ease",
                              boxShadow: "0 1px 2px rgba(0,0,0,0.02)",
                            }}
                            title={`คลิกเพื่อดูวงจรชีวิตล็อต ${l.lotNo || ""} ตั้งแต่รับเข้าจนหมดสต็อก`}
                          >
                            <span style={{ fontWeight: 600 }}>ล็อต {l.lotNo || "ไม่ระบุ"}</span>
                            <span>· {l.qty} {it.unit}</span>
                            <span>· หมดอายุ {fmtDate(l.expiryDate)}</span>
                            {warn && <span style={{ fontWeight: 700 }}>({d < 0 ? "หมดอายุ" : `เหลือ ${d} ว.`})</span>}
                            <Eye size={12} style={{ opacity: 0.7 }} />
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Depleted Lots History for this Medicine */}
                {(() => {
                  const depletedLots = inv.lots.filter((l) => l.itemId === it.id && l.qty === 0);
                  if (depletedLots.length === 0) return null;
                  const isExpanded = expandedDepletedItemIds.includes(it.id);

                  return (
                    <div style={{ marginTop: 8 }}>
                      <button
                        id={`btn-toggle-depleted-lots-${it.id}`}
                        onClick={() => {
                          setExpandedDepletedItemIds((prev) =>
                            prev.includes(it.id) ? prev.filter((id) => id !== it.id) : [...prev, it.id]
                          );
                        }}
                        style={{
                          background: "transparent",
                          border: "none",
                          color: "#6B5B95",
                          fontSize: 12,
                          fontWeight: 600,
                          cursor: "pointer",
                          display: "inline-flex",
                          alignItems: "center",
                          gap: 4,
                          padding: "2px 0",
                          textDecoration: "underline",
                        }}
                        title="ดูล็อตยาที่ถูกเบิกจ่ายจนหมดสิ้น (Final Depletion) แล้ว"
                      >
                        <History size={13} />
                        <span>
                          {isExpanded
                            ? "ซ่อนประวัติล็อตที่เบิกจ่ายหมดแล้ว"
                            : `ดูประวัติล็อตที่เบิกจ่ายหมดแล้ว (${depletedLots.length} ล็อต)`}
                        </span>
                      </button>

                      {isExpanded && (
                        <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 6 }}>
                          {depletedLots.map((dl) => (
                            <div
                              key={dl.id}
                              id={`lot-pill-${dl.id}`}
                              onClick={() => onOpenLotLifecycle?.(dl.id)}
                              style={{
                                fontSize: 11.5,
                                padding: "4px 10px",
                                borderRadius: 20,
                                background: "#F4F2F9",
                                color: "#574880",
                                border: "1px dashed #D6D0EA",
                                display: "flex",
                                alignItems: "center",
                                gap: 6,
                                cursor: "pointer",
                                transition: "all 0.15s ease",
                              }}
                              title="คลิกเพื่อดูวงจรชีวิตล็อตยานี้ตั้งแต่รับเข้าจนหมดสต็อก (100% Depleted)"
                            >
                              <span style={{ fontWeight: 600 }}>ล็อต {dl.lotNo || "ไม่ระบุ"}</span>
                              <span
                                style={{
                                  fontSize: 10.5,
                                  background: "#6B5B95",
                                  color: "#fff",
                                  padding: "1px 6px",
                                  borderRadius: 10,
                                }}
                              >
                                เบิกหมดแล้ว (0 {it.unit})
                              </span>
                              <Eye size={12} />
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  );
                })()}

                {(it.supplier || it.reorderQty || it.orderNotes) && (
                  <div
                    style={{
                      marginTop: 10,
                      padding: "6px 10px",
                      background: "#F6F8F6",
                      borderRadius: 6,
                      fontSize: 12,
                      color: "#5B5747",
                      display: "flex",
                      gap: 14,
                      flexWrap: "wrap",
                      border: "1px dashed #D5E0D8",
                    }}
                  >
                    {it.supplier && (
                      <div>
                        ผู้จัดจำหน่าย: <strong style={{ color: "#1F2D24" }}>{it.supplier}</strong>
                      </div>
                    )}
                    {it.reorderQty && (
                      <div>
                        แนะนำสั่งซื้อต่อรอบ: <strong style={{ color: "#3C5A45" }}>{it.reorderQty} {it.unit}</strong>
                      </div>
                    )}
                    {it.leadTimeDays && (
                      <div>
                        ระยะเวลารอสินค้า: <strong>{it.leadTimeDays} วัน</strong>
                      </div>
                    )}
                    {it.orderNotes && (
                      <div style={{ color: "#7B6645" }}>
                        หมายเหตุ: {it.orderNotes}
                      </div>
                    )}
                  </div>
                )}
              </Panel>
            </div>
          );
        })}
      </div>
    </div>
  );
}
