import React, { useState, useEffect, useMemo, useCallback } from "react";
import {
  LayoutDashboard, Package, ArrowLeftRight, History, Leaf, RefreshCw, Check, Mail, Trash2, RotateCcw
} from "lucide-react";
import type { InventoryState, StockTransaction } from "./types";
import {
  loadInventory, saveInventory,
  loadTx, saveTx,
  loadName, saveName,
  lotQtyForItem, daysUntil,
  clearAllData, loadSampleData
} from "./utils/storage";
import { Dashboard } from "./components/Dashboard";
import { ItemsView } from "./components/ItemsView";
import { MoveView } from "./components/MoveView";
import { HistoryView } from "./components/HistoryView";
import { LotLifecycleModal } from "./components/LotLifecycleModal";

// ---------- Google Fonts (Thai-friendly) ----------
function useFonts() {
  useEffect(() => {
    const id = "herbal-stock-fonts";
    if (document.getElementById(id)) return;
    const link = document.createElement("link");
    link.id = id;
    link.rel = "stylesheet";
    link.href =
      "https://fonts.googleapis.com/css2?family=Noto+Serif+Thai:wght@500;600;700&family=Sarabun:wght@400;500;600;700&display=swap";
    document.head.appendChild(link);
  }, []);
}

export default function HerbalStockApp() {
  useFonts();
  const [tab, setTab] = useState<"dashboard" | "items" | "move" | "history">("dashboard");
  const [inv, setInv] = useState<InventoryState>({ items: [], lots: [] });
  const [tx, setTx] = useState<StockTransaction[]>([]);
  const [staffName, setStaffName] = useState("");
  const [loading, setLoading] = useState(true);
  const [toast, setToast] = useState<string | null>(null);
  const [lastSynced, setLastSynced] = useState<Date | null>(null);
  const [syncing, setSyncing] = useState(false);
  const [preselectedMoveItem, setPreselectedMoveItem] = useState<string>("");
  const [preselectedMoveMode, setPreselectedMoveMode] = useState<"in" | "out">("in");
  const [lifecycleLotId, setLifecycleLotId] = useState<string | null>(null);

  useEffect(() => {
    (async () => {
      const [i, t, n] = await Promise.all([loadInventory(), loadTx(), loadName()]);
      setInv(i);
      setTx(t);
      setStaffName(n);
      setLoading(false);
      setLastSynced(new Date());
    })();
  }, []);

  const showToast = useCallback((msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 2500);
  }, []);

  // Pull the latest shared data from storage
  const doSync = useCallback(
    async (silent?: boolean) => {
      setSyncing(true);
      try {
        const [i, t] = await Promise.all([loadInventory(), loadTx()]);
        setInv(i);
        setTx(t);
        setLastSynced(new Date());
        if (!silent) showToast("ซิงค์ข้อมูลล่าสุดเรียบร้อยแล้ว");
      } catch {
        if (!silent) showToast("ซิงค์ไม่สำเร็จ ลองใหม่อีกครั้ง");
      } finally {
        setSyncing(false);
      }
    },
    [showToast]
  );

  // Auto background sync every 20s, and whenever the tab becomes visible again
  useEffect(() => {
    const interval = setInterval(() => doSync(true), 20000);
    const onVisible = () => {
      if (document.visibilityState === "visible") doSync(true);
    };
    document.addEventListener("visibilitychange", onVisible);
    return () => {
      clearInterval(interval);
      document.removeEventListener("visibilitychange", onVisible);
    };
  }, [doSync]);

  const persistInv = useCallback(async (next: InventoryState) => {
    setInv(next);
    await saveInventory(next);
    setLastSynced(new Date());
  }, []);

  const persistTx = useCallback(async (next: StockTransaction[]) => {
    setTx(next);
    await saveTx(next);
    setLastSynced(new Date());
  }, []);

  const handleClearSampleData = useCallback(async () => {
    const ok = window.confirm(
      "ยืนยันการล้างข้อมูลตัวอย่างทั้งหมดในคลังยาใช่หรือไม่?\n\nการกระทำนี้จะล้างรายการยาทั้งหมด สต็อกคงเหลือ และประวัติการรับเข้า-เบิกออก เพื่อให้คุณเริ่มต้นใช้งานคลังยาใหม่จากศูนย์"
    );
    if (!ok) return;
    const { inventory, transactions } = await clearAllData();
    setInv(inventory);
    setTx(transactions);
    setLastSynced(new Date());
    showToast("ล้างข้อมูลตัวอย่างทั้งหมดเรียบร้อยแล้ว คลังยาพร้อมใช้งาน");
  }, [showToast]);

  const handleLoadSampleData = useCallback(async () => {
    const ok = window.confirm(
      "ต้องการโหลดชุดข้อมูลตัวอย่างสมุนไพร 5 รายการ พร้อมล็อตและประวัติ เพื่อใช้ทดสอบระบบใช่หรือไม่?"
    );
    if (!ok) return;
    const { inventory, transactions } = await loadSampleData();
    setInv(inventory);
    setTx(transactions);
    setLastSynced(new Date());
    showToast("โหลดชุดข้อมูลตัวอย่าง 5 รายการเรียบร้อยแล้ว");
  }, [showToast]);

  const lowStockItems = useMemo(
    () => inv.items.filter((it) => lotQtyForItem(inv.lots, it.id) < it.minStock),
    [inv]
  );

  const nearExpiryLots = useMemo(
    () =>
      inv.lots
        .filter((l) => l.qty > 0 && daysUntil(l.expiryDate) <= 90)
        .sort((a, b) => new Date(a.expiryDate).getTime() - new Date(b.expiryDate).getTime()),
    [inv.lots]
  );

  if (loading) {
    return (
      <div className="flex items-center justify-center min-h-[500px] font-['Sarabun'] text-[#5B5747]">
        <div className="flex items-center gap-3 bg-white px-6 py-4 rounded-xl border border-[#E4E0D2] shadow-sm">
          <Leaf className="animate-spin text-[#3C5A45]" size={20} />
          <span>กำลังโหลดข้อมูลคลังยาสมุนไพร...</span>
        </div>
      </div>
    );
  }

  const NAV = [
    { id: "dashboard", label: "ภาพรวม", icon: LayoutDashboard },
    { id: "items", label: "รายการยา", icon: Package },
    { id: "move", label: "รับเข้า / เบิกออก", icon: ArrowLeftRight },
    { id: "history", label: "ประวัติ & รายงาน", icon: History },
  ] as const;

  return (
    <div
      id="herbal-app-container"
      className="herbal-app-root max-w-7xl mx-auto my-4"
      style={{
        fontFamily: "Sarabun, sans-serif",
        background: "#F6F3EA",
        minHeight: 650,
        display: "flex",
        color: "#1F2D24",
        borderRadius: 12,
        overflow: "hidden",
        border: "1px solid #E4E0D2",
        boxShadow: "0 4px 20px rgba(42,56,44,0.06)",
      }}
    >
      <style>{`
        @media print {
          .herbal-app-root { display: block !important; border: none !important; border-radius: 0 !important; overflow: visible !important; background: #fff !important; box-shadow: none !important; margin: 0 !important; max-width: 100% !important; }
          .herbal-app-main { max-height: none !important; overflow: visible !important; padding: 0 !important; }
        }
      `}</style>

      {/* Sidebar */}
      <aside
        id="app-sidebar"
        className="no-print"
        style={{
          width: 220,
          flexShrink: 0,
          background: "#1F2D24",
          color: "#EFEDE3",
          padding: "20px 14px",
          display: "flex",
          flexDirection: "column",
          gap: 4,
        }}
      >
        <div style={{ display: "flex", alignItems: "center", gap: 10, padding: "4px 8px 22px" }}>
          <div style={{ background: "rgba(156,182,140,0.18)", padding: 6, borderRadius: 8 }}>
            <Leaf size={22} color="#9CB68C" />
          </div>
          <div>
            <div style={{ fontFamily: "'Noto Serif Thai', serif", fontWeight: 700, fontSize: 16, lineHeight: 1.2 }}>
              คลังยาสมุนไพร
            </div>
            <div style={{ fontSize: 11, color: "#8FA888", marginTop: 2 }}>ระบบคลังเวชภัณฑ์</div>
          </div>
        </div>

        <nav className="flex flex-col gap-1">
          {NAV.map((n) => {
            const Icon = n.icon;
            const active = tab === n.id;
            return (
              <button
                key={n.id}
                id={`nav-${n.id}`}
                onClick={() => setTab(n.id)}
                style={{
                  display: "flex",
                  alignItems: "center",
                  gap: 10,
                  padding: "10px 12px",
                  borderRadius: 8,
                  border: "none",
                  background: active ? "#3C5A45" : "transparent",
                  color: active ? "#fff" : "#C9C6B8",
                  fontFamily: "Sarabun, sans-serif",
                  fontSize: 14,
                  fontWeight: active ? 700 : 500,
                  cursor: "pointer",
                  textAlign: "left",
                  transition: "background 0.15s ease",
                }}
              >
                <Icon size={16} />
                <span>{n.label}</span>
                {n.id === "dashboard" && (lowStockItems.length > 0 || nearExpiryLots.length > 0) && (
                  <span
                    style={{
                      marginLeft: "auto",
                      background: lowStockItems.length > 0 ? "#A83B32" : "#C08A2E",
                      color: "#fff",
                      fontSize: 11,
                      fontWeight: 700,
                      padding: "1px 6px",
                      borderRadius: 10,
                    }}
                  >
                    {lowStockItems.length + nearExpiryLots.length}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        <div style={{ marginTop: "auto", paddingTop: 14 }}>
          <div
            id="sidebar-email-indicator"
            onClick={() => {
              setTab("dashboard");
              setTimeout(() => {
                const btn = document.getElementById("btn-open-email-alerts");
                if (btn) btn.click();
              }, 120);
            }}
            style={{
              padding: "8px 10px",
              borderRadius: 8,
              background: "rgba(255, 255, 255, 0.05)",
              border: "1px solid #3A4A3C",
              marginBottom: 10,
              cursor: "pointer",
              transition: "all 0.15s ease",
            }}
            title="คลิกเพื่อเปิดระบบจำลองแจ้งเตือนอีเมล"
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between" }}>
              <div style={{ display: "flex", alignItems: "center", gap: 6, fontSize: 11.5, color: "#9CB68C", fontWeight: 700 }}>
                <Mail size={13} />
                <span>จำลองแจ้งเตือนอีเมล</span>
              </div>
              {(lowStockItems.length > 0 || nearExpiryLots.length > 0) && (
                <span
                  style={{
                    background: lowStockItems.length > 0 ? "#A83B32" : "#C08A2E",
                    color: "#FFFFFF",
                    fontSize: 10,
                    fontWeight: 700,
                    padding: "1px 5px",
                    borderRadius: 8,
                  }}
                >
                  {lowStockItems.length + nearExpiryLots.length}
                </span>
              )}
            </div>
            <div style={{ fontSize: 11, color: "#EFEDE3", marginTop: 3, fontWeight: 500, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
              titee2409@gmail.com
            </div>
          </div>

          <button
            id="sync-button"
            onClick={() => doSync(false)}
            disabled={syncing}
            style={{
              width: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: 7,
              background: "#2A382C",
              border: "1px solid #445040",
              borderRadius: 7,
              color: "#C9C6B8",
              fontSize: 12.5,
              fontFamily: "Sarabun, sans-serif",
              fontWeight: 600,
              padding: "8px 10px",
              cursor: syncing ? "default" : "pointer",
            }}
          >
            <RefreshCw size={13} style={{ animation: syncing ? "spin 0.8s linear infinite" : "none" }} />
            {syncing ? "กำลังซิงค์..." : "ซิงค์ข้อมูลล่าสุด"}
          </button>
          <div style={{ fontSize: 10.5, color: "#8A8874", textAlign: "center", marginTop: 5 }}>
            {lastSynced ? `ซิงค์ล่าสุด ${lastSynced.toLocaleTimeString("th-TH", { hour: "2-digit", minute: "2-digit" })} น.` : ""}
          </div>

          {/* Quick Clear / Load Sample Data Buttons */}
          <div style={{ marginTop: 10, display: "flex", flexDirection: "column", gap: 6 }}>
            {inv.items.length > 0 ? (
              <button
                id="btn-sidebar-clear-sample-data"
                onClick={handleClearSampleData}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 6,
                  background: "transparent",
                  border: "1px dashed rgba(168, 59, 50, 0.45)",
                  borderRadius: 6,
                  color: "#E28B83",
                  fontSize: 11.5,
                  fontFamily: "Sarabun, sans-serif",
                  fontWeight: 600,
                  padding: "6px 8px",
                  cursor: "pointer",
                  transition: "all 0.15s ease",
                }}
                title="ล้างข้อมูลตัวอย่างและเริ่มใช้งานคลังยาเปล่า"
              >
                <Trash2 size={12} color="#E28B83" />
                <span>ล้างข้อมูลตัวอย่าง</span>
              </button>
            ) : (
              <button
                id="btn-sidebar-load-sample-data"
                onClick={handleLoadSampleData}
                style={{
                  width: "100%",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: 6,
                  background: "rgba(156, 182, 140, 0.12)",
                  border: "1px dashed rgba(156, 182, 140, 0.4)",
                  borderRadius: 6,
                  color: "#9CB68C",
                  fontSize: 11.5,
                  fontFamily: "Sarabun, sans-serif",
                  fontWeight: 600,
                  padding: "6px 8px",
                  cursor: "pointer",
                  transition: "all 0.15s ease",
                }}
                title="โหลดข้อมูลตัวอย่าง 5 รายการเพื่อทดสอบระบบ"
              >
                <RotateCcw size={12} color="#9CB68C" />
                <span>โหลดข้อมูลตัวอย่าง</span>
              </button>
            )}
          </div>
          <style>{`@keyframes spin { from { transform: rotate(0deg);} to { transform: rotate(360deg);} }`}</style>
        </div>

        <div style={{ paddingTop: 14, borderTop: "1px solid #33422F" }}>
          <div style={{ fontSize: 11, color: "#8A8874", marginBottom: 6 }}>ผู้ใช้งานปัจจุบัน</div>
          <input
            id="staff-name-input"
            value={staffName}
            onChange={(e) => setStaffName(e.target.value)}
            onBlur={(e) => saveName(e.target.value)}
            placeholder="ชื่อผู้บันทึก"
            style={{
              width: "100%",
              boxSizing: "border-box",
              background: "#2A382C",
              border: "1px solid #445040",
              borderRadius: 6,
              color: "#EFEDE3",
              padding: "7px 9px",
              fontSize: 13,
              fontFamily: "Sarabun, sans-serif",
            }}
          />
        </div>
      </aside>

      {/* Main Content Area */}
      <main
        id="app-main-content"
        className="herbal-app-main"
        style={{ flex: 1, padding: "22px 28px", overflow: "auto", maxHeight: 780 }}
      >
        {tab === "dashboard" && (
          <Dashboard
            inv={inv}
            lowStockItems={lowStockItems}
            nearExpiryLots={nearExpiryLots}
            tx={tx}
            setTab={setTab}
            persistInv={persistInv}
            showToast={showToast}
            onOpenMoveWithItem={(itemId, mode = "in") => {
              setPreselectedMoveItem(itemId);
              setPreselectedMoveMode(mode);
              setTab("move");
            }}
            onClearSampleData={handleClearSampleData}
            onLoadSampleData={handleLoadSampleData}
            onOpenLotLifecycle={(lotId) => setLifecycleLotId(lotId)}
          />
        )}
        {tab === "items" && (
          <ItemsView
            inv={inv}
            tx={tx}
            persistInv={persistInv}
            showToast={showToast}
            onLoadSampleData={handleLoadSampleData}
            onOpenLotLifecycle={(lotId) => setLifecycleLotId(lotId)}
            onNavigateToMove={(itemId, lotId) => {
              setPreselectedMoveItem(itemId);
              setPreselectedMoveMode("out");
              setTab("move");
            }}
          />
        )}
        {tab === "move" && (
          <MoveView
            inv={inv}
            persistInv={persistInv}
            tx={tx}
            persistTx={persistTx}
            staffName={staffName}
            showToast={showToast}
            preselectedItemId={preselectedMoveItem}
            preselectedMode={preselectedMoveMode}
            onNavigateToItems={() => setTab("items")}
          />
        )}
        {tab === "history" && (
          <HistoryView
            inv={inv}
            tx={tx}
            persistInv={persistInv}
            persistTx={persistTx}
            showToast={showToast}
            onClearSampleData={handleClearSampleData}
            onLoadSampleData={handleLoadSampleData}
            onOpenLotLifecycle={(lotId) => setLifecycleLotId(lotId)}
          />
        )}
      </main>

      {/* Lot Lifecycle Detail History Modal */}
      <LotLifecycleModal
        isOpen={!!lifecycleLotId}
        onClose={() => setLifecycleLotId(null)}
        lotId={lifecycleLotId}
        inv={inv}
        tx={tx}
        onNavigateToMove={(itemId, lotId) => {
          setPreselectedMoveItem(itemId);
          setPreselectedMoveMode("out");
          setTab("move");
        }}
        showToast={showToast}
      />

      {/* Toast Notification */}
      {toast && (
        <div
          id="app-toast"
          style={{
            position: "fixed",
            bottom: 24,
            left: "50%",
            transform: "translateX(-50%)",
            background: "#1F2D24",
            color: "#fff",
            padding: "10px 20px",
            borderRadius: 8,
            fontSize: 13.5,
            fontWeight: 500,
            boxShadow: "0 8px 24px rgba(0,0,0,0.25)",
            zIndex: 9999,
            display: "flex",
            alignItems: "center",
            gap: 8,
            border: "1px solid #3C5A45",
          }}
        >
          <Check size={16} color="#9CB68C" />
          <span>{toast}</span>
        </div>
      )}
    </div>
  );
}
